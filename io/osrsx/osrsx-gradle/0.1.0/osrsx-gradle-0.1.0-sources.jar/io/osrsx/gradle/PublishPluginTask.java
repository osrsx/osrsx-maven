package io.osrsx.gradle;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GraphicsEnvironment;
import java.awt.Insets;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicReference;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.gradle.api.DefaultTask;
import org.gradle.api.GradleException;
import org.gradle.api.tasks.Input;
import org.gradle.api.tasks.Optional;
import org.gradle.api.tasks.TaskAction;
import org.gradle.api.tasks.options.Option;

/**
 * {@code publishPlugin} — one command to submit a plugin to the osrsx registry, doing all the heavy
 * lifting:
 * <ol>
 *   <li>collects the release info (version, changelog, description) — from a small Swing dialog when run
 *       interactively, or from {@code -Pversion=/-Pchangelog=/-Pdescription=} in CI/headless,</li>
 *   <li>makes sure the author's repo is pushed (pushes the current HEAD + a {@code v<version>} tag),</li>
 *   <li>authenticates to GitHub — the local {@code gh} CLI token if present, else a GitHub OAuth
 *       device-flow sign-in (needs {@code osrsxPlugin.oauthClientId}), else a token typed into the dialog,</li>
 *   <li>opens the submission issue on the registry ({@code osrsx/osrsx-central}) with the standard
 *       fields, which the registry CI picks up to build + publish the plugin.</li>
 * </ol>
 * Note: the Swing/OAuth/GitHub-API paths are network- and desktop-dependent and are exercised at runtime,
 * not by unit tests.
 */
public class PublishPluginTask extends DefaultTask {

    private static final String REGISTRY_REPO = "osrsx/osrsx-central";
    private static final String DEVICE_CODE_URL = "https://github.com/login/device/code";
    private static final String DEVICE_TOKEN_URL = "https://github.com/login/oauth/access_token";

    private String pluginId;
    private String repoUrl;          // https://github.com/<owner>/<repo>
    private String version;
    private String changelog = "";
    private String description = "";
    private String oauthClientId;    // optional; enables the device-flow fallback

    @Input public String getPluginId() { return pluginId; }
    public void setPluginId(String v) { this.pluginId = v; }

    @Input public String getRepoUrl() { return repoUrl; }
    public void setRepoUrl(String v) { this.repoUrl = v; }

    @Input @Optional
    @Option(option = "pluginVersion", description = "Version to publish (defaults to the project version).")
    public String getVersion() { return version; }
    public void setVersion(String v) { this.version = v; }

    @Input @Optional public String getChangelog() { return changelog; }
    public void setChangelog(String v) { this.changelog = v; }

    @Input @Optional public String getDescription() { return description; }
    public void setDescription(String v) { this.description = v; }

    @Input @Optional public String getOauthClientId() { return oauthClientId; }
    public void setOauthClientId(String v) { this.oauthClientId = v; }

    @TaskAction
    public void publish() {
        if (repoUrl == null || !repoUrl.contains("github.com")) {
            throw new GradleException("Could not determine a GitHub repo URL for this plugin (git remote 'origin'). "
                    + "Push the plugin to a GitHub repo first.");
        }
        // 1) collect release info (dialog when interactive, else -P props).
        boolean interactive = !GraphicsEnvironment.isHeadless()
                && !Boolean.parseBoolean(String.valueOf(getProject().findProperty("noninteractive")));
        if (interactive) {
            Release r = promptRelease(pluginId, version, description, changelog);
            if (r == null) throw new GradleException("Publish cancelled.");
            version = r.version; description = r.description; changelog = r.changelog;
        }
        if (version == null || version.isBlank()) {
            throw new GradleException("No version — pass -PpluginVersion=<v> or set the project version.");
        }

        // 2) ensure the repo is pushed + tagged so the registry CI can clone this exact commit.
        pushAndTag(version);

        // 3) get a GitHub token: gh CLI, then device flow, then a typed PAT.
        String token = resolveToken(interactive);
        if (token == null || token.isBlank()) throw new GradleException("No GitHub token available to submit.");

        // 4) open the submission issue on the registry.
        String issueUrl = createSubmissionIssue(token, repoUrl, pluginId, version, description, changelog);
        getLogger().lifecycle("[osrsx] submitted {} v{} — tracking issue: {}", pluginId, version, issueUrl);
        getLogger().lifecycle("[osrsx] the registry CI will build + publish it; a maintainer merges the bot PR to go live.");
    }

    // ---- release info dialog -------------------------------------------------

    private static final class Release {
        final String version; final String description; final String changelog;
        Release(String v, String d, String c) { version = v; description = d; changelog = c; }
    }

    private Release promptRelease(String id, String defVersion, String defDesc, String defChangelog) {
        AtomicReference<Release> out = new AtomicReference<>();
        runOnSwing(() -> {
            JTextField versionField = new JTextField(defVersion == null ? "" : defVersion, 20);
            JTextField descField = new JTextField(defDesc == null ? "" : defDesc, 20);
            JTextArea changelogArea = new JTextArea(defChangelog == null ? "" : defChangelog, 6, 20);
            changelogArea.setLineWrap(true);

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints c = new GridBagConstraints();
            c.insets = new Insets(4, 4, 4, 4);
            c.anchor = GridBagConstraints.WEST;
            c.fill = GridBagConstraints.HORIZONTAL;
            addRow(panel, c, 0, new JLabel("Plugin"), new JLabel(id == null ? "(this plugin)" : id));
            addRow(panel, c, 1, new JLabel("Version"), versionField);
            addRow(panel, c, 2, new JLabel("Description"), descField);
            addRow(panel, c, 3, new JLabel("Changelog"), new JScrollPane(changelogArea));

            JDialog dialog = new JDialog((java.awt.Frame) null, "Publish osrsx plugin", true);
            JButton ok = new JButton("Publish");
            JButton cancel = new JButton("Cancel");
            ok.addActionListener(e -> {
                out.set(new Release(versionField.getText().trim(), descField.getText().trim(), changelogArea.getText().trim()));
                dialog.dispose();
            });
            cancel.addActionListener(e -> dialog.dispose());
            JPanel buttons = new JPanel();
            buttons.add(cancel); buttons.add(ok);
            c.gridx = 0; c.gridy = 4; c.gridwidth = 2;
            panel.add(buttons, c);

            dialog.setContentPane(panel);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
        });
        return out.get();
    }

    private static void addRow(JPanel panel, GridBagConstraints c, int row, JLabel label, java.awt.Component field) {
        c.gridx = 0; c.gridy = row; c.gridwidth = 1; c.weightx = 0; panel.add(label, c);
        c.gridx = 1; c.weightx = 1; panel.add(field, c);
    }

    private static void runOnSwing(Runnable r) {
        try {
            if (SwingUtilities.isEventDispatchThread()) r.run();
            else SwingUtilities.invokeAndWait(r);
        } catch (Exception e) {
            throw new GradleException("Publish dialog failed: " + e.getMessage(), e);
        }
    }

    // ---- git -----------------------------------------------------------------

    private void pushAndTag(String version) {
        String tag = "v" + version;
        exec("git", "push", "origin", "HEAD");
        // create the tag if missing, then push it (ignore "already exists").
        if (run("git", "rev-parse", "-q", "--verify", "refs/tags/" + tag) != 0) {
            exec("git", "tag", "-a", tag, "-m", "osrsx plugin " + version);
        }
        run("git", "push", "origin", tag);
    }

    // ---- auth ----------------------------------------------------------------

    private String resolveToken(boolean interactive) {
        String gh = capture("gh", "auth", "token");
        if (gh != null && !gh.isBlank()) {
            getLogger().lifecycle("[osrsx] using the local gh CLI token.");
            return gh.trim();
        }
        if (oauthClientId != null && !oauthClientId.isBlank()) {
            String t = deviceFlow(oauthClientId);
            if (t != null) return t;
        }
        if (interactive) {
            AtomicReference<String> pat = new AtomicReference<>();
            runOnSwing(() -> {
                JTextField field = new JTextField(30);
                JPanel p = new JPanel();
                p.add(new JLabel("GitHub token (create one at github.com/settings/tokens, scope: public_repo):"));
                p.add(field);
                int r = javax.swing.JOptionPane.showConfirmDialog(null, p, "GitHub sign-in",
                        javax.swing.JOptionPane.OK_CANCEL_OPTION);
                if (r == javax.swing.JOptionPane.OK_OPTION) pat.set(field.getText().trim());
            });
            return pat.get();
        }
        return null;
    }

    /** GitHub OAuth device flow: request a code, tell the user, poll until they authorise. */
    private String deviceFlow(String clientId) {
        try {
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
            String start = post(http, DEVICE_CODE_URL, "client_id=" + clientId + "&scope=public_repo");
            String deviceCode = jsonField(start, "device_code");
            String userCode = jsonField(start, "user_code");
            String verifyUri = jsonField(start, "verification_uri");
            int interval = parseIntOr(jsonField(start, "interval"), 5);
            if (deviceCode == null || userCode == null) return null;

            getLogger().lifecycle("[osrsx] to authorise, open {} and enter code: {}", verifyUri, userCode);
            openBrowser(verifyUri);

            for (int i = 0; i < 60; i++) {
                Thread.sleep(interval * 1000L);
                String poll = post(http, DEVICE_TOKEN_URL, "client_id=" + clientId + "&device_code=" + deviceCode
                        + "&grant_type=urn:ietf:params:oauth:grant-type:device_code");
                String token = jsonField(poll, "access_token");
                if (token != null && !token.isBlank()) return token;
                if ("access_denied".equals(jsonField(poll, "error"))) return null;
            }
        } catch (Exception e) {
            getLogger().warn("[osrsx] device-flow sign-in failed: {}", e.getMessage());
        }
        return null;
    }

    // ---- issue creation ------------------------------------------------------

    private String createSubmissionIssue(String token, String repoUrl, String pluginId, String version,
                                         String description, String changelog) {
        String body = "### Repository URL\n\n" + repoUrl + "\n\n"
                + "### Description\n\n" + (description == null || description.isBlank() ? "(none)" : description) + "\n\n"
                + "### Version (optional)\n\n" + version + "\n\n"
                + "### Changelog\n\n" + (changelog == null || changelog.isBlank() ? "(none)" : changelog) + "\n";
        String title = "[plugin] " + (pluginId == null ? "submission" : pluginId) + " v" + version;
        String payload = "{\"title\":" + jsonStr(title) + ",\"body\":" + jsonStr(body)
                + ",\"labels\":[\"plugin-submission\"]}";
        try {
            HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.github.com/repos/" + REGISTRY_REPO + "/issues"))
                    .header("Authorization", "Bearer " + token)
                    .header("Accept", "application/vnd.github+json")
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(30))
                    .POST(HttpRequest.BodyPublishers.ofString(payload, StandardCharsets.UTF_8))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() / 100 != 2) {
                throw new GradleException("GitHub issue creation failed (HTTP " + resp.statusCode() + "): " + resp.body());
            }
            String url = jsonField(resp.body(), "html_url");
            return url != null ? url : ("https://github.com/" + REGISTRY_REPO + "/issues");
        } catch (IOException | InterruptedException e) {
            throw new GradleException("Failed to create the submission issue: " + e.getMessage(), e);
        }
    }

    // ---- small helpers -------------------------------------------------------

    private static String post(HttpClient http, String url, String form) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("Accept", "application/json")
                .header("Content-Type", "application/x-www-form-urlencoded")
                .timeout(Duration.ofSeconds(30))
                .POST(HttpRequest.BodyPublishers.ofString(form)).build();
        return http.send(req, HttpResponse.BodyHandlers.ofString()).body();
    }

    /** Minimal JSON string-field extractor (values are simple strings/ints — no nested parsing needed). */
    private static String jsonField(String json, String field) {
        if (json == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("\"" + java.util.regex.Pattern.quote(field) + "\"\\s*:\\s*\"([^\"]*)\"").matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private static String jsonStr(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "") + "\"";
    }

    private static int parseIntOr(String s, int def) {
        try { return s == null ? def : Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return def; }
    }

    private void exec(String... cmd) {
        if (run(cmd) != 0) throw new GradleException("command failed: " + String.join(" ", cmd));
    }

    private int run(String... cmd) {
        try {
            Process p = new ProcessBuilder(cmd).directory(getProject().getProjectDir()).inheritIO().start();
            return p.waitFor();
        } catch (IOException | InterruptedException e) {
            return -1;
        }
    }

    private String capture(String... cmd) {
        try {
            Process p = new ProcessBuilder(cmd).redirectErrorStream(false).start();
            String out = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            return p.waitFor() == 0 ? out : null;
        } catch (IOException | InterruptedException e) {
            return null;
        }
    }

    private void openBrowser(String url) {
        try {
            if (java.awt.Desktop.isDesktopSupported()) java.awt.Desktop.getDesktop().browse(URI.create(url));
        } catch (Exception ignored) { /* the URL is printed regardless */ }
    }
}
