package io.osrsx.gradle;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.provider.Provider;
import org.gradle.api.tasks.Copy;
import org.gradle.api.tasks.TaskProvider;
import org.gradle.jvm.tasks.Jar;

/**
 * {@code io.osrsx.plugin} — the convention plugin an external osrsx-plugin project applies.
 *
 * <p>Applying it does all the heavy lifting so a plugin project is near-zero-config:
 * <ul>
 *   <li>applies {@code java-library} + the Kotlin JVM plugin (author in Kotlin or plain Java) and pins the
 *       JDK-11 toolchain the client runs on (auto-provisioned by foojay in the template's settings),</li>
 *   <li>wires the anonymous osrsx-maven repo (served over {@code raw.githubusercontent}, no token) +
 *       {@code mavenCentral()} — no {@code mavenLocal},</li>
 *   <li>adds {@code compileOnly "io.osrsx:osrsx-api:<apiVersion>"} + {@code testImplementation
 *       "io.osrsx:osrsx-testkit:<apiVersion>"} — compile against the SDK, unit-test with the harness,</li>
 *   <li>stamps the plugin jar's manifest with id/name/version/api-version (see {@link PluginManifest}) and
 *       generates a {@code plugin.yaml} into the jar (id/name/version/apiVersion/description/authors/tags)
 *       from the {@code osrsxPlugin { }} DSL — the single source of truth, no hand-written manifest,</li>
 *   <li>registers {@code installPlugin} / {@code osrsxRun} / {@code publishPlugin}.</li>
 * </ul>
 * So the author's {@code build.gradle} is just: apply {@code io.osrsx.plugin}, set {@code osrsxPlugin { id }}.
 */
public class OsrsxPluginPlugin implements Plugin<Project> {

    /** Group/artifact of the SDK the plugin compiles against (version is resolved per-project). */
    private static final String SDK_GROUP_ARTIFACT = "io.osrsx:osrsx-api";
    /** The plugin unit-test harness (mocked PluginContext). */
    private static final String SDK_TESTKIT = "io.osrsx:osrsx-testkit";
    /** The osrsx SDK served as a plain Maven repo over raw.githubusercontent — anonymous, no token. */
    private static final String SDK_MAVEN_URL = "https://raw.githubusercontent.com/osrsx/osrsx-maven/main/";
    /** Host plugin directory the client's PluginManager scans on startup. */
    private static final String PLUGINS_DIR = ".osrsx/plugins";
    /** Project property / env var to install into a different plugins dir (e.g. a launcher account home). */
    private static final String INSTALL_DIR_PROPERTY = "osrsx.pluginsDir";
    private static final String INSTALL_DIR_ENV = "OSRSX_PLUGINS_DIR";
    private static final String TASK_GROUP = "osrsx";
    /** The osrsx-org GitHub OAuth app (device flow) publishPlugin signs in with when there's no local gh
     *  token. A client id is public by design — no secret. Override via {@code osrsxPlugin.oauthClientId}. */
    private static final String DEFAULT_OAUTH_CLIENT_ID = "Ov23li8ABEv6l45LTS40";

    @Override
    public void apply(Project project) {
        // java-library (for the `api`/`jar` surface) + Kotlin JVM (so authors write Kotlin without
        // declaring the plugin themselves; plain-Java authors just put sources in src/main/java).
        project.getPluginManager().apply("java-library");
        project.getPluginManager().apply("org.jetbrains.kotlin.jvm");

        // Pin the JDK-11 toolchain the client runs on. Kotlin honours the Java toolchain, so this drives
        // both. When JDK 11 isn't installed, the foojay resolver (wired in the template's settings.gradle)
        // auto-provisions it.
        project.getExtensions().getByType(org.gradle.api.plugins.JavaPluginExtension.class)
                .getToolchain().getLanguageVersion().set(org.gradle.jvm.toolchain.JavaLanguageVersion.of(11));

        // The osrsx SDK repo (anonymous raw Maven) — no mavenLocal. mavenCentral for transitive deps.
        project.getRepositories().maven(r -> {
            r.setName("osrsxSdk");
            r.setUrl(project.uri(SDK_MAVEN_URL));
        });
        project.getRepositories().mavenCentral();

        OsrsxPluginExtension ext = project.getExtensions()
                .create("osrsxPlugin", OsrsxPluginExtension.class);

        // Host-matched defaults so a minimal config only needs `id`.
        String builtAgainstSdk = builtAgainstSdkVersion();
        Provider<String> id = ext.getId();
        Provider<String> name = ext.getName().orElse(ext.getId());
        Provider<String> version = ext.getVersion().orElse(project.provider(() -> project.getVersion().toString()));
        Provider<String> apiVersion = ext.getApiVersion().orElse(builtAgainstSdk);

        addSdkDependency(project, apiVersion);
        stampJarManifest(project, id, name, version, apiVersion);
        generatePluginYaml(project, ext, id, name, version, apiVersion);
        registerInstallTask(project);
        registerRunTask(project);
        registerPublishTask(project, ext, id, version);

        // Let the osrsxPlugin { } block be the single source of truth: if it declares group/version,
        // apply them to the project so the author needn't also write `group`/`version` at the top of the
        // build script. Done in afterEvaluate because the DSL is configured AFTER this plugin applies.
        project.afterEvaluate(p -> {
            if (ext.getGroup().isPresent() && !ext.getGroup().get().isEmpty()) p.setGroup(ext.getGroup().get());
            if (ext.getVersion().isPresent() && !ext.getVersion().get().isEmpty()) p.setVersion(ext.getVersion().get());
        });
    }

    /**
     * Generate {@code plugin.yaml} into the jar from the {@code osrsxPlugin { }} DSL — the single source of
     * truth, so there is no hand-written manifest to drift. Bundled in resources so the host can read the
     * richer metadata (description/authors/tags) beyond the four manifest headers.
     */
    private void generatePluginYaml(Project project, OsrsxPluginExtension ext, Provider<String> id,
                                    Provider<String> name, Provider<String> version, Provider<String> apiVersion) {
        java.io.File outDir = project.getLayout().getBuildDirectory().dir("generated/osrsx-resources").get().getAsFile();
        TaskProvider<?> gen = project.getTasks().register("generatePluginYaml", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Generate plugin.yaml from the osrsxPlugin { } DSL.");
            task.getOutputs().dir(outDir);
            task.doLast(t -> {
                StringBuilder y = new StringBuilder();
                y.append("# generated by io.osrsx.plugin — do not edit; change osrsxPlugin { } in build.gradle\n");
                y.append("id: ").append(orEmpty(id.getOrNull())).append('\n');
                y.append("name: ").append(orEmpty(name.getOrNull())).append('\n');
                y.append("version: ").append(orEmpty(version.getOrNull())).append('\n');
                y.append("apiVersion: ").append(orEmpty(apiVersion.getOrNull())).append('\n');
                String desc = ext.getDescription().getOrElse("");
                if (!desc.isEmpty()) y.append("description: ").append(yamlScalar(desc)).append('\n');
                appendList(y, "authors", ext.getAuthors().getOrElse(java.util.Collections.emptyList()));
                appendList(y, "tags", ext.getTags().getOrElse(java.util.Collections.emptyList()));
                try {
                    outDir.mkdirs();
                    java.nio.file.Files.write(new File(outDir, "plugin.yaml").toPath(),
                            y.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                } catch (IOException e) {
                    throw new org.gradle.api.GradleException("Failed to write plugin.yaml: " + e.getMessage(), e);
                }
            });
        });
        project.getExtensions().getByType(org.gradle.api.tasks.SourceSetContainer.class)
                .getByName("main").getResources().srcDir(outDir);
        project.getTasks().named("processResources").configure(t -> t.dependsOn(gen));
    }

    private static void appendList(StringBuilder y, String key, java.util.List<String> items) {
        if (items.isEmpty()) return;
        y.append(key).append(":\n");
        for (String it : items) y.append("  - ").append(yamlScalar(it)).append('\n');
    }

    private static String orEmpty(String s) { return s == null ? "" : s; }

    /** Quote a scalar if it contains YAML-significant chars, else leave it bare. */
    private static String yamlScalar(String s) {
        if (s.matches("[^:#\\-\\n\"'\\[\\]{}][^:#\\n]*")) return s;
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /** {@code publishPlugin} — submit this plugin to the osrsx registry (see {@link PublishPluginTask}). */
    private void registerPublishTask(Project project, OsrsxPluginExtension ext, Provider<String> id, Provider<String> version) {
        project.getTasks().register("publishPlugin", PublishPluginTask.class, task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Submit this plugin to the osrsx registry: collect release info, push, open the submission issue.");
            task.dependsOn("build");
            task.setPluginId(id.getOrNull());
            task.setVersion(version.getOrNull());
            task.setRepoUrl(gitRemoteUrl(project));
            task.setOauthClientId(ext.getOauthClientId().getOrElse(DEFAULT_OAUTH_CLIENT_ID));
        });
    }

    /** The plugin's GitHub repo URL from {@code git remote origin}, normalised to {@code https://github.com/owner/repo}. */
    private static String gitRemoteUrl(Project project) {
        try {
            Process p = new ProcessBuilder("git", "config", "--get", "remote.origin.url")
                    .directory(project.getProjectDir()).start();
            String out = new String(p.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            if (p.waitFor() != 0 || out.isEmpty()) return null;
            out = out.replaceFirst("\\.git$", "");
            if (out.startsWith("git@github.com:")) out = "https://github.com/" + out.substring("git@github.com:".length());
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * {@code compileOnly "io.osrsx:osrsx-api:<v>"} (the host provides it at runtime) plus
     * {@code testImplementation "io.osrsx:osrsx-testkit:<v>"} (the mocked-PluginContext harness) — both
     * resolved lazily from the extension's apiVersion.
     */
    private void addSdkDependency(Project project, Provider<String> apiVersion) {
        Provider<Dependency> api = apiVersion.map(v -> project.getDependencies().create(SDK_GROUP_ARTIFACT + ":" + v));
        project.getConfigurations().named("compileOnly").configure(c -> c.getDependencies().addLater(api));

        Provider<Dependency> testkit = apiVersion.map(v -> project.getDependencies().create(SDK_TESTKIT + ":" + v));
        project.getConfigurations().named("testImplementation").configure(c -> c.getDependencies().addLater(testkit));
    }

    /**
     * Write id/name/version/api-version into the {@code jar} task's manifest. Done in {@code doFirst}
     * so the extension's lazy providers are resolved (and validated with a friendly message) right
     * before the archive is assembled.
     */
    private void stampJarManifest(Project project, Provider<String> id, Provider<String> name,
                                  Provider<String> version, Provider<String> apiVersion) {
        project.getTasks().named("jar", Jar.class).configure(jar -> jar.doFirst(t -> {
            Map<String, String> attrs = PluginManifest.attributes(
                    id.getOrNull(), name.getOrNull(), version.getOrNull(), apiVersion.getOrNull());
            jar.getManifest().attributes(attrs);
        }));
    }

    /**
     * {@code installPlugin} — copy the built plugin jar into the host's plugins dir. Defaults to
     * {@code ~/.osrsx/plugins}, but can be redirected with {@code -Posrsx.pluginsDir=<dir>} or the
     * {@code OSRSX_PLUGINS_DIR} env var — e.g. a launcher per-account home
     * ({@code ~/.osrsx/homes/<account>/.osrsx/plugins}) to dev against one account. Combine with
     * {@code gradle -t installPlugin} for save→rebuild→hot-reload against a running client.
     */
    private void registerInstallTask(Project project) {
        TaskProvider<Jar> jar = project.getTasks().named("jar", Jar.class);
        File pluginsDir = resolvePluginsDir(project);
        project.getTasks().register("installPlugin", Copy.class, task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Copy the built plugin jar into the host plugins dir (default ~/.osrsx/plugins; "
                    + "override -Posrsx.pluginsDir / $OSRSX_PLUGINS_DIR).");
            task.from(jar.flatMap(Jar::getArchiveFile));
            task.into(pluginsDir);
            task.doLast(t -> t.getLogger().lifecycle("[osrsx] installed plugin jar into {}", pluginsDir));
        });
    }

    /** The plugins dir to install into: {@code -Posrsx.pluginsDir} > {@code $OSRSX_PLUGINS_DIR} > default. */
    private static File resolvePluginsDir(Project project) {
        Object prop = project.findProperty(INSTALL_DIR_PROPERTY);
        if (prop != null && !prop.toString().isEmpty()) {
            return new File(prop.toString().replaceFirst("^~", System.getProperty("user.home")));
        }
        String env = System.getenv(INSTALL_DIR_ENV);
        if (env != null && !env.isEmpty()) {
            return new File(env.replaceFirst("^~", System.getProperty("user.home")));
        }
        return new File(System.getProperty("user.home"), PLUGINS_DIR);
    }

    /**
     * {@code osrsxRun} — installs the jar and prints the zero-friction live-reload dev loop. The client's
     * directory watcher (delivered) hot-reloads a rewritten jar with no restart, so the loop is:
     * launch the client once, then {@code gradle -t installPlugin} rebuilds+reinstalls on every save.
     */
    private void registerRunTask(Project project) {
        project.getTasks().register("osrsxRun", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Install this plugin, then print the live-reload dev loop.");
            task.dependsOn("installPlugin");
            task.doLast(t -> {
                t.getLogger().lifecycle("[osrsx] plugin installed. Live-reload dev loop:");
                t.getLogger().lifecycle("[osrsx]   1) launch the client once (from an osrsx checkout: ./gradlew :osrsx-core:runClient)");
                t.getLogger().lifecycle("[osrsx]   2) in this project:  ./gradlew -t installPlugin");
                t.getLogger().lifecycle("[osrsx]      -> rebuilds + reinstalls on every save; the client hot-reloads it live.");
            });
        });
    }

    /** Read the SDK version this Gradle plugin was built against from the bundled resource. */
    private static String builtAgainstSdkVersion() {
        try (InputStream in = OsrsxPluginPlugin.class.getResourceAsStream("/osrsx-gradle.properties")) {
            if (in == null) {
                return "unspecified";
            }
            Properties props = new Properties();
            props.load(in);
            return props.getProperty("sdk.version", "unspecified");
        } catch (IOException e) {
            return "unspecified";
        }
    }
}
