package io.osrsx.gradle;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.artifacts.Dependency;
import org.gradle.api.provider.Provider;
import org.gradle.api.tasks.Copy;
import org.gradle.api.tasks.TaskProvider;
import org.gradle.jvm.tasks.Jar;

/**
 * {@code io.osrsx.plugin} — the convention plugin an external osrsx-plugin project applies.
 *
 * <p>Applying it does all the heavy lifting so a plugin project is near-zero-config:
 * <ul>
 *   <li>applies {@code java-library} + the Kotlin JVM plugin (author in Kotlin or plain Java) and pins the
 *       JDK-11 toolchain the client runs on (auto-provisioned by foojay in the template's settings),</li>
 *   <li>wires the anonymous osrsx-maven repo (served over {@code raw.githubusercontent}, no token) +
 *       {@code mavenCentral()} — no {@code mavenLocal},</li>
 *   <li>adds {@code compileOnly "io.osrsx:osrsx-api:<apiVersion>"} + {@code testImplementation
 *       "io.osrsx:osrsx-testkit:<apiVersion>"} — compile against the SDK, unit-test with the harness,</li>
 *   <li>stamps the plugin jar's manifest with id/name/version/api-version (see {@link PluginManifest}) and
 *       generates a {@code plugin.yaml} into the jar (id/name/version/apiVersion/description/authors/tags)
 *       from the {@code osrsxPlugin { }} DSL — the single source of truth, no hand-written manifest,</li>
 *   <li>registers {@code installPlugin} / {@code osrsxRun} / {@code publishPlugin}.</li>
 * </ul>
 * So the author's {@code build.gradle} is just: apply {@code io.osrsx.plugin}, set {@code osrsxPlugin { id }}.
 */
public class OsrsxPluginPlugin implements Plugin<Project> {

    /** Group/artifact of the SDK the plugin compiles against (version is resolved per-project). */
    private static final String SDK_GROUP_ARTIFACT = "io.osrsx:osrsx-api";
    /** Maven group library plugins are published under on osrsx-maven — the coordinate a dependent resolves. */
    private static final String LIBRARY_GROUP = "io.osrsx.plugins";
    /** The plugin unit-test harness (mocked PluginContext). Brings Mockito transitively ({@code api}). */
    private static final String SDK_TESTKIT = "io.osrsx:osrsx-testkit";
    /** The JUnit 5 + kotlin-test stack the plugin wires so authors get a working test setup with zero config
     *  (Mockito already arrives via {@link #SDK_TESTKIT}). kotlin-test's version is aligned by the Kotlin plugin. */
    private static final String KOTLIN_TEST = "org.jetbrains.kotlin:kotlin-test-junit5";
    private static final String JUNIT_JUPITER = "org.junit.jupiter:junit-jupiter:5.10.2";
    private static final String JUNIT_PLATFORM_LAUNCHER = "org.junit.platform:junit-platform-launcher:1.10.2";
    /** The osrsx SDK served as a plain Maven repo over raw.githubusercontent — anonymous, no token. */
    private static final String SDK_MAVEN_URL = "https://raw.githubusercontent.com/osrsx/osrsx-maven/main/";
    /** Host plugin directory the client's PluginManager scans on startup. */
    private static final String PLUGINS_DIR = ".osrsx/plugins";
    /** Project property / env var to install into a different plugins dir (e.g. a launcher account home). */
    private static final String INSTALL_DIR_PROPERTY = "osrsx.pluginsDir";
    private static final String INSTALL_DIR_ENV = "OSRSX_PLUGINS_DIR";
    private static final String TASK_GROUP = "osrsx";
    /** The osrsx-org GitHub OAuth app (device flow) publishPlugin signs in with when there's no local gh
     *  token. A client id is public by design — no secret. Override via {@code osrsxPlugin.oauthClientId}. */
    private static final String DEFAULT_OAUTH_CLIENT_ID = "Ov23li8ABEv6l45LTS40";

    @Override
    public void apply(Project project) {
        // java-library (for the `api`/`jar` surface) + Kotlin JVM (so authors write Kotlin without
        // declaring the plugin themselves; plain-Java authors just put sources in src/main/java).
        project.getPluginManager().apply("java-library");
        project.getPluginManager().apply("org.jetbrains.kotlin.jvm");

        // Pin the JDK-17 toolchain the client runs on. Kotlin honours the Java toolchain, so this drives
        // both. When JDK 17 isn't installed, the foojay resolver (wired in the template's settings.gradle)
        // auto-provisions it.
        project.getExtensions().getByType(org.gradle.api.plugins.JavaPluginExtension.class)
                .getToolchain().getLanguageVersion().set(org.gradle.jvm.toolchain.JavaLanguageVersion.of(17));

        // mavenLocal FIRST: a locally-published SDK/library (e.g. one you bumped a version on and
        // `publishToMavenLocal`'d for cross-repo dev) is resolved ahead of the remote. Since ~/.m2 is
        // normally empty of io.osrsx artifacts, this is a no-op for a plain author build and only kicks in
        // once you deliberately publish a local build — bump the version before publishing so the local
        // one wins over what osrsx-maven already serves.
        project.getRepositories().mavenLocal();
        // The osrsx SDK repo (anonymous raw Maven). mavenCentral for transitive deps.
        project.getRepositories().maven(r -> {
            r.setName("osrsxSdk");
            r.setUrl(project.uri(SDK_MAVEN_URL));
        });
        project.getRepositories().mavenCentral();

        OsrsxPluginExtension ext = project.getExtensions()
                .create("osrsxPlugin", OsrsxPluginExtension.class);

        // Host-matched defaults so a minimal config only needs `id`.
        String builtAgainstSdk = builtAgainstSdkVersion();
        Provider<String> id = ext.getId();
        Provider<String> name = ext.getName().orElse(ext.getId());
        Provider<String> version = ext.getVersion().orElse(project.provider(() -> project.getVersion().toString()));
        Provider<String> apiVersion = ext.getApiVersion().orElse(builtAgainstSdk);
        // Supported-SDK range: explicit osrsxPlugin.apiRange, else the same major as apiVersion.
        Provider<String> apiRange = ext.getApiRange().orElse(apiVersion.map(OsrsxPluginPlugin::defaultApiRange));
        // Library flag + declared plugin dependencies (see the LibraryPlugin / requires/optional DSL).
        Provider<Boolean> library = ext.getLibrary().orElse(Boolean.FALSE);
        Provider<java.util.List<String>> requires = ext.getRequires().orElse(java.util.Collections.emptyList());
        Provider<java.util.List<String>> optional = ext.getOptional().orElse(java.util.Collections.emptyList());

        addSdkDependency(project, apiVersion);
        addTestFramework(project);
        addLibraryDependencies(project, ext);
        stampJarManifest(project, ext, id, ext.getMain(), name, version, apiVersion, apiRange, library, requires, optional);
        generatePluginYaml(project, ext, id, name, version, apiVersion, apiRange);
        registerInstallTask(project);
        registerRunTask(project);
        registerPublishRemoteTask(project, ext, id, version);
        configurePublishing(project, ext, id, version);

        // Let the osrsxPlugin { } block be the single source of truth: if it declares group/version,
        // apply them to the project so the author needn't also write `group`/`version` at the top of the
        // build script. Done in afterEvaluate because the DSL is configured AFTER this plugin applies.
        project.afterEvaluate(p -> {
            if (ext.getGroup().isPresent() && !ext.getGroup().get().isEmpty()) p.setGroup(ext.getGroup().get());
            if (ext.getVersion().isPresent() && !ext.getVersion().get().isEmpty()) p.setVersion(ext.getVersion().get());
        });
    }

    /**
     * Generate {@code plugin.yaml} into the jar from the {@code osrsxPlugin { }} DSL — the single source of
     * truth, so there is no hand-written manifest to drift. Bundled in resources so the host can read the
     * richer metadata (description/authors/tags) beyond the four manifest headers.
     */
    private void generatePluginYaml(Project project, OsrsxPluginExtension ext, Provider<String> id,
                                    Provider<String> name, Provider<String> version, Provider<String> apiVersion,
                                    Provider<String> apiRange) {
        java.io.File outDir = project.getLayout().getBuildDirectory().dir("generated/osrsx-resources").get().getAsFile();
        TaskProvider<?> gen = project.getTasks().register("generatePluginYaml", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Generate plugin.yaml from the osrsxPlugin { } DSL.");
            task.getOutputs().dir(outDir);
            task.doLast(t -> {
                StringBuilder y = new StringBuilder();
                y.append("# generated by io.osrsx.plugin — do not edit; change osrsxPlugin { } in build.gradle\n");
                y.append("id: ").append(orEmpty(id.getOrNull())).append('\n');
                String main = orEmpty(ext.getMain().getOrNull());
                if (!main.isEmpty()) y.append("main: ").append(main).append('\n');
                y.append("name: ").append(orEmpty(name.getOrNull())).append('\n');
                y.append("version: ").append(orEmpty(version.getOrNull())).append('\n');
                y.append("apiVersion: ").append(orEmpty(apiVersion.getOrNull())).append('\n');
                String range = orEmpty(apiRange.getOrNull());
                if (!range.isEmpty()) y.append("apiRange: ").append(yamlScalar(range)).append('\n');
                y.append("type: ").append(ext.getLibrary().getOrElse(Boolean.FALSE) ? "library" : "plugin").append('\n');
                String overview = ext.getOverview().getOrElse("");
                if (!overview.isEmpty()) y.append("overview: ").append(yamlScalar(overview)).append('\n');
                String desc = ext.getDescription().getOrElse("");
                if (!desc.isEmpty()) y.append("description: ").append(yamlScalar(desc)).append('\n');
                String iconName = iconResourceName(ext);
                if (iconName != null) y.append("icon: ").append(iconName).append('\n');
                appendList(y, "authors", ext.getAuthors().getOrElse(java.util.Collections.emptyList()));
                appendList(y, "tags", ext.getTags().getOrElse(java.util.Collections.emptyList()));
                if (Boolean.TRUE.equals(ext.getEnabledByDefault().getOrNull())) y.append("enabledByDefault: true\n");
                Integer prio = ext.getDefaultPriority().getOrNull();
                if (prio != null && prio != 0) y.append("priority: ").append(prio.toString()).append('\n');
                appendList(y, "requires", ext.getRequires().getOrElse(java.util.Collections.emptyList()));
                appendList(y, "optional", ext.getOptional().getOrElse(java.util.Collections.emptyList()));
                try {
                    outDir.mkdirs();
                    java.nio.file.Files.write(new File(outDir, "plugin.yaml").toPath(),
                            y.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    // Bundle the icon (if any) at the jar root under the resource name recorded above, so the
                    // host can load it from the classloader and the build worker can extract it for the registry.
                    if (iconName != null) {
                        File src = ext.getIcon().get().getAsFile();
                        if (!src.isFile()) {
                            throw new org.gradle.api.GradleException("osrsxPlugin.icon does not exist: " + src);
                        }
                        java.nio.file.Files.copy(src.toPath(), new File(outDir, iconName).toPath(),
                                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    throw new org.gradle.api.GradleException("Failed to write plugin.yaml: " + e.getMessage(), e);
                }
            });
        });
        project.getExtensions().getByType(org.gradle.api.tasks.SourceSetContainer.class)
                .getByName("main").getResources().srcDir(outDir);
        project.getTasks().named("processResources").configure(t -> t.dependsOn(gen));
    }

    /**
     * The in-jar resource name for the configured icon (e.g. {@code icon.png}), or {@code null} when no icon
     * is set. The extension is taken from the source file (defaulting to {@code png}); the name is stable so
     * {@link #generatePluginYaml} (which copies the file) and {@link #stampJarManifest} (which records it)
     * agree without threading state between the two tasks.
     */
    private static String iconResourceName(OsrsxPluginExtension ext) {
        if (!ext.getIcon().isPresent()) return null;
        String fileName = ext.getIcon().get().getAsFile().getName();
        int dot = fileName.lastIndexOf('.');
        String ext2 = dot > 0 ? fileName.substring(dot + 1).toLowerCase() : "png";
        return "icon." + ext2;
    }

    private static void appendList(StringBuilder y, String key, java.util.List<String> items) {
        if (items.isEmpty()) return;
        y.append(key).append(":\n");
        for (String it : items) y.append("  - ").append(yamlScalar(it)).append('\n');
    }

    private static String orEmpty(String s) { return s == null ? "" : s; }

    /** Quote a scalar if it contains YAML-significant chars, else leave it bare. */
    private static String yamlScalar(String s) {
        if (s.matches("[^:#\\-\\n\"'\\[\\]{}][^:#\\n]*")) return s;
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    /**
     * {@code publishRemote} — submit this plugin to the osrsx registry (see {@link PublishPluginTask}):
     * push the code + tag, then open the submission issue on {@code osrsx/osrsx-central}. Drivable
     * head-less by an agent/CI with {@code --noninteractive --pluginVersion=<v> --changelog="…"}. A thin
     * {@code publishPlugin} alias is kept for back-compat.
     */
    private void registerPublishRemoteTask(Project project, OsrsxPluginExtension ext, Provider<String> id, Provider<String> version) {
        TaskProvider<PublishPluginTask> remote = project.getTasks().register("publishRemote", PublishPluginTask.class, task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Publish REMOTE: push + open the osrsx-central submission issue "
                    + "(--noninteractive --pluginVersion=<v> --changelog=\"…\" for CI/agents).");
            task.dependsOn("build");
            task.setPluginId(id.getOrNull());
            task.setVersion(version.getOrNull());
            task.setRepoUrl(gitRemoteUrl(project));
            task.setOauthClientId(ext.getOauthClientId().getOrElse(DEFAULT_OAUTH_CLIENT_ID));
            // -Paccount=<user> seeds the account; the --account CLI option overrides it.
            Object acct = project.findProperty("account");
            if (acct != null && !acct.toString().isEmpty()) task.setAccount(acct.toString());
        });
        // Back-compat alias — the old task name, now delegating to publishRemote.
        project.getTasks().register("publishPlugin", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Deprecated alias for `publishRemote`.");
            task.dependsOn(remote);
        });
    }

    /**
     * Wire the {@code publishLocal} task: apply {@code maven-publish} and register a publication at
     * {@code io.osrsx.plugins:<id>:<version>} — the exact coordinate a dependent resolves via
     * {@code requires '<id>:<version>'} — then expose {@code publishLocal} as a friendly alias for
     * {@code publishToMavenLocal}. This is the local half of the dev loop: bump a library's version,
     * {@code ./gradlew publishLocal}, and a dependent plugin (which has mavenLocal wired above) compiles
     * against your local build with no remote round-trip. It is primarily meaningful for libraries
     * ({@code osrsxPlugin.library = true}), but registered uniformly so every project has the same task.
     * Configured in {@code afterEvaluate} because the id/version live in the DSL, evaluated after apply.
     */
    private void configurePublishing(Project project, OsrsxPluginExtension ext,
                                     Provider<String> id, Provider<String> version) {
        // Register publishLocal eagerly (string dependsOn is lazy) so it always lists under the osrsx group.
        project.getTasks().register("publishLocal", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Publish LOCAL: install this artifact to ~/.m2 (io.osrsx.plugins:<id>:<version>) "
                    + "for cross-repo dev — bump the version first so it wins over osrsx-maven.");
            task.dependsOn("publishToMavenLocal");
        });
        project.afterEvaluate(p -> {
            p.getPluginManager().apply("maven-publish");
            String artifactId = id.getOrNull();
            String ver = version.getOrNull();
            if (artifactId == null || artifactId.isEmpty()) {
                throw new org.gradle.api.GradleException("osrsxPlugin.id is required to publish.");
            }
            p.getExtensions().configure(org.gradle.api.publish.PublishingExtension.class, publishing ->
                    publishing.getPublications().create("osrsxLibrary",
                            org.gradle.api.publish.maven.MavenPublication.class, pub -> {
                                pub.from(p.getComponents().getByName("java"));
                                pub.setGroupId(LIBRARY_GROUP);
                                pub.setArtifactId(artifactId);
                                pub.setVersion(ver);
                            }));
        });
    }

    /** The plugin's GitHub repo URL from {@code git remote origin}, normalised to {@code https://github.com/owner/repo}. */
    private static String gitRemoteUrl(Project project) {
        try {
            Process p = new ProcessBuilder("git", "config", "--get", "remote.origin.url")
                    .directory(project.getProjectDir()).start();
            String out = new String(p.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8).trim();
            if (p.waitFor() != 0 || out.isEmpty()) return null;
            out = out.replaceFirst("\\.git$", "");
            if (out.startsWith("git@github.com:")) out = "https://github.com/" + out.substring("git@github.com:".length());
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * {@code compileOnly "io.osrsx:osrsx-api:<v>"} (the host provides it at runtime) plus
     * {@code testImplementation "io.osrsx:osrsx-testkit:<v>"} (the mocked-PluginContext harness) — both
     * resolved lazily from the extension's apiVersion.
     */
    private void addSdkDependency(Project project, Provider<String> apiVersion) {
        Provider<Dependency> api = apiVersion.map(v -> project.getDependencies().create(SDK_GROUP_ARTIFACT + ":" + v));
        project.getConfigurations().named("compileOnly").configure(c -> c.getDependencies().addLater(api));

        Provider<Dependency> testkit = apiVersion.map(v -> project.getDependencies().create(SDK_TESTKIT + ":" + v));
        project.getConfigurations().named("testImplementation").configure(c -> c.getDependencies().addLater(testkit));
    }

    /**
     * Wire a batteries-included JUnit 5 test setup so a plugin author can drop test classes in
     * {@code src/test} and run {@code ./gradlew test} with no test config of their own: kotlin-test on the
     * JUnit 5 platform (+ the launcher), with Mockito already provided transitively by {@link #SDK_TESTKIT}.
     */
    private void addTestFramework(Project project) {
        project.getDependencies().add("testImplementation", KOTLIN_TEST);
        project.getDependencies().add("testImplementation", JUNIT_JUPITER);
        project.getDependencies().add("testRuntimeOnly", JUNIT_PLATFORM_LAUNCHER);
        project.getTasks().named("test", org.gradle.api.tasks.testing.Test.class)
                .configure(org.gradle.api.tasks.testing.Test::useJUnitPlatform);
    }

    /**
     * Write id/name/version/api-version into the {@code jar} task's manifest. Done in {@code doFirst}
     * so the extension's lazy providers are resolved (and validated with a friendly message) right
     * before the archive is assembled.
     */
    private void stampJarManifest(Project project, OsrsxPluginExtension ext, Provider<String> id, Provider<String> main,
                                  Provider<String> name, Provider<String> version, Provider<String> apiVersion,
                                  Provider<String> apiRange, Provider<Boolean> library,
                                  Provider<java.util.List<String>> requires, Provider<java.util.List<String>> optional) {
        project.getTasks().named("jar", Jar.class).configure(jar -> jar.doFirst(t -> {
            Map<String, String> attrs = PluginManifest.attributes(
                    id.getOrNull(), name.getOrNull(), version.getOrNull(), apiVersion.getOrNull(), apiRange.getOrNull(),
                    Boolean.TRUE.equals(library.getOrNull()), requires.getOrNull(), optional.getOrNull());
            // The host instantiates this class directly (no annotation/classpath scan) — the obfuscator
            // strips @PluginDescriptor, so the main class MUST come from the manifest. Required for a
            // plugin (omitted for a library).
            String mainClass = main.getOrNull();
            boolean isLibrary = Boolean.TRUE.equals(library.getOrNull());
            if (mainClass != null && !mainClass.trim().isEmpty()) {
                attrs.put(PluginManifest.ATTR_MAIN, mainClass.trim());
            } else if (!isLibrary) {
                throw new org.gradle.api.GradleException("osrsxPlugin.main must be set to the plugin's main "
                        + "class (the io.osrsx.plugin.Plugin subclass), e.g. main = 'io.osrsx.plugins.foo.FooPlugin'");
            }
            // Display metadata that was previously on @PluginDescriptor — the host reads it off the manifest
            // now that the annotation is stripped by the obfuscator. Blank/empty values are omitted.
            putIfSet(attrs, PluginManifest.ATTR_DESCRIPTION, ext.getDescription().getOrNull());
            putIfSet(attrs, PluginManifest.ATTR_OVERVIEW, ext.getOverview().getOrNull());
            putIfSet(attrs, PluginManifest.ATTR_ICON, iconResourceName(ext));
            putIfSet(attrs, PluginManifest.ATTR_AUTHORS, PluginManifest.joinCoords(ext.getAuthors().getOrNull()));
            putIfSet(attrs, PluginManifest.ATTR_TAGS, PluginManifest.joinCoords(ext.getTags().getOrNull()));
            if (Boolean.TRUE.equals(ext.getEnabledByDefault().getOrNull())) {
                attrs.put(PluginManifest.ATTR_ENABLED_DEFAULT, "true");
            }
            Integer priority = ext.getDefaultPriority().getOrNull();
            if (priority != null && priority != 0) attrs.put(PluginManifest.ATTR_PRIORITY, priority.toString());
            jar.getManifest().attributes(attrs);
        }));
    }

    /** Put a trimmed value under {@code key}, skipping null/blank so unset metadata leaves no attribute. */
    private static void putIfSet(Map<String, String> attrs, String key, String value) {
        if (value != null && !value.trim().isEmpty()) attrs.put(key, value.trim());
    }

    /**
     * Add a {@code compileOnly} dependency for each declared {@code requires}/{@code optional} coordinate
     * that carries a version — {@code compileOnly "io.osrsx.plugins:<id>:<version>"}, resolved from the
     * osrsx-maven repo already wired above (a library is published there on registry approval). A bare
     * {@code <id>} with no version is runtime-only (the host provides it), so it gets no compile dep.
     * Done in {@code afterEvaluate} so the DSL lists are fully configured.
     */
    private void addLibraryDependencies(Project project, OsrsxPluginExtension ext) {
        project.afterEvaluate(p -> {
            java.util.List<String> coords = new java.util.ArrayList<>();
            coords.addAll(ext.getRequires().getOrElse(java.util.Collections.emptyList()));
            coords.addAll(ext.getOptional().getOrElse(java.util.Collections.emptyList()));
            for (String coord : coords) {
                if (coord == null) continue;
                String c = coord.trim();
                int colon = c.indexOf(':');
                if (colon < 0) continue; // no version pin — runtime-only, nothing to compile against
                String pid = c.substring(0, colon).trim();
                String ver = c.substring(colon + 1).trim();
                if (pid.isEmpty() || ver.isEmpty()) continue;
                p.getDependencies().add("compileOnly", LIBRARY_GROUP + ":" + pid + ":" + ver);
            }
        });
    }

    /**
     * The default supported-SDK range for a plugin built against {@code apiVersion}: the same major, i.e.
     * {@code [<major>.0.0,<major+1>.0.0)}. Returns "" if the version's major can't be parsed (⇒ no range
     * stamped, host falls back to the coarse major gate).
     */
    static String defaultApiRange(String apiVersion) {
        if (apiVersion == null) return "";
        String core = apiVersion.trim();
        int dash = core.indexOf('-');
        if (dash >= 0) core = core.substring(0, dash);
        String[] parts = core.split("\\.");
        try {
            int major = Integer.parseInt(parts[0]);
            return "[" + major + ".0.0," + (major + 1) + ".0.0)";
        } catch (RuntimeException e) {
            return "";
        }
    }

    /**
     * {@code installPlugin} — copy the built plugin jar into the host's plugins dir. Defaults to
     * {@code ~/.osrsx/plugins}, but can be redirected with {@code -Posrsx.pluginsDir=<dir>} or the
     * {@code OSRSX_PLUGINS_DIR} env var — e.g. a launcher per-account home
     * ({@code ~/.osrsx/homes/<account>/.osrsx/plugins}) to dev against one account. Combine with
     * {@code gradle -t installPlugin} for save→rebuild→hot-reload against a running client.
     */
    private void registerInstallTask(Project project) {
        TaskProvider<Jar> jar = project.getTasks().named("jar", Jar.class);
        File pluginsDir = resolvePluginsDir(project);
        project.getTasks().register("installPlugin", Copy.class, task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Copy the built plugin jar into the host plugins dir (default ~/.osrsx/plugins; "
                    + "override -Posrsx.pluginsDir / $OSRSX_PLUGINS_DIR).");
            task.from(jar.flatMap(Jar::getArchiveFile));
            task.into(pluginsDir);
            task.doLast(t -> t.getLogger().lifecycle("[osrsx] installed plugin jar into {}", pluginsDir));
        });
    }

    /** The plugins dir to install into: {@code -Posrsx.pluginsDir} > {@code $OSRSX_PLUGINS_DIR} > default. */
    private static File resolvePluginsDir(Project project) {
        Object prop = project.findProperty(INSTALL_DIR_PROPERTY);
        if (prop != null && !prop.toString().isEmpty()) {
            return new File(prop.toString().replaceFirst("^~", System.getProperty("user.home")));
        }
        String env = System.getenv(INSTALL_DIR_ENV);
        if (env != null && !env.isEmpty()) {
            return new File(env.replaceFirst("^~", System.getProperty("user.home")));
        }
        return new File(System.getProperty("user.home"), PLUGINS_DIR);
    }

    /**
     * {@code osrsxRun} — installs the jar and prints the zero-friction live-reload dev loop. The client's
     * directory watcher (delivered) hot-reloads a rewritten jar with no restart, so the loop is:
     * launch the client once, then {@code gradle -t installPlugin} rebuilds+reinstalls on every save.
     */
    private void registerRunTask(Project project) {
        project.getTasks().register("osrsxRun", task -> {
            task.setGroup(TASK_GROUP);
            task.setDescription("Install this plugin, then print the live-reload dev loop.");
            task.dependsOn("installPlugin");
            task.doLast(t -> {
                t.getLogger().lifecycle("[osrsx] plugin installed. Live-reload dev loop:");
                t.getLogger().lifecycle("[osrsx]   1) launch the client once (from an osrsx checkout: ./gradlew :osrsx-core:runClient)");
                t.getLogger().lifecycle("[osrsx]   2) in this project:  ./gradlew -t installPlugin");
                t.getLogger().lifecycle("[osrsx]      -> rebuilds + reinstalls on every save; the client hot-reloads it live.");
            });
        });
    }

    /** Read the SDK version this Gradle plugin was built against from the bundled resource. */
    private static String builtAgainstSdkVersion() {
        try (InputStream in = OsrsxPluginPlugin.class.getResourceAsStream("/osrsx-gradle.properties")) {
            if (in == null) {
                return "unspecified";
            }
            Properties props = new Properties();
            props.load(in);
            return props.getProperty("sdk.version", "unspecified");
        } catch (IOException e) {
            return "unspecified";
        }
    }
}
