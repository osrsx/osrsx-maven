package io.osrsx.gradle;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The manifest contract between a plugin jar built by the {@code io.osrsx.plugin} Gradle plugin and the
 * host's {@code PluginManager} (Phase 2/4 consumer).
 *
 * <p>The four fields are written as {@code MANIFEST.MF} main attributes. The attribute names below are
 * the stable contract — the host reads exactly these keys off {@code JarFile.getManifest()}:
 *
 * <pre>
 *   Osrsx-Plugin-Id:       stable identifier, e.g. "my-woodcutter"
 *   Osrsx-Plugin-Name:     human display name
 *   Osrsx-Plugin-Version:  the plugin's own version
 *   Osrsx-Api-Version:     the io.osrsx:osrsx-api version it was compiled against
 *   Osrsx-Api-Range:       the SDK versions it supports (Maven/NeoForge range) — optional
 * </pre>
 *
 * <p>Kept as a pure, dependency-free function so it is unit-testable without a Gradle build.
 */
public final class PluginManifest {

    public static final String ATTR_ID = "Osrsx-Plugin-Id";
    /** Fully-qualified main-class name (the concrete {@code Plugin} subclass the host instantiates). Absent
     *  on library jars. Read directly by the host, so discovery needs no annotation/classpath scan. */
    public static final String ATTR_MAIN = "Osrsx-Plugin-Main";
    public static final String ATTR_NAME = "Osrsx-Plugin-Name";
    public static final String ATTR_VERSION = "Osrsx-Plugin-Version";
    public static final String ATTR_API_VERSION = "Osrsx-Api-Version";
    public static final String ATTR_API_RANGE = "Osrsx-Api-Range";
    /** {@code plugin} (default) or {@code library}. The host renders + resolves libraries differently. */
    public static final String ATTR_TYPE = "Osrsx-Plugin-Type";
    /** Short human description (the removed {@code @PluginDescriptor.description}). Omitted when blank. */
    public static final String ATTR_DESCRIPTION = "Osrsx-Plugin-Description";
    /** One-line overview shown in the marketplace list (shorter than {@link #ATTR_DESCRIPTION}). Omitted when blank. */
    public static final String ATTR_OVERVIEW = "Osrsx-Plugin-Overview";
    /** In-jar resource path of the plugin icon (e.g. {@code icon.png}), bundled at the jar root. Omitted when none. */
    public static final String ATTR_ICON = "Osrsx-Plugin-Icon";
    /** Comma-separated author(s). Omitted when none. */
    public static final String ATTR_AUTHORS = "Osrsx-Plugin-Authors";
    /** Comma-separated category tags. Omitted when none. */
    public static final String ATTR_TAGS = "Osrsx-Plugin-Tags";
    /** {@code true} if the host auto-enables on first discovery. Omitted (⇒ false) when not set. */
    public static final String ATTR_ENABLED_DEFAULT = "Osrsx-Plugin-Enabled-Default";
    /** Integer default load/UI priority. Omitted (⇒ 0) when not set. */
    public static final String ATTR_PRIORITY = "Osrsx-Plugin-Priority";
    /** Comma-separated required-dependency coordinates {@code <id>[:<range>]}. Absent when none. */
    public static final String ATTR_REQUIRES = "Osrsx-Plugin-Requires";
    /** Comma-separated optional-dependency coordinates {@code <id>[:<range>]}. Absent when none. */
    public static final String ATTR_OPTIONAL = "Osrsx-Plugin-Optional";

    /** The {@code Osrsx-Plugin-Type} value for an ordinary plugin. */
    public static final String TYPE_PLUGIN = "plugin";
    /** The {@code Osrsx-Plugin-Type} value for a library plugin. */
    public static final String TYPE_LIBRARY = "library";

    private PluginManifest() {
    }

    /**
     * Build the ordered map of manifest main attributes for a plugin jar. Blank/null values are
     * rejected: an unstamped plugin jar would be indistinguishable from an ordinary library, so the
     * caller must supply every field.
     */
    public static Map<String, String> attributes(String id, String name, String version, String apiVersion) {
        Map<String, String> attrs = new LinkedHashMap<>();
        attrs.put(ATTR_ID, require(id, "id"));
        attrs.put(ATTR_NAME, require(name, "name"));
        attrs.put(ATTR_VERSION, require(version, "version"));
        attrs.put(ATTR_API_VERSION, require(apiVersion, "apiVersion"));
        return attrs;
    }

    /**
     * As {@link #attributes(String, String, String, String)} plus the optional {@code Osrsx-Api-Range}.
     * A blank/null range is simply omitted (the host then falls back to the coarse major-version gate).
     */
    public static Map<String, String> attributes(String id, String name, String version, String apiVersion, String apiRange) {
        Map<String, String> attrs = attributes(id, name, version, apiVersion);
        if (apiRange != null && !apiRange.trim().isEmpty()) attrs.put(ATTR_API_RANGE, apiRange.trim());
        return attrs;
    }

    /**
     * The full attribute set including the {@code library}/dependency contract. {@code type} defaults to
     * {@code plugin} when null/blank; {@code requires}/{@code optional} are comma-joined and omitted when
     * empty (so an ordinary plugin with no dependencies is byte-identical to the pre-dependency manifest,
     * bar the always-present {@code Osrsx-Plugin-Type}).
     */
    public static Map<String, String> attributes(String id, String name, String version, String apiVersion,
                                                  String apiRange, boolean library,
                                                  List<String> requires, List<String> optional) {
        Map<String, String> attrs = attributes(id, name, version, apiVersion, apiRange);
        attrs.put(ATTR_TYPE, library ? TYPE_LIBRARY : TYPE_PLUGIN);
        String req = joinCoords(requires);
        if (!req.isEmpty()) attrs.put(ATTR_REQUIRES, req);
        String opt = joinCoords(optional);
        if (!opt.isEmpty()) attrs.put(ATTR_OPTIONAL, opt);
        return attrs;
    }

    /** Trim, drop blanks, and comma-join dependency coordinates (empty string when none). */
    static String joinCoords(List<String> coords) {
        if (coords == null) return "";
        return coords.stream()
                .filter(c -> c != null && !c.trim().isEmpty())
                .map(String::trim)
                .collect(Collectors.joining(","));
    }

    private static String require(String value, String field) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("osrsxPlugin." + field + " must be set");
        }
        return value.trim();
    }
}
