package io.osrsx.gradle;

import org.gradle.api.file.RegularFileProperty;
import org.gradle.api.provider.ListProperty;
import org.gradle.api.provider.Property;

/**
 * The {@code osrsxPlugin { ... }} DSL an author configures in their plugin project's build script:
 *
 * <pre>
 *   osrsxPlugin {
 *       id = "my-woodcutter"          // required — stable plugin identifier
 *       name = "My Woodcutter"         // defaults to id
 *       // version    — defaults to project.version
 *       // apiVersion — defaults to the osrsx-api version this Gradle plugin was built against
 *   }
 * </pre>
 *
 * <p>{@code version} and {@code apiVersion} have host-matched defaults, so a minimal config sets only
 * {@code id}. The four resolved values become the plugin jar's manifest attributes (see
 * {@link PluginManifest}).
 */
public abstract class OsrsxPluginExtension {

    /** Stable plugin identifier written to {@code Osrsx-Plugin-Id}. Required. */
    public abstract Property<String> getId();

    /**
     * Fully-qualified name of the plugin's main class — the concrete {@code io.osrsx.plugin.Plugin} subclass
     * the host instantiates — written to {@code Osrsx-Plugin-Main} and {@code plugin.yaml}. Required for a
     * plugin (omit for a library). The host loads this class directly instead of scanning for the
     * (being-removed) {@code @PluginDescriptor} annotation, which also works when the jar is delivered
     * encrypted and loaded from a non-scannable in-memory classloader (#227).
     */
    public abstract Property<String> getMain();

    /** Human display name written to {@code Osrsx-Plugin-Name}. Defaults to {@link #getId()}. */
    public abstract Property<String> getName();

    /**
     * The plugin's own version, written to {@code Osrsx-Plugin-Version}. When set, it also becomes the
     * project's version (so you don't repeat {@code version = '…'} at the top of the build script). If
     * unset, it defaults to {@code project.version}.
     */
    public abstract Property<String> getVersion();

    /**
     * The Maven group / package namespace. When set, it becomes the project's {@code group} (so you don't
     * repeat {@code group = '…'} at the top of the build script). Cosmetic for the jar; unset ⇒ whatever
     * {@code project.group} is.
     */
    public abstract Property<String> getGroup();

    /**
     * The {@code io.osrsx:osrsx-api} SDK version this plugin compiles against, written to
     * {@code Osrsx-Api-Version}. Defaults to the SDK version this Gradle plugin was built against, and
     * is also the coordinate used for the injected {@code compileOnly} dependency.
     */
    public abstract Property<String> getApiVersion();

    /**
     * The SDK versions this plugin SUPPORTS, as a Maven/NeoForge range written to {@code Osrsx-Api-Range}
     * and the generated {@code plugin.yaml} — the marketplace only offers this plugin version to clients
     * whose {@code SdkInfo.API_VERSION} satisfies the range. Syntax: inclusive {@code [ ]} / exclusive
     * {@code ( )} bounds, an empty side is unbounded, comma-separated sets union — e.g.
     * {@code [0.1.0,0.2.0)}, {@code [1.2.0,)}, {@code [1.0.0,1.1.0),(1.2.0,)}. Defaults to the same major as
     * {@link #getApiVersion()} (e.g. api {@code 0.1.5} ⇒ {@code [0.0.0,1.0.0)}).
     */
    public abstract Property<String> getApiRange();

    /** Short human description of the plugin — bundled into the generated {@code plugin.yaml}. */
    public abstract Property<String> getDescription();

    /**
     * One-line overview shown in the marketplace list (shorter than {@link #getDescription()}), written to
     * {@code Osrsx-Plugin-Overview} + {@code plugin.yaml}. For a MANUAL release the dev portal's overview is
     * authoritative; a NIGHTLY build falls back to this manifest value.
     */
    public abstract Property<String> getOverview();

    /**
     * Optional plugin icon — a small square image (PNG recommended) bundled into the jar at its root as
     * {@code icon.<ext>} and recorded in {@code Osrsx-Plugin-Icon} + {@code plugin.yaml}. Shown in the
     * marketplace. Like {@link #getOverview()}, the dev-portal icon is authoritative for manual releases;
     * nightly builds fall back to this bundled icon. Example: {@code icon = file("src/main/resources/icon.png")}.
     */
    public abstract RegularFileProperty getIcon();

    /** Plugin author(s) — bundled into the generated {@code plugin.yaml}. */
    public abstract ListProperty<String> getAuthors();

    /** Category tags (e.g. skilling, combat) — bundled into the generated {@code plugin.yaml}. */
    public abstract ListProperty<String> getTags();

    /**
     * Whether the host auto-enables this plugin on first discovery (before the user has toggled it),
     * written to {@code Osrsx-Plugin-Enabled-Default} + {@code plugin.yaml}. Replaces the removed
     * {@code @PluginDescriptor.enabledByDefault} — the obfuscator strips annotations, so this must come
     * off the manifest. Defaults to {@code false}.
     */
    public abstract Property<Boolean> getEnabledByDefault();

    /**
     * The plugin's default load/UI priority (higher sorts first), written to {@code Osrsx-Plugin-Priority}
     * + {@code plugin.yaml}. Replaces the removed {@code @PluginDescriptor.defaultPriority}. Defaults to 0.
     */
    public abstract Property<Integer> getDefaultPriority();

    /**
     * Mark this plugin as a <b>library</b> (written to {@code Osrsx-Plugin-Type: library}). A library is a
     * normal plugin whose purpose is to provide shared code/services other plugins depend on: on registry
     * approval it is additionally published to the osrsx Maven repo so dependents can {@code compileOnly}
     * it. Defaults to {@code false} (an ordinary plugin, {@code Osrsx-Plugin-Type: plugin}). The plugin's
     * class should also implement {@code io.osrsx.plugin.LibraryPlugin}.
     */
    public abstract Property<Boolean> getLibrary();

    /**
     * Plugins this plugin <b>requires</b> — usually libraries. Each entry is {@code "<id>"} or
     * {@code "<id>:<version>"}; a version pins the {@code compileOnly} dependency
     * ({@code io.osrsx.plugins:<id>:<version>}) resolved from the osrsx Maven repo, and seeds the runtime
     * {@code Osrsx-Plugin-Requires} manifest range. When a required library is disabled at runtime, the
     * host disables this plugin too (after confirming with the user). Prefer the {@link #requires(String...)}
     * helper.
     */
    public abstract ListProperty<String> getRequires();

    /**
     * Plugins this plugin can <b>optionally</b> use if present. Same coordinate form as {@link #getRequires()},
     * written to {@code Osrsx-Plugin-Optional}. An optional dependency is never force-installed and its
     * absence/disable never cascades — the plugin guards its own usage. Prefer {@link #optional(String...)}.
     */
    public abstract ListProperty<String> getOptional();

    /** Append required-dependency coordinates ({@code "<id>:<version>"}). See {@link #getRequires()}. */
    public void requires(String... coordinates) {
        getRequires().addAll(coordinates);
    }

    /** Append optional-dependency coordinates ({@code "<id>[:<version>]"}). See {@link #getOptional()}. */
    public void optional(String... coordinates) {
        getOptional().addAll(coordinates);
    }

    /**
     * Optional GitHub OAuth app client id used by {@code publishPlugin}'s device-flow sign-in when no
     * local {@code gh} CLI token is present. Unset ⇒ {@code publishPlugin} falls back to a token typed
     * into the dialog. (Register an OAuth app under your org and set its client id here.)
     */
    public abstract Property<String> getOauthClientId();
}
