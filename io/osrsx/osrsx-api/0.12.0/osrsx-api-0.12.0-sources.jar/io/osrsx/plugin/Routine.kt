package io.osrsx.plugin

import io.osrsx.api.Events
import io.osrsx.api.Profiler
import io.osrsx.api.Subscription
import io.osrsx.api.events.ClientTick
import io.osrsx.api.events.GameTick
import io.osrsx.api.section

/**
 * One rung of a routine's decision ladder, evaluated against a per-tick snapshot [C]. A [Step] is a guard
 * ([applies]) plus the work it gates ([run]) — the same "condition + action" shape as [Task], but both halves
 * receive the same immutable snapshot the [Routine] sensed once at the top of the tick, so every step in a
 * ladder sees one coherent view of the game instead of each re-reading it.
 *
 * [run] returns ms-until-next-loop — the same contract as [Plugin.onLoop] / [Task.execute] ([Plugin.NO_LOOP]
 * to stop the plugin). Both lambdas run with [C] as their receiver (`this`), so a step body reads the snapshot's
 * fields unqualified (`{ !invFull }`) and still calls the enclosing routine's own methods (`{ mine() }`) — a
 * context-free step just ignores the receiver.
 *
 * Build one tersely with the [step] factory inside a [routine] block. Pure — no engine types.
 */
interface Step<C> {
    /** Short label — the [Routine] shows it as the plugin's status and uses it as the profiler span name
     *  while this step runs, so status and instrumentation can never drift apart. */
    val name: String

    /** Whether this step is eligible this tick, given the sensed [snapshot]. Keep it cheap and side-effect
     *  free — it's polled in priority order every tick until one returns true. */
    fun applies(snapshot: C): Boolean

    /** Do the work; return ms until the next loop (or [Plugin.NO_LOOP] to stop). */
    fun run(snapshot: C): Long
}

/**
 * Build a [Step] from lambdas — `step("Mine", { !invFull }) { mine() }`. Both lambdas take the snapshot as
 * their receiver, so `this` is the sensed [C]; ignore it for a context-free step.
 */
fun <C> step(name: String, applies: C.() -> Boolean, run: C.() -> Long): Step<C> {
    val taskName = name
    val cond = applies
    val body = run
    return object : Step<C> {
        override val name: String = taskName
        override fun applies(snapshot: C): Boolean = snapshot.cond()
        override fun run(snapshot: C): Long = snapshot.body()
    }
}

/**
 * Where — and on which thread — a [Routine] builds its per-tick snapshot.
 *
 * - [LOOP] (default): the snapshot is sensed inline on the plugin's own loop thread, once per [Routine.tick].
 *   Simplest; reads marshall onto the client thread like any other loop read. Right for turn-based automation
 *   (skilling) where one batched read per loop is plenty.
 * - [GAME_TICK] / [CLIENT_TICK]: the [Routine] subscribes to that event and senses **on the client thread** as
 *   it fires, publishing an immutable snapshot the loop then reads. The reads are therefore **coherent** (all
 *   from the same tick, no tearing) and **marshall-free** (already on the client thread). [GAME_TICK] fires
 *   ~600 ms; [CLIENT_TICK] fires every rendered frame (~20 ms) for reactive automation (combat/bossing) that
 *   must notice sub-tick changes. These modes require an [Events] bus and a matching [Routine.stop] on teardown.
 */
enum class SenseOn { LOOP, GAME_TICK, CLIENT_TICK }

/**
 * A prioritized [Step] runner a plugin (or a routine object it holds) drives from `onLoop` — the richer sibling
 * of [TaskScript]. Each tick it:
 *
 *  1. runs [beforeTick] (an always-run side effect — run-energy management, input-lock upkeep, …),
 *  2. runs the first eligible [guards] entry, if any (context-free short-circuits — login, break, stop-target,
 *     auto-dialogue, antiban idle — the "prologue" every bot repeats). A guard is a plain [Step] over [Unit],
 *     so it needs no snapshot; crucially it runs **before** [sense], so a heavy/side-effecting sense (an
 *     inventory read, a `gearUp()` that banks) never fires while logged out or on a break,
 *  3. otherwise builds ONE snapshot [C] via [sense] and runs the first eligible domain [step][Step],
 *
 * setting the plugin status to the chosen step's name and timing it under a `"$spanPrefix/${name}"` profiler
 * span — so the status label and the span are always the same string and can't drift. When nothing applies it
 * returns [idleDelay].
 *
 * **The snapshot is the point.** Sensing once and handing the result to every step replaces the twin
 * hand-rolled patterns this codebase grew independently: the "take one inventory snapshot per loop, then a big
 * guarded `when`" ladders, and the "`@Volatile` pre-compute on a ClientTick handler that the loop reads"
 * combat loops. Pick the sensing thread with [senseOn]; the driver owns the `@Volatile` publish and the event
 * subscription so authors don't. Keep policy (which guards, which antiban) out of any base class and in the
 * routine you build here — the SDK stays engine- and policy-free.
 *
 * ```
 * private val routine = routine<Inv>(ctx.profiler(), "miner", { senseInv() }, status = { stats.status = it }) {
 *     beforeEach { walking.manageRun() }                                   // always-run upkeep
 *     guard("login",  { !login.isLoggedIn() })   { login.login(); 1500 }   // prologue — runs before sense()
 *     guard("break",  { breaks.onBreak() })      { Rng.uniform(2000, 5000) }
 *     step("mining",  { !full })                 { mine() }                 // domain — `full` is a snapshot field
 *     step("banking", { bankWanted })            { bankOre() }
 * }
 * ```
 *
 * A [RoutinePlugin] drives one of these with no boilerplate: `override fun routine() = this.routine`.
 */
class Routine<C>(
    private val profiler: Profiler,
    private val spanPrefix: String,
    private val sense: () -> C,
    private val steps: List<Step<C>>,
    private val status: ((String) -> Unit)? = null,
    private val idleDelay: () -> Long = { 600 },
    private val senseOn: SenseOn = SenseOn.LOOP,
    private val events: Events? = null,
    private val beforeTick: () -> Unit = {},
    private val guards: List<Step<Unit>> = emptyList(),
) {
    /** Holds the latest client-thread-sensed snapshot for the tick modes. A null box means "not sensed yet";
     *  a non-null box may still wrap a null [C], so the box distinguishes the two. Published on the client
     *  thread ([GAME_TICK]/[CLIENT_TICK] handler), read on the loop thread — hence `@Volatile`. */
    private class Box<C>(val value: C)

    @Volatile private var box: Box<C>? = null
    private var sub: Subscription? = null

    /** Run one tick: [beforeTick] upkeep, then the first eligible guard (before sensing), then the first
     *  eligible domain step against a freshly-built snapshot — labelling status + timing whichever runs, or
     *  returning the idle delay when nothing applies (or, in a tick-sense mode, until the first snapshot lands). */
    fun tick(): Long {
        beforeTick()
        guards.firstOrNull { it.applies(Unit) }?.let { return dispatch(it, Unit) }
        val snapshot: C = when (senseOn) {
            SenseOn.LOOP -> sense()
            else -> { ensureSubscribed(); (box ?: return idleDelay()).value }
        }
        val step = steps.firstOrNull { it.applies(snapshot) } ?: return idleDelay()
        return dispatch(step, snapshot)
    }

    private fun <T> dispatch(step: Step<T>, snapshot: T): Long {
        status?.invoke(step.name)
        return profiler.section("$spanPrefix/${step.name}") { step.run(snapshot) }
    }

    /** The step (guard or domain) that would run now, or null if none apply. Senses inline regardless of
     *  [senseOn] — for tests / introspection, not the hot path. */
    fun next(): Step<*>? {
        guards.firstOrNull { it.applies(Unit) }?.let { return it }
        val snapshot = box?.value ?: sense()
        return steps.firstOrNull { it.applies(snapshot) }
    }

    /** Tear down the tick-mode subscription. Safe to call always (a no-op for [SenseOn.LOOP]); call it from the
     *  plugin's `onStop`. Idempotent. */
    fun stop() {
        sub?.unsubscribe()
        sub = null
        box = null
    }

    private fun ensureSubscribed() {
        if (sub != null || senseOn == SenseOn.LOOP) return
        val bus = events ?: error("Routine '$spanPrefix' senses on $senseOn but was given no Events bus")
        // The handler runs on the client thread as the event fires: sensing here is coherent and marshall-free.
        sub = when (senseOn) {
            SenseOn.GAME_TICK -> bus.on(GameTick::class.java) { _ -> box = Box(sense()) }
            SenseOn.CLIENT_TICK -> bus.on(ClientTick::class.java) { _ -> box = Box(sense()) }
            SenseOn.LOOP -> null
        }
    }
}

/** Collects [Step]s (and guards / the before-tick hook) in priority order for the [routine] builder. */
class RoutineBuilder<C> {
    internal val steps = mutableListOf<Step<C>>()
    internal val guards = mutableListOf<Step<Unit>>()
    internal var beforeTick: () -> Unit = {}

    /** Register a domain step (lowest priority so far). Both lambdas take the snapshot as receiver — see [step]. */
    fun step(name: String, applies: C.() -> Boolean, run: C.() -> Long) {
        steps += io.osrsx.plugin.step(name, applies, run)
    }

    /** Register a pre-built domain [step] (lowest priority so far). */
    fun add(step: Step<C>) {
        steps += step
    }

    /**
     * Register a **guard** — a context-free short-circuit that runs in priority order BEFORE the snapshot is
     * sensed (login, break, stop-target, auto-dialogue, antiban idle …). If it applies, it runs and the tick
     * ends. Guards keep the "prologue" in the routine (and out of any base class), and running them before
     * [sense] means a side-effecting sense never fires while logged out / on a break.
     */
    fun guard(name: String, applies: () -> Boolean, run: () -> Long) {
        guards += io.osrsx.plugin.step<Unit>(name, { applies() }, { run() })
    }

    /** Set the always-run per-tick side effect (run-energy management, input-lock upkeep, …). Runs first, every
     *  tick, before guards and sense; it never short-circuits. */
    fun beforeEach(block: () -> Unit) {
        beforeTick = block
    }
}

/**
 * Build a [Routine] whose steps share a sensed snapshot [C]. [sense] runs once per tick (on the thread chosen by
 * [senseOn]), AFTER any guard has had its chance; its result is handed to every step. See [Routine] for the model.
 */
fun <C> routine(
    profiler: Profiler,
    spanPrefix: String,
    sense: () -> C,
    status: ((String) -> Unit)? = null,
    idleDelay: () -> Long = { 600 },
    senseOn: SenseOn = SenseOn.LOOP,
    events: Events? = null,
    build: RoutineBuilder<C>.() -> Unit,
): Routine<C> {
    val b = RoutineBuilder<C>().apply(build)
    return Routine(profiler, spanPrefix, sense, b.steps, status, idleDelay, senseOn, events, b.beforeTick, b.guards)
}

/**
 * Build a context-free [Routine] (snapshot is [Unit]) — the simple case that just wants named, self-labelling,
 * self-timing steps (and maybe guards) with no shared snapshot. Step/guard lambdas ignore the [Unit] receiver.
 */
fun routine(
    profiler: Profiler,
    spanPrefix: String,
    status: ((String) -> Unit)? = null,
    idleDelay: () -> Long = { 600 },
    build: RoutineBuilder<Unit>.() -> Unit,
): Routine<Unit> = routine(profiler, spanPrefix, sense = {}, status = status, idleDelay = idleDelay, build = build)

/**
 * A [Plugin] whose whole behaviour is a single [Routine]: the minimal base for routine-driven plugins, the way
 * [TaskPlugin] is for [Task] lists. It bakes in only the **universal wiring** — drive the routine each loop,
 * stop it on teardown — and deliberately **no policy**: login, breaks, antiban idle, input-lock, coordination
 * and dialogue handling are not methods here. They live in the routine you build (as [RoutineBuilder.guard]s
 * and [RoutineBuilder.beforeEach]), so the SDK stays engine- and policy-free and every plugin composes exactly
 * the prologue it wants.
 *
 * ```
 * class MinerPlugin : RoutinePlugin(), HasOverlay {
 *     override fun routine() = if (Config.isMotherlode) motherlode.routine else normal.routine
 * }
 * ```
 *
 * [routine] is called every loop, so it MAY switch on config (e.g. normal vs Motherlode) — return a cached
 * instance (a `by lazy` val), don't allocate one per call. Override [onStop] (calling `super.onStop()`) for any
 * extra teardown, such as releasing an input lock the routine's `beforeEach` applied.
 */
abstract class RoutinePlugin : Plugin() {
    /** The routine to drive this tick. Called every loop; return a cached instance (may switch on config). */
    protected abstract fun routine(): Routine<*>

    final override fun onLoop(): Long = routine().tick()

    override fun onStop() {
        routine().stop()
    }
}
