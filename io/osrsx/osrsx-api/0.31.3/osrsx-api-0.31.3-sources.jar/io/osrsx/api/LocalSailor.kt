package io.osrsx.api


/**
 * Scene-local sailing — hull-aware manoeuvring WITHIN the loaded scene, reactively routing around live
 * hazards (rocks, whirlpools, sea monsters) and, once landed, collision objects. The sea counterpart of
 * [LocalWalker]; for a destination beyond the scene use [GlobalSailor], which delegates each leg here.
 *
 * Unlike walking you do not click tiles: [pathTo] plans a hull-legal path and then steers by HEADING and
 * SAILS toward it, re-planning each control step as hazards move. A path a player could walk may be
 * impossible for a boat — the hull footprint and turning radius are part of the search, so a gap narrower
 * than the beam or a turn tighter than the radius simply isn't a path.
 *
 * Requires being aboard a boat ([Sailor.isOnBoat]); [pathTo] returns false otherwise.
 *
 * **Staging note.** Sailing is beta content and this tier is being built out. Today [pathTo] accepts
 * destinations in or near the loaded scene and drives them with a scene-bounded hull-aware plan; the
 * reactive hazard-detour logic still also runs inside [GlobalSailor] as a splice over its route. Those two
 * converge as the composition inverts — [GlobalSailor] will drive this tier for every leg. The CONTRACT
 * here is settled; only the internals move.
 *
 * @since 0.28.0
 */
interface LocalSailor : Navigator<LocalSailConfig, SailEvent> {
    override val defaultConfig: LocalSailConfig get() = LocalSailConfig.DEFAULT

    /**
     * The currently planned local path as tile waypoints (for overlays), or null when idle. Reflects the
     * live plan including any hazard detour in force.
     */
    fun path(): List<Tile>? = null

    /**
     * True when the tier has found a hazard ahead with NO safe way around and is holding station rather
     * than sailing into it. Distinct from [NavPhase.STUCK] (wedged and trying to recover) — this is a
     * deliberate, controlled hold.
     */
    fun isHolding(): Boolean = false

    /**
     * Follow a FIXED ordered course of [waypoints] directly, bypassing route planning — for a preset path
     * such as a Barracuda-trial racing line, where the course is authored/known rather than searched. The
     * reactive collision steering, hazard detour and arrival logic still apply, so the boat dodges obstacles
     * while tracking the line. Unlike [pathTo] this takes a whole path, not a destination, and does NOT plan
     * over the collision map — the waypoints ARE the route.
     *
     * Self-driving: call ONCE (not per loop); it runs to the last waypoint and then reports
     * [SailEvent.Arrived] to [listener]. Uses [config]'s `arriveRadius` for the final waypoint. Returns false
     * if not aboard or given fewer than two waypoints.
     *
     * @since 0.31.3
     */
    fun sailAlong(
        waypoints: List<Tile>,
        config: LocalSailConfig = defaultConfig,
        listener: (SailEvent) -> Unit = {},
    ): Boolean = false
}

/**
 * How [LocalSailor.pathTo] manoeuvres. Defaults reproduce the tuned behaviour of the existing local tier.
 */
data class LocalSailConfig(
    /** Dock/arrive when within this many tiles of the destination — boats are multi-tile and rarely land on
     *  an exact square, so this is meaningfully larger than a walker's. */
    val arriveRadius: Int = 2,
    /** Tiles of clearance kept between the hull and a known hazard when planning a detour. Raise it in
     *  cluttered water at the cost of finding fewer routes. */
    val hazardBuffer: Int = 1,
    /** How far ahead along the plan to scan for hazards each control step. */
    val hazardLookahead: Int = 12,
    /** Delay between control steps, in ms. Lower reacts faster to moving hazards and costs more CPU. */
    val stepMs: Long = 250,
    /** Making no way for this long ⇒ [NavPhase.STUCK] and an un-wedging reverse. */
    val stuckMs: Long = 6_000,
    /** Give up (emit [SailEvent.Failed]) after this long without arriving. 0 = never time out. */
    val timeoutMs: Long = 120_000,
    /** Allow the un-wedging reverse manoeuvre when lodged on an obstacle the static map doesn't carry. */
    val allowReverse: Boolean = true,
) {
    companion object {
        /** The tuned defaults. */
        val DEFAULT = LocalSailConfig()

        /** Cluttered/hazardous water — wider clearance, longer lookahead, faster control steps. */
        val CAUTIOUS = LocalSailConfig(hazardBuffer = 2, hazardLookahead = 20, stepMs = 150)
    }
}

/**
 * What a sailing navigation reports. Shared by [LocalSailor] and [GlobalSailor] — the global tier adds
 * [Planned] and [LegStarted]; the rest come from whichever tier is steering.
 */
sealed interface SailEvent : NavEvent {
    /** Sailing to [dest] began from [from]. */
    data class Started(override val dest: Tile, val from: Tile) : SailEvent
    /** A hull-aware route was planned with [waypoints] waypoints. */
    data class Planned(override val dest: Tile, val waypoints: Int) : SailEvent
    /** The global plan handed off a leg ending at [legEnd] to the local tier. */
    data class LegStarted(override val dest: Tile, val legEnd: Tile) : SailEvent
    /** Steering toward [target] on heading [heading] (0..15). */
    data class Steering(override val dest: Tile, val target: Tile, val heading: Int) : SailEvent
    /** Routing around a hazard: a detour of [tiles] tiles was spliced in, rejoining the plan afterwards. */
    data class Rerouted(override val dest: Tile, val around: Tile, val tiles: Int) : SailEvent
    /** A hazard blocks the way ahead with no safe route around it — holding station at [at]. */
    data class Holding(override val dest: Tile, val at: Tile, val reason: String) : SailEvent
    /** Lodged at [at] and making no way; reversing off to recover. */
    data class Stuck(override val dest: Tile, val at: Tile, val reason: String) : SailEvent
    /** No hull-legal route to [dest] exists ([diagnosis] from the pathfinder — often a beam/turn-radius
     *  constraint rather than genuinely closed water). */
    data class Unreachable(override val dest: Tile, val diagnosis: String) : SailEvent
    /** A generic diagnostic message. */
    data class Info(override val dest: Tile, val message: String) : SailEvent
    /** Docked at [dest], hull at [at]. */
    data class Arrived(override val dest: Tile, val at: Tile) : SailEvent
    /** Gave up ([reason] explains — not aboard, timed out, or no route). */
    data class Failed(override val dest: Tile, val reason: String) : SailEvent
}
