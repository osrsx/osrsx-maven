/**
 * Typesafe, engine-free catalogs of Old School RuneScape game ids.
 *
 * Every object in this package is **generated** from RuneLite's cache-derived id tables
 * (`net.runelite.api.gameval.*`) by `tools/generate_game_ids.py`, and re-emitted as pure
 * Kotlin `const val Int`s. This lets a plugin reference an id by name — with no
 * `net.runelite.*` dependency on the SDK surface — while the backing value stays exactly
 * the raw in-game id:
 *
 * ```kotlin
 * import io.osrsx.ids.Items
 * import io.osrsx.ids.Npcs
 *
 * inventory.getItem(Items.ABYSSAL_WHIP)      // 4151
 * npcs.closest(Npcs.GOBLIN)
 * ```
 *
 * ### The catalogs
 * - [Items] — item ids. Noted and bank-placeholder variants live under [Items.Cert] and
 *   [Items.Placeholder] (same names, the noted/placeholder id).
 * - [Npcs], [Objects] (+ [Objects2]) — scene entity ids. [Objects] is split across two
 *   objects only because its table exceeds the JVM's 65535 constant-pool limit per class.
 * - [Interfaces] — interface group ids at the top level, with a nested object per interface
 *   holding its component ids (packed `group shl 16 or child`, matching `Widget.id`).
 * - [Sprites] — sprite ids (top-level + a nested object per UI group).
 * - [Varbits], [VarPlayers] — the varbit / VarPlayer ids read via `Varps`.
 * - [Animations] — animation ids.
 * - [Inventories] — inventory container ids.
 *
 * ### Why `const val Int`, not `enum`
 * The largest tables (items ~33k, objects ~32k, interfaces ~27k) are far past the ~2-3k
 * constant ceiling where a Kotlin/Java `enum` still compiles (the JVM caps a class's
 * `<clinit>` at 64KB). A `const val Int` is a compile-time constant — inlined at the use
 * site with no initializer code — so it scales to tens of thousands at zero runtime cost.
 *
 * These files are checked in; re-run the generator when RuneLite's tables update.
 */
package io.osrsx.ids
