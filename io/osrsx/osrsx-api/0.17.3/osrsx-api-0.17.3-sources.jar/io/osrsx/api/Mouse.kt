package io.osrsx.api

import java.awt.Dimension
import java.awt.Point

/**
 * Low-level control of the humanised virtual cursor — the escape hatch for plugins that need precise,
 * reaction-time mouse control the ordinary [SceneEntity.interact] path can't express: homing a moving
 * target's on-screen hull, dwell-gating a click, aborting a move mid-flight when a telegraph fires, or
 * parking the cursor on a specific tile to dodge. Obtained from [PluginContext.mouse].
 *
 * Most plugins should NOT use this — prefer [SceneEntity.interact] / [Walking] / [Combat], which pick and
 * click menu options for you. This surface exists for reaction-fight automation (boss triggerbots) that
 * genuinely needs pixel-level cursor control. All coordinates are game-canvas pixels; moves are generated
 * by the client's humanised mouse-path engine (never a teleport).
 */
interface Mouse {

    /** The cursor's current position on the game canvas. */
    val position: Point

    /** The game canvas size in pixels (for choosing on-screen points, e.g. a camera-recenter drag). */
    fun canvasSize(): Dimension

    /** Humanised move to (`x`, `y`) on the canvas. */
    fun moveTo(x: Int, y: Int)

    /** Humanised move to [p]. */
    fun moveTo(p: Point) = moveTo(p.x, p.y)

    /** Click at the current cursor position ([LEFT] by default). */
    fun click(button: Int = LEFT)

    /** Move to (`x`, `y`) and click ([LEFT] by default). */
    fun click(x: Int, y: Int, button: Int = LEFT)

    /** Raise the abort flag so an in-flight [moveTo]/[moveTracking] bails at its next step. */
    fun abortMove()

    /** Clear the abort flag before a move that must complete (e.g. the dodge step itself). */
    fun clearAbort()

    /** Run [block] as one atomic cursor gesture (serialised against other cursor operations). */
    fun <T> gesture(block: () -> T): T

    /** Run [block] at a hurried, reaction-time pace (skips the leisurely inter-move dwell). */
    fun <T> withHurry(block: () -> T): T

    /**
     * Track a moving target for [durationMs], continuously aiming the humanised cursor at the freshest
     * point [target] returns (it's re-queried with the remaining ms as the boss keeps moving). [hitTest]
     * can early-exit the moment the cursor is over the target; [dwellMs] holds on-target before returning.
     * Returns true if it locked onto (a non-null [target]) within the window.
     */
    fun moveTracking(
        durationMs: Long,
        minStepMs: Long = 5L,
        dwellMs: Long = 0L,
        hitTest: (Point) -> Boolean = { false },
        target: (remMs: Double) -> Point?,
    ): Boolean

    companion object {
        /** Left mouse button. */
        const val LEFT = 1
        /** Right mouse button. */
        const val RIGHT = 3
    }
}
