package io.osrsx.api

import io.osrsx.api.TransportKind.AGILITY_SHORTCUT
import io.osrsx.api.TransportKind.BOAT
import io.osrsx.api.TransportKind.CHARTER_SHIP
import io.osrsx.api.TransportKind.FAIRY_RING
import io.osrsx.api.TransportKind.GNOME_GLIDER
import io.osrsx.api.TransportKind.HOT_AIR_BALLOON
import io.osrsx.api.TransportKind.MAGIC_CARPET
import io.osrsx.api.TransportKind.MINECART
import io.osrsx.api.TransportKind.MINIGAME_TELEPORT
import io.osrsx.api.TransportKind.MUSHTREE
import io.osrsx.api.TransportKind.QUETZAL
import io.osrsx.api.TransportKind.SPIRIT_TREE
import io.osrsx.api.TransportKind.TELEPORT_ITEM
import io.osrsx.api.TransportKind.TELEPORT_SPELL
import io.osrsx.api.TransportKind.WILDERNESS_OBELISK

/**
 * Type-safe builder DSL for [WalkConfig] — the ergonomic way to shape a walk. Transport control is
 * organised by FAMILY blocks, each with the same verbs (`all()` / `none()` / `only(...)` / `include(...)`
 * / `exclude(...)`); everything else (detour policy, run, ranking, timing, …) reads as plain statements.
 *
 * ```
 * val cfg = walkConfig {
 *     teleports {
 *         all()                          // or none()
 *         exclude("Home")                // never home-teleport (substring, case-insensitive)
 *         spells { none() }              // …but ban spell teleports specifically
 *         items  { include("glory") }    // force-allow amulet of glory
 *     }
 *     minigames {
 *         none()
 *         include("Castle Wars")         // …except Castle Wars
 *     }
 *     fairyRings { all() }
 *     boats { none() }
 *     shortcuts { all() }
 *
 *     detour(true)                       // bank runs on
 *     grandExchange(false)
 *     preferTeleports()                  // or conserveResources()
 *     runHumanized()                     // or runAlways() / runNever() / runAbove(50)
 *     stamina(threshold = 25)
 *     arriveWithin(2)
 *
 *     ranking     { teleportMinCost = 15 }
 *     banks       { maxBanksProbed = 12 }
 *     exclusion   { reverseCooldownMs = 8000 }
 *     pathfinding { approachRadius = 20 }
 *     timing      { teleportConfirmMs = 12000 }
 * }
 * ```
 */
@OsrsxDsl
class WalkConfigBuilder(base: WalkConfig = WalkConfig.DEFAULT) {

    private val disabledKinds = base.disabledKinds.toMutableSet()
    private val forceAllow = base.forceAllowTransports.toMutableSet()
    private val forceDeny = base.blacklistedTransports.toMutableSet()
    private val whitelist = base.allowedTransports.toMutableSet()

    // Plain top-level statements.
    var allowPlantedSpiritTrees: Boolean = base.allowPlantedSpiritTrees
    var allowBankRuns: Boolean = base.allowBankRuns
    var allowGrandExchange: Boolean = base.allowGrandExchange
    var useStaminaPotions: Boolean = base.useStaminaPotions
    var staminaThreshold: Int = base.staminaThreshold
    var runPolicy: RunPolicy = base.runPolicy
    var pathfindTimeoutMs: Long = base.pathfindTimeoutMs
    var arriveRadius: Int = base.arriveRadius

    // Ranking (flat so `walkConfig { teleportMinCost = 15 }` works; the maps are filled by prefer()/avoid()/cost()).
    var teleportMinCost: Int = base.ranking.teleportMinCost
    var homeTeleportCost: Int = base.ranking.homeTeleportCost
    private val kindCost = base.ranking.kindCost.toMutableMap()
    private val transportCost = base.ranking.transportCost.toMutableMap()

    private var detour = base.detour
    private var exclusion = base.exclusion
    private var pathfinding = base.pathfinding
    private var timing = base.timing

    // ── internal hooks the family / ranking scopes call ──
    internal fun ban(kinds: Set<TransportKind>) { disabledKinds.addAll(kinds) }
    internal fun unban(kinds: Set<TransportKind>) { disabledKinds.removeAll(kinds) }
    internal fun allow(names: Array<out String>) { forceAllow.addAll(names) }
    internal fun deny(names: Array<out String>) { forceDeny.addAll(names) }
    internal fun rankKind(kinds: Set<TransportKind>, cost: Int) { kinds.forEach { kindCost[it] = cost } }
    internal fun rankTransport(name: String, cost: Int) { transportCost[name] = cost }

    // ── Transport family blocks ──
    /** Item + spell teleports. Has [TeleportScope.spells]/[TeleportScope.items] sub-blocks. */
    fun teleports(block: TeleportScope.() -> Unit) { TeleportScope(this).apply(block) }
    /** Minigame-group teleports (Castle Wars, Clan Wars, …). */
    fun minigames(block: FamilyScope.() -> Unit) { FamilyScope(setOf(MINIGAME_TELEPORT), this).apply(block) }
    fun fairyRings(block: FamilyScope.() -> Unit) { FamilyScope(setOf(FAIRY_RING), this).apply(block) }
    fun boats(block: FamilyScope.() -> Unit) { FamilyScope(setOf(BOAT), this).apply(block) }
    fun charters(block: FamilyScope.() -> Unit) { FamilyScope(setOf(CHARTER_SHIP), this).apply(block) }
    fun shortcuts(block: FamilyScope.() -> Unit) { FamilyScope(setOf(AGILITY_SHORTCUT), this).apply(block) }
    fun spiritTrees(block: FamilyScope.() -> Unit) { FamilyScope(setOf(SPIRIT_TREE), this).apply(block) }
    fun gliders(block: FamilyScope.() -> Unit) { FamilyScope(setOf(GNOME_GLIDER), this).apply(block) }
    fun balloons(block: FamilyScope.() -> Unit) { FamilyScope(setOf(HOT_AIR_BALLOON), this).apply(block) }
    fun carpets(block: FamilyScope.() -> Unit) { FamilyScope(setOf(MAGIC_CARPET), this).apply(block) }
    fun mushtrees(block: FamilyScope.() -> Unit) { FamilyScope(setOf(MUSHTREE), this).apply(block) }
    fun minecarts(block: FamilyScope.() -> Unit) { FamilyScope(setOf(MINECART), this).apply(block) }
    fun quetzals(block: FamilyScope.() -> Unit) { FamilyScope(setOf(QUETZAL), this).apply(block) }
    fun obelisks(block: FamilyScope.() -> Unit) { FamilyScope(setOf(WILDERNESS_OBELISK), this).apply(block) }

    // ── Whole-map gating shortcuts ──
    /** Walk on foot only — ban all fast travel (doors/gates/stairs + agility shortcuts still used). */
    fun onlyOnFoot() { disabledKinds.addAll(TransportKind.FAST_TRAVEL) }
    /** Ban every teleport family (item/spell/minigame). */
    fun noTeleports() { disabledKinds.addAll(TransportKind.TELEPORTS) }
    /** Re-enable every family. */
    fun allowEverything() { disabledKinds.clear() }

    // ── Detour / GE / spirit-tree toggles ──
    fun detour(enabled: Boolean = true) { allowBankRuns = enabled }
    fun grandExchange(enabled: Boolean = true) { allowGrandExchange = enabled }
    fun plantedSpiritTrees(enabled: Boolean = true) { allowPlantedSpiritTrees = enabled }

    // ── Ranking shortcuts ──
    /** Aggressively prefer teleports — teleport for almost any non-trivial hop. */
    fun preferTeleports() { teleportMinCost = 1 }
    /** Conserve charges/runes — only teleport when it saves a lot of walking. */
    fun conserveResources() { teleportMinCost = 150 }

    // ── Run / stamina ──
    fun runAlways() { runPolicy = RunPolicy.Always }
    fun runNever() { runPolicy = RunPolicy.Never }
    fun runHumanized() { runPolicy = RunPolicy.Humanized }
    fun runAbove(percent: Int) { runPolicy = RunPolicy.AboveEnergy(percent) }
    /** Drink stamina/energy potions when energy is at/below [threshold]. */
    fun stamina(threshold: Int = 20) { useStaminaPotions = true; staminaThreshold = threshold }

    // ── Arrival ──
    fun arriveWithin(radius: Int) { arriveRadius = radius }

    // ── Numeric knob blocks ──
    fun ranking(block: RankingScope.() -> Unit) { RankingScope(this).apply(block) }
    fun banks(block: BanksScope.() -> Unit) { detour = BanksScope(detour).apply(block).build() }
    fun exclusion(block: ExclusionScope.() -> Unit) { exclusion = ExclusionScope(exclusion).apply(block).build() }
    fun pathfinding(block: PathfindingScope.() -> Unit) { pathfinding = PathfindingScope(pathfinding).apply(block).build() }
    fun timing(block: TimingScope.() -> Unit) { timing = TimingScope(timing).apply(block).build() }

    fun build(): WalkConfig = WalkConfig(
        disabledKinds = disabledKinds.toSet(),
        blacklistedTransports = forceDeny.toSet(),
        forceAllowTransports = forceAllow.toSet(),
        allowedTransports = whitelist.toSet(),
        allowPlantedSpiritTrees = allowPlantedSpiritTrees,
        allowBankRuns = allowBankRuns,
        allowGrandExchange = allowGrandExchange,
        useStaminaPotions = useStaminaPotions,
        staminaThreshold = staminaThreshold,
        runPolicy = runPolicy,
        pathfindTimeoutMs = pathfindTimeoutMs,
        arriveRadius = arriveRadius,
        ranking = RankingConfig(teleportMinCost, homeTeleportCost, kindCost.toMap(), transportCost.toMap()),
        detour = detour,
        exclusion = exclusion,
        pathfinding = pathfinding,
        timing = timing,
    )
}

/**
 * Verbs shared by every transport-family block. `all()`/`none()` toggle the whole family; `include`/
 * `exclude` force-allow/deny by name (case-insensitive substring); `only(...)` bans the family then
 * re-allows just the named ones.
 */
@OsrsxDsl
open class FamilyScope internal constructor(
    private val kinds: Set<TransportKind>,
    @PublishedApi internal val b: WalkConfigBuilder,
) {
    /** Allow this whole family. */
    fun all() { b.unban(kinds) }
    /** Ban this whole family. */
    fun none() { b.ban(kinds) }
    /** Ban the family, then allow ONLY these named transports within it. */
    fun only(vararg names: String) { b.ban(kinds); b.allow(names) }
    /** Force-allow these named transports (even if the family is banned). */
    fun include(vararg names: String) { b.allow(names) }
    /** Never use these named transports. */
    fun exclude(vararg names: String) { b.deny(names) }
    /** Force-allow one transport by name. */
    infix fun include(name: String) { b.allow(arrayOf(name)) }
    /** Never use one transport by name. */
    infix fun exclude(name: String) { b.deny(arrayOf(name)) }

    // ── ranking (this whole family) ──
    /** Set the routing cost for every transport in this family (lower = more preferred). */
    fun cost(value: Int) { b.rankKind(kinds, value) }
    /** Strongly prefer this family (cheap cost) — taken whenever it's available. */
    fun prefer() { cost(RankingConfig.PREFER) }
    /** Avoid this family (expensive) — used only when nothing cheaper reaches the goal. */
    fun avoid() { cost(RankingConfig.AVOID) }
}

/** The [WalkConfigBuilder.teleports] block: family verbs for item+spell teleports, plus sub-blocks. */
@OsrsxDsl
class TeleportScope internal constructor(b: WalkConfigBuilder) :
    FamilyScope(setOf(TELEPORT_ITEM, TELEPORT_SPELL), b) {
    /** Just spell teleports (any spellbook). */
    fun spells(block: FamilyScope.() -> Unit) { FamilyScope(setOf(TELEPORT_SPELL), b).apply(block) }
    /** Just item teleports (tablets + jewellery). */
    fun items(block: FamilyScope.() -> Unit) { FamilyScope(setOf(TELEPORT_ITEM), b).apply(block) }
    /** Readable alias for force-allowing a spell teleport by name. */
    fun includeSpell(vararg names: String) = include(*names)
    /** Readable alias for force-allowing an item teleport (tab/jewellery) by name. */
    fun includeItem(vararg names: String) = include(*names)
}

/**
 * The `ranking { }` block — set the teleport floors and rank ANY family or individual transport.
 * ```
 * ranking {
 *     teleportMinCost = 15
 *     kind(TransportKind.FAIRY_RING, cost = 5)   // whole family
 *     transport("Fairy ring DKR", cost = 1)      // one transport, by name
 *     prefer("Camelot teleport")                 // = very cheap
 *     avoid("Ardougne teleport")                 // = expensive / last resort
 * }
 * ```
 */
@OsrsxDsl
class RankingScope internal constructor(private val b: WalkConfigBuilder) {
    var teleportMinCost: Int
        get() = b.teleportMinCost
        set(v) { b.teleportMinCost = v }
    var homeTeleportCost: Int
        get() = b.homeTeleportCost
        set(v) { b.homeTeleportCost = v }
    /** Set the routing cost for a whole [TransportKind] family. */
    fun kind(kind: TransportKind, cost: Int) { b.rankKind(setOf(kind), cost) }
    /** Set the routing cost for specific transports by name (case-insensitive substring). */
    fun transport(name: String, cost: Int) { b.rankTransport(name, cost) }
    /** Strongly prefer these transports (cheap) by name. */
    fun prefer(vararg names: String) { names.forEach { b.rankTransport(it, RankingConfig.PREFER) } }
    /** Avoid these transports (expensive / last resort) by name. */
    fun avoid(vararg names: String) { names.forEach { b.rankTransport(it, RankingConfig.AVOID) } }
}

@OsrsxDsl
class BanksScope internal constructor(c: DetourConfig) {
    var maxBanksProbed = c.maxBanksProbed
    var bankProbeMs = c.bankProbeMs
    var localDetourFactor = c.localDetourFactor
    var localDetourSlack = c.localDetourSlack
    internal fun build() = DetourConfig(maxBanksProbed, bankProbeMs, localDetourFactor, localDetourSlack)
}

@OsrsxDsl
class ExclusionScope internal constructor(c: ExclusionConfig) {
    var reverseCooldownMs = c.reverseCooldownMs
    var transportFailLimit = c.transportFailLimit
    var crossMissLimit = c.crossMissLimit
    var transportExcludeMs = c.transportExcludeMs
    var homeTeleportCooldownMs = c.homeTeleportCooldownMs
    var minigameTeleportCooldownMs = c.minigameTeleportCooldownMs
    internal fun build() = ExclusionConfig(
        reverseCooldownMs, transportFailLimit, crossMissLimit,
        transportExcludeMs, homeTeleportCooldownMs, minigameTeleportCooldownMs,
    )
}

@OsrsxDsl
class PathfindingScope internal constructor(c: PathfindingConfig) {
    var nearRadius = c.nearRadius
    var waypointArriveRadius = c.waypointArriveRadius
    var approachRadius = c.approachRadius
    var shortcutReach = c.shortcutReach
    var reachProbeMs = c.reachProbeMs
    var searchBudgetMs = c.searchBudgetMs
    internal fun build() = PathfindingConfig(
        nearRadius, waypointArriveRadius, approachRadius, shortcutReach, reachProbeMs, searchBudgetMs,
    )
}

@OsrsxDsl
class TimingScope internal constructor(c: TimingConfig) {
    var approachMsPerTile = c.approachMsPerTile
    var openBaseMs = c.openBaseMs
    var crossConfirmMs = c.crossConfirmMs
    var teleportConfirmMs = c.teleportConfirmMs
    var teleportArriveRadius = c.teleportArriveRadius
    internal fun build() = TimingConfig(approachMsPerTile, openBaseMs, crossConfirmMs, teleportConfirmMs, teleportArriveRadius)
}

/** Build a [WalkConfig] with the DSL, starting from [base] (default: [WalkConfig.DEFAULT]). */
fun walkConfig(base: WalkConfig = WalkConfig.DEFAULT, block: WalkConfigBuilder.() -> Unit): WalkConfig =
    WalkConfigBuilder(base).apply(block).build()

/** Return a copy of this config edited through the DSL — e.g. `WalkConfig.FASTEST.edit { detour(false) }`. */
fun WalkConfig.edit(block: WalkConfigBuilder.() -> Unit): WalkConfig =
    WalkConfigBuilder(this).apply(block).build()
