package io.osrsx.plugin

/**
 * A plugin capability: contribute a **custom sidebar menu item** to the osrsx editor. The plugin gets its
 * own entry in the left icon rail — placed in a separate plugin section below the built-in Plugins /
 * Marketplace / Logs items — that opens a docked, lockable, width-resizable panel exactly like the
 * built-in ones.
 *
 * Distinct from the other UI capabilities — pick the one that fits:
 * - [HasMenu]     — a first-class **sidebar flyout** with its own rail icon (this one).
 * - [HasPaint]    — a window docked into the central editor dockspace.
 * - [HasPanel]    — a read-only RuneLite data box (draggable stats overlay).
 * - [HasOverlay]  — a floating, alt-draggable in-game overlay.
 *
 * The panel opens **locked** by default: docked flush to the rail with a padlock in its header. Unlock it
 * (the padlock) to float it as a free window; drag a locked panel's right edge to resize it. Only one
 * *locked* menu — across every plugin's menus and the built-in ones — is open at a time; unlocked panels
 * are unconstrained. The rail item follows the plugin's enabled state by default (appears when enabled,
 * disappears when disabled) unless [MenuItem.visible] overrides that.
 *
 * ```
 * class Fisher : Plugin(), HasMenu {
 *     private var caught = 0
 *     override fun menu() = MenuItem("Fisher", MenuIcon.FISH, defaultWidth = 320f)
 *     override fun onMenu(gui: ScriptGui) {
 *         gui.text("Fish caught: $caught")
 *         if (gui.button("Reset")) caught = 0
 *     }
 * }
 * ```
 */
interface HasMenu {
    /**
     * This menu's descriptor — icon, label, default width, lock and visibility. Read fresh each frame on
     * the render thread, so keep it cheap; [MenuItem.title]/[MenuItem.icon]/[MenuItem.visible] may vary
     * frame to frame, while [MenuItem.defaultWidth]/[MenuItem.lockedByDefault] only seed initial state.
     */
    fun menu(): MenuItem

    /**
     * Render this menu's panel body for the current frame into the engine-managed sidebar window (called
     * every frame on the render thread — keep it quick and immediate-mode, like [HasPaint.onPaint]).
     */
    fun onMenu(gui: ScriptGui)
}
