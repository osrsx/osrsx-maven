package io.osrsx.plugin

/**
 * Descriptor for a plugin's [HasMenu] sidebar item — its entry in the osrsx editor's left icon rail.
 *
 * [title] labels the rail icon (tooltip when the rail is collapsed, and the row label when it is expanded)
 * and heads the panel; [icon] is the rail glyph. [defaultWidth] is the initial docked width in logical px.
 * [lockedByDefault] seeds the padlock: `true` (the default) opens the panel *locked* — docked flush to the
 * rail, its right edge draggable to resize — while unlocking floats it as a free window. [visible]
 * controls whether the item appears at all: `null` (the default) follows the plugin's enabled state (shown
 * when enabled, hidden when disabled), `true` always shows it, `false` never does.
 *
 * [defaultWidth] and [lockedByDefault] are *seed* values — read only until the user first resizes or
 * re-locks the panel, after which their persisted choice wins. [title], [icon] and [visible] are read live
 * each frame, so a plugin may vary them dynamically (e.g. hide the menu while idle, or relabel it).
 *
 * ```
 * override fun menu() = MenuItem("Fisher", MenuIcon.FISH, defaultWidth = 320f)
 * ```
 */
data class MenuItem(
    val title: String,
    val icon: MenuIcon = MenuIcon.PUZZLE,
    val defaultWidth: Float = 340f,
    val lockedByDefault: Boolean = true,
    val visible: Boolean? = null,
)
