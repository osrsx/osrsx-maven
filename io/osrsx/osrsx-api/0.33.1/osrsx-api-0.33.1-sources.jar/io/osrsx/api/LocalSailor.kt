package io.osrsx.api


/**
 * Scene-local sailing — hull-aware manoeuvring WITHIN the loaded scene, reactively routing around live
 * hazards (rocks, whirlpools, sea monsters) and, once landed, collision objects. The sea counterpart of
 * [LocalWalker]; for a destination beyond the scene use [GlobalSailor], which delegates each leg here.
 *
 * Unlike walking you do not click tiles: [pathTo] plans a hull-legal path and then steers by HEADING and
 * SAILS toward it, re-planning each control step as hazards move. A path a player could walk may be
 * impossible for a boat — the hull footprint and turning radius are part of the search, so a gap narrower
 * than the beam or a turn tighter than the radius simply isn't a path.
 *
 * Requires being aboard a boat ([Sailor.isOnBoat]); [pathTo] returns false otherwise.
 *
 * **Staging note.** Sailing is beta content and this tier is being built out. Today [pathTo] accepts
 * destinations in or near the loaded scene and drives them with a scene-bounded hull-aware plan; the
 * reactive hazard-detour logic still also runs inside [GlobalSailor] as a splice over its route. Those two
 * converge as the composition inverts — [GlobalSailor] will drive this tier for every leg. The CONTRACT
 * here is settled; only the internals move.
 *
 * @since 0.28.0
 */
interface LocalSailor : Navigator<LocalSailConfig, SailEvent> {
    override val defaultConfig: LocalSailConfig get() = LocalSailConfig.DEFAULT

    /**
     * The currently planned local path as tile waypoints (for overlays), or null when idle. Reflects the
     * live plan including any hazard detour in force.
     */
    fun path(): List<Tile>? = null

    /**
     * True when the tier has found a hazard ahead with NO safe way around and is holding station rather
     * than sailing into it. Distinct from [NavPhase.STUCK] (wedged and trying to recover) — this is a
     * deliberate, controlled hold.
     */
    fun isHolding(): Boolean = false

    /**
     * Follow a FIXED ordered course of [waypoints] directly, bypassing route planning — for a preset path
     * such as a Barracuda-trial racing line, where the course is authored/known rather than searched. The
     * reactive collision steering, hazard detour and arrival logic still apply, so the boat dodges obstacles
     * while tracking the line. Unlike [pathTo] this takes a whole path, not a destination, and does NOT plan
     * over the collision map — the waypoints ARE the route.
     *
     * Self-driving: call ONCE (not per loop); it runs to the last waypoint and then reports
     * [SailEvent.Arrived] to [listener]. Uses [config]'s `arriveRadius` for the final waypoint. Returns false
     * if not aboard or given fewer than two waypoints.
     *
     * @since 0.31.3
     */
    fun sailAlong(
        waypoints: List<Tile>,
        config: LocalSailConfig = defaultConfig,
        listener: (SailEvent) -> Unit = {},
    ): Boolean = false

    /**
     * PRECISE, discrete navigation to [dest] — the boat's hull ends ON that tile — by explicit stop-turn-move
     * maneuvers, with this tier's flowing behaviour (pure-pursuit steering, reactive collision avoidance, turn
     * smoothing) turned OFF. The boat comes to a STOP before every turn (it doesn't translate while rotating),
     * rotates straight to the needed heading, then creeps each straight run at slow speed. For threading into a
     * tight berth or landing exactly on a spot where the flowing navigator would cut the corner or have its
     * ±22.5° corner probes veto the approach.
     *
     * Distinct from [pathTo]: [pathTo] flows a hull-aware route with the safety wheels ON (right for open
     * water); this executes an exact, collision-checked maneuver sequence with them OFF (right for tight,
     * deliberate positioning). Self-driving — call ONCE; observe via [state], a listener, or `awaitArrival`.
     * Returns false if not aboard or no maneuver path exists.
     *
     * @since 0.33.0
     */
    fun preciseTo(dest: Tile, config: PreciseSailConfig = PreciseSailConfig.DEFAULT, listener: (SailEvent) -> Unit = {}): Boolean = false

    /**
     * Compute and execute the exact maneuvers to get the boat OUT of a wedge — from where it sits (even a pose
     * the map calls illegal) to the nearest open water it can set off from. The non-naïve replacement for a
     * blind astern reverse: it drives FORWARD out when that's the clear way (e.g. open water is ahead),
     * reverses only when needed, and turns in place between runs. Self-driving. Returns false if not aboard or
     * no escape exists within range.
     *
     * @since 0.33.0
     */
    fun unwedge(config: PreciseSailConfig = PreciseSailConfig.DEFAULT, listener: (SailEvent) -> Unit = {}): Boolean = false
}

/**
 * How the PRECISE scene navigator ([LocalSailor.preciseTo] / [LocalSailor.unwedge]) plans and moves. Its
 * constraints are deliberately DIFFERENT from the flowing [LocalSailConfig]: no reactive avoidance, no turn
 * smoothing, stop-turn-move, slow speed — the manual, exact counterpart to the global tier's safety wheels.
 *
 * @since 0.33.0
 */
data class PreciseSailConfig(
    /** Allow astern maneuvers in the plan (needed to back out of a wedge; forward-only otherwise). */
    val allowReverse: Boolean = true,
    /** Give up (emit [SailEvent.Failed]) after this long without arriving. 0 = never. */
    val timeoutMs: Long = 60_000,
) {
    companion object {
        /** Tuned defaults: reverse allowed, slow controlled creep. */
        val DEFAULT = PreciseSailConfig()

        /** Forward-only precise positioning (no astern) — for berthing where reversing isn't wanted. */
        val FORWARD_ONLY = PreciseSailConfig(allowReverse = false)
    }
}

/**
 * How [LocalSailor.pathTo] manoeuvres. Defaults reproduce the tuned behaviour of the existing local tier.
 */
data class LocalSailConfig(
    /** Dock/arrive when within this many tiles of the destination — boats are multi-tile and rarely land on
     *  an exact square, so this is meaningfully larger than a walker's. */
    val arriveRadius: Int = 2,
    /** Tiles of clearance kept between the hull and a known hazard when planning a detour. Raise it in
     *  cluttered water at the cost of finding fewer routes. */
    val hazardBuffer: Int = 1,
    /** How far ahead along the plan to scan for hazards each control step. */
    val hazardLookahead: Int = 12,
    /** Delay between control steps, in ms. Lower reacts faster to moving hazards and costs more CPU. */
    val stepMs: Long = 250,
    /** Making no way for this long ⇒ [NavPhase.STUCK] and an un-wedging reverse. */
    val stuckMs: Long = 6_000,
    /** Give up (emit [SailEvent.Failed]) after this long without arriving. 0 = never time out. */
    val timeoutMs: Long = 120_000,
    /** Allow the un-wedging reverse manoeuvre when lodged on an obstacle the static map doesn't carry. */
    val allowReverse: Boolean = true,
    /**
     * Engage the TILE-PRECISE docking controller for the final berth. When set, once the pursuit brings the
     * boat near the destination the driver stops powering at max speed and instead ROTATES to align, then
     * creeps the hull onto the exact target tile with slow forward / reverse nudges, coasting rather than
     * plowing through it. The destination is then a specific tile the hull must OCCUPY ([dockCoverage]), not
     * a distance band ([arriveRadius]) — the right mode for getting alongside scenery (a wreck, a fishing
     * spot). Off by default: ordinary "sail to a dock" navigation keeps the looser, faster radius arrival.
     *
     * @since 0.32.0
     */
    val preciseDock: Boolean = false,
    /** What "the hull is on the target tile" means when [preciseDock] is set. @since 0.32.0 */
    val dockCoverage: DockCoverage = DockCoverage.CENTRE_ON_TILE,
    /**
     * Tiles of run-out to leave before the berth: once this close to the target the driver bleeds way off
     * (drops the sails) so hull momentum settles ON the tile instead of past it. Tune to the boat's coast;
     * starts conservative. Only consulted when [preciseDock] is set. @since 0.32.0
     */
    val brakeTiles: Int = 3,
    /** Creep at speed 1 (slow) rather than speed 2 during the precise-dock final adjustments — smaller,
     *  re-checkable nudges that don't overshoot. Only consulted when [preciseDock] is set. @since 0.32.0 */
    val slowDock: Boolean = true,
) {
    companion object {
        /** The tuned defaults. */
        val DEFAULT = LocalSailConfig()

        /** Cluttered/hazardous water — wider clearance, longer lookahead, faster control steps. */
        val CAUTIOUS = LocalSailConfig(hazardBuffer = 2, hazardLookahead = 20, stepMs = 150)

        /** Tile-precise berthing alongside scenery — the boat's hull ends up ON the target tile, creeping
         *  the last stretch with slow/reverse adjustments instead of overshooting at full sail. */
        val DOCK = LocalSailConfig(arriveRadius = 1, hazardBuffer = 2, preciseDock = true)
    }
}

/**
 * How [LocalSailConfig.preciseDock] decides the boat has reached the target tile.
 *
 * @since 0.32.0
 */
enum class DockCoverage {
    /** The boat's hull CENTRE must sit on the target tile — the tightest, most precise berth. */
    CENTRE_ON_TILE,

    /** The target tile need only fall anywhere UNDER the multi-tile hull footprint — looser, reached sooner,
     *  enough when "alongside" is all that matters. */
    HULL_COVERS_TILE,
}

/**
 * What a sailing navigation reports. Shared by [LocalSailor] and [GlobalSailor] — the global tier adds
 * [Planned] and [LegStarted]; the rest come from whichever tier is steering.
 */
sealed interface SailEvent : NavEvent {
    /** Sailing to [dest] began from [from]. */
    data class Started(override val dest: Tile, val from: Tile) : SailEvent
    /** A hull-aware route was planned with [waypoints] waypoints. */
    data class Planned(override val dest: Tile, val waypoints: Int) : SailEvent
    /** The global plan handed off a leg ending at [legEnd] to the local tier. */
    data class LegStarted(override val dest: Tile, val legEnd: Tile) : SailEvent
    /** Steering toward [target] on heading [heading] (0..15). */
    data class Steering(override val dest: Tile, val target: Tile, val heading: Int) : SailEvent
    /** Routing around a hazard: a detour of [tiles] tiles was spliced in, rejoining the plan afterwards. */
    data class Rerouted(override val dest: Tile, val around: Tile, val tiles: Int) : SailEvent
    /** A hazard blocks the way ahead with no safe route around it — holding station at [at]. */
    data class Holding(override val dest: Tile, val at: Tile, val reason: String) : SailEvent
    /** Lodged at [at] and making no way; reversing off to recover. */
    data class Stuck(override val dest: Tile, val at: Tile, val reason: String) : SailEvent
    /** No hull-legal route to [dest] exists ([diagnosis] from the pathfinder — often a beam/turn-radius
     *  constraint rather than genuinely closed water). */
    data class Unreachable(override val dest: Tile, val diagnosis: String) : SailEvent
    /** A generic diagnostic message. */
    data class Info(override val dest: Tile, val message: String) : SailEvent
    /** Docked at [dest], hull at [at]. */
    data class Arrived(override val dest: Tile, val at: Tile) : SailEvent
    /** Gave up ([reason] explains — not aboard, timed out, or no route). */
    data class Failed(override val dest: Tile, val reason: String) : SailEvent
}
