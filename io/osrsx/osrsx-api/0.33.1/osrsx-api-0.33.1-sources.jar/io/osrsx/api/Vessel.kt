package io.osrsx.api

/**
 * The boat you are standing on — its state, its controls and its facilities.
 *
 * Complements [Sailor], which is about GOING somewhere. This is about the ship itself: is a trim being
 * offered, are the sails set, what is in the cargo hold, which facilities are mounted and usable. A
 * sailing-skill plugin lives here at least as much as it does in the navigators.
 *
 * Reached via `vessel` on [PluginApi]. Every accessor is safe to call ashore and reports a neutral value
 * ([aboard] false, [moveMode] `null`, empty facility list) rather than throwing.
 *
 * ### Working with a boat's worldview
 * A boat is a sub-[WorldView]: its deck is a small scene of its own, separate from the world it floats
 * in. Scene queries cascade both, so `objects()` returns deck AND world entities together, with deck
 * coordinates normalised into main-world space so distances stay comparable. That means [facilities] and
 * `objects()` agree, and `distance()` on a deck object is the couple of tiles you would expect.
 *
 * ### Coordinating with the navigators
 * [Sailor]'s drivers actuate the same helm and sails. Issuing control calls here while a navigator is
 * running means two writers on one boat — prefer stopping the navigator first, or restrict yourself to
 * reads and to facilities the driver does not touch.
 *
 * @since 0.29.0
 */
interface Vessel {

    // ---- state ----

    /** Is the local player aboard a boat at all? Equivalent to [Sailor.isOnBoat]. */
    fun aboard(): Boolean

    /** Is the player AT THE HELM, i.e. actually steering? Aboard but off the helm, controls are inert. */
    fun atHelm(): Boolean

    /** How the boat is moving, or null when not aboard. */
    fun moveMode(): MoveMode?

    /** Is the boat making way (sails set and moving, forward or reverse)? */
    fun underWay(): Boolean = moveMode().let { it == MoveMode.FORWARD || it == MoveMode.REVERSE }

    /** Boat heading, 0..15 (0=S, 4=W, 8=N, 12=E), or -1 when not aboard. Same scale as [Sailor.heading]. */
    fun heading(): Int

    // ---- sail control ----

    /**
     * Is the game offering a sail TRIM right now?
     *
     * Trimming is the skill's passive xp drip and only pays inside a window the game opens; outside it the
     * action does nothing. This reads the live minimenu flag
     * ([SceneObject.isActionShown]) rather than the sails' action list, which advertises `Trim`
     * permanently and would read "always available".
     */
    fun canTrim(): Boolean

    /** Trim the sails, if [canTrim]. Returns true when a click was issued. No-op otherwise. */
    fun trim(): Boolean

    /** Raise the sails to get under way. Returns true when a click was issued. */
    fun setSails(): Boolean

    /** Lower the sails and come to a stop. Returns true when a click was issued. */
    fun unsetSails(): Boolean

    // ---- cargo ----

    /**
     * The boat's cargo hold contents, or null when they cannot be read right now.
     *
     * **The hold is WIDGET-BACKED, and only readable while it is OPEN.** It is deliberately not a
     * [Container]: measured live with six cannonballs aboard, none of the five
     * `Inventories.SAILING_BOAT_*_CARGOHOLD` ids (963..967) is ever populated — not while closed, and not
     * while open either. A full sweep of every container id finds only inventory and equipment; the
     * contents live in the sailing cargo-hold interface instead.
     *
     * So null means **"cannot see"**, NOT "empty" — conflating the two reads as cargo vanishing. Open the
     * hold (see [facilities], the hold's `Open` action) before trusting a read.
     *
     * Because of that, anything tracking cargo across time needs to cache: snapshot while open, then carry
     * the value forward. Note the hold also CHANGES while closed — salvaging hooks deposit into it — so a
     * snapshot alone goes stale exactly when it matters, and deltas have to come from elsewhere (the
     * salvage/full chat messages) with staleness surfaced rather than hidden.
     */
    fun cargo(): List<CachedItem>?

    /**
     * A cached, explicitly-possibly-stale view of the cargo hold — usable while the hold is CLOSED.
     *
     * [cargo] can only answer while the hold is open, which is useless for the loops that actually care
     * ("is the hold full yet?" during salvaging). This carries the last confirmed contents forward and
     * tracks what the game has told us since, so a caller can decide without opening anything.
     *
     * Never returns null while aboard: an unknown hold is [CargoView.NONE]-shaped (`asOfMs == 0`), which is
     * honest, whereas null or an empty list would read as "the hold is empty".
     */
    fun cargoView(): CargoView?

    // ---- facilities ----

    /**
     * The facilities mounted on this boat — helm, sails, cargo hold, salvaging hooks, crystal extractor
     * and so on. Empty ashore.
     *
     * Each entry is the live deck object, so you can check availability with
     * [SceneObject.isActionShown] and act on it with the usual [Interactable] verbs.
     */
    fun facilities(): List<SceneObject>

    /** The mounted facility whose name matches [name] (case-insensitive), or null. */
    fun facility(name: String): SceneObject? =
        facilities().firstOrNull { it.name().equals(name, ignoreCase = true) }

    // ---- fitted parts (read off-boat, from the boat's varbits + the game DB) ----

    /**
     * The names of the FACILITIES fitted to the boat you own (e.g. "Steel salvaging hook", "Inoculation
     * station"), decoded from the boat's hotspot varbits and the game DB. Unlike [facilities] this works
     * ANYWHERE — you need not be aboard — and is the authoritative "what is fitted" read; [facilities] stays for
     * acting on the live deck objects when aboard. Empty when you own no boat.
     */
    fun fittedFacilities(): List<String> = emptyList()

    /** Is there an EMPTY hotspot on your boat that can hold a variant of facility [type] (e.g. "cannon")? */
    fun hasEmptyHotspotFor(type: String): Boolean = false

    /**
     * The water types this boat can cross WITHOUT capsizing — the navigator's routing whitelist. Plain water
     * (value 1) is always included; each hazard type is present only when a fitted facility makes it survivable
     * (an Inoculation station → diseased water, etc.). Values are [io.osrsx.api] water-type ids matching the
     * engine's TileType (1 plain, 3 storm, 4 disease, 8 sharp-crystal, …).
     */
    fun crossableWaterTypes(): IntArray = intArrayOf(1)

    /** The boat's size class — 0 Raft, 1 Skiff, 2 Sloop — or -1 when you own no boat. */
    fun boatSizeRank(): Int = -1

    /** The mounted tier RANK of a core [part] (hull/mast/helm/keel), or -1 when it can't be read. */
    fun componentTierRank(part: BoatPart): Int = -1
}

/** A core boat component built at the schematics board. Its mounted tier is read via [Vessel.componentTierRank]. */
enum class BoatPart { HULL, MAST, HELM, KEEL }

/**
 * What we believe is in the cargo hold, and how much that belief is worth.
 *
 * The hold is only readable while OPEN, yet it CHANGES while closed — salvaging hooks deposit into it —
 * so a snapshot alone is stale exactly when it matters. Every field exists so a caller can tell knowing
 * from guessing, rather than being handed a confident number that might be minutes old.
 *
 * @property items contents as of [asOfMs]; empty when never read.
 * @property capacity total slots, or 0 when unknown — the hold's own readout, not a guess.
 * @property occupied slots in use as of [asOfMs] — again the hold's OWN number. Not the same as
 *   `items.size`: measured live, a hold showing two stacks (6 cannonballs + 16 salvage) reported 17/30
 *   occupied, so counting stacks would badly under-read fullness.
 * @property asOfMs when [items] was captured from an open hold; 0 = never seen this session.
 * @property fresh the hold is open RIGHT NOW, so [items] is exact rather than remembered.
 * @property addedSinceRead stacks the game has said arrived since [asOfMs] (salvage hooked while closed).
 *   A LOWER BOUND, not a guarantee — chat is the only signal available with the hold shut.
 * @property knownFull the game explicitly said the hold was full after [asOfMs]. Trust this over
 *   [used] vs [capacity], which is only as fresh as the last read.
 *
 * @since 0.29.0
 */
data class CargoView(
    val items: List<CachedItem> = emptyList(),
    val capacity: Int = 0,
    val occupied: Int = 0,
    val asOfMs: Long = 0,
    val fresh: Boolean = false,
    val addedSinceRead: Int = 0,
    val knownFull: Boolean = false,
) {
    /** Have we ever seen inside this hold? False ⇒ every other field is a default, not a reading. */
    val known: Boolean get() = asOfMs > 0L

    /**
     * Best estimate of occupied slots: the hold's own occupancy at the last read, plus what we have been
     * told arrived since. Falls back to counting stacks only when the hold never reported a number.
     */
    val used: Int get() = (if (occupied > 0) occupied else items.size) + addedSinceRead

    /** Best estimate of free slots, floored at 0; 0 when [capacity] is unknown. */
    val free: Int get() = if (capacity <= 0) 0 else (capacity - used).coerceAtLeast(0)

    /** Is the hold full? Prefers the game's own statement over arithmetic on a possibly-stale read. */
    val full: Boolean get() = knownFull || (capacity > 0 && used >= capacity)
}

/**
 * How a boat is moving, read from the sailing side-panel.
 *
 * @since 0.29.0
 */
enum class MoveMode {
    /** Stationary, sails stowed. */
    STILL,

    /** Aboard but not under sail. */
    ON_BOAT,

    /** Making way forward. */
    FORWARD,

    /** Making way astern. */
    REVERSE,

    /** Stationary with the wind catcher deployed. */
    STILL_WITH_WIND_CATCHER,
}
