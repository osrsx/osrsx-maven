package io.osrsx.api

/** Withdraw [amount] of [ref] from the bank ([noted] = as bank notes). @since 0.4.0 */
data class Withdrawal(val ref: ItemRef, val amount: Int, val noted: Boolean = false)

/** Deposit [amount] of [ref] into the bank (`amount <= 0` = deposit-all). @since 0.4.0 */
data class Deposit(val ref: ItemRef, val amount: Int)

/** A required item the bank couldn't fully cover — the restock trigger ([shortfall] still missing). @since 0.4.0 */
data class RestockNeed(val item: LoadoutItem, val shortfall: Int)

/**
 * The reconciliation diff between the live containers and a [Loadout]: what to deposit (foreign + excess),
 * what to withdraw (deficits the bank can cover), what to equip (carried but must be worn), and what to
 * restock (required deficits the bank can't cover). [satisfied] is the dry-run "already there?" answer.
 *
 * @since 0.4.0
 */
data class LoadoutPlan(
    val deposits: List<Deposit>,
    val withdrawals: List<Withdrawal>,
    val equips: List<ItemRef>,
    val restocks: List<RestockNeed>,
) {
    /** True when the live containers already meet the loadout (nothing to deposit/withdraw/equip). */
    val satisfied: Boolean get() = deposits.isEmpty() && withdrawals.isEmpty() && equips.isEmpty()
}

/**
 * Provisions the live inventory + equipment toward a declarative [Loadout] using ONLY osrsx's synthetic
 * bank / Grand Exchange interaction (no packets, no field writes).
 *
 * **Use it in two lines.** Build a loadout with [build] (or [Loadout.build]), then hand it to [provision]
 * ONCE — it drives the whole bank → GE → withdraw sequence itself on a background driver, so you never pump
 * it each loop. Poll [provisioning] / [provisioned], or take the completion callback:
 *
 * ```
 * // start once (e.g. when a step first needs the gear)
 * if (!ctx.loadouts().provisioning()) ctx.loadouts().provision(gear)
 * // …then just wait for it; proceed when it's done
 * if (ctx.loadouts().provisioning()) return WAIT
 * ```
 *
 * Obtain it from [PluginContext.loadouts] / the `loadouts` authoring sugar.
 *
 * @since 0.4.0
 */
interface Loadouts {

    /** Build a [Loadout] with the [LoadoutBuilder] DSL — sugar for [Loadout.build]. */
    fun build(name: String, block: LoadoutBuilder.() -> Unit): Loadout = Loadout.build(name, block)

    /** Dry-run: does the live inventory/equipment ALREADY satisfy [loadout]? (Ignores the bank.) */
    fun isSatisfied(loadout: Loadout): Boolean

    // ---- fire-once, self-driving (preferred) ----

    /**
     * FIRE-ONCE provisioning: begin reconciling the live containers toward [loadout] on a background driver
     * and return immediately. The driver runs the whole sequence itself — open the nearest bank, deposit
     * foreign clutter, withdraw what the bank has, and for a required deficit the bank can't cover, walk to
     * the Grand Exchange, buy it (marked up for an instant fill), bank it, and withdraw — pumping at its own
     * cadence with no per-loop `apply` calls from you.
     *
     * With [returnToStart], once the loadout is satisfied the driver walks the character BACK to the tile it
     * was standing on when this call was made (teleport-capable), then reports done — so a flow interrupted by
     * a far bank/GE detour resumes where it left off. Best-effort: a return that can't be routed still reports
     * the provisioning success. (Capture is the live player tile; if provisioning is kicked off while aboard a
     * boat the captured tile is boat-local, so prefer starting it ashore.)
     *
     * Poll [provisioning] / [provisioned] to know when it's done, or pass [onComplete] (invoked with true on
     * success). Calling again with a different loadout replaces the one in flight (a plugin provisions one
     * thing at a time). Returns true once a provision is active — or immediately, having fired [onComplete],
     * when [loadout] is already satisfied.
     *
     * @since 0.31.0
     */
    fun provision(
        loadout: Loadout,
        budget: Int = DEFAULT_BUDGET,
        returnToStart: Boolean = false,
        onComplete: (Boolean) -> Unit = {},
    ): Boolean

    /** True while a [provision] is in flight (its driver is still running). @since 0.31.0 */
    fun provisioning(): Boolean = false

    /** The last finished [provision]'s outcome — null while one is running, or before any has run. @since 0.31.0 */
    fun provisioned(): Boolean? = null

    /** Cancel any in-flight [provision]; the loadout is left as far along as it got. @since 0.31.0 */
    fun cancelProvision() {}

    // ---- legacy per-loop stepper (prefer provision) ----

    /** The current diff against [loadout], reading the bank only when it's open (else deficits are assumed
     *  withdrawable). @since 0.4.0 */
    @Deprecated("Internal reconciliation detail; prefer isSatisfied() to test and provision() to act.")
    fun plan(loadout: Loadout): LoadoutPlan

    /**
     * Advance one loop-step toward [loadout]; returns true once satisfied. The per-loop stepper that
     * [provision] supersedes — prefer [provision], which drives this to completion for you off the plugin
     * loop. Retained for callers not yet migrated.
     */
    @Deprecated("Prefer provision(): fire-once, self-driving.", ReplaceWith("provision(loadout, budget)"))
    fun apply(loadout: Loadout, budget: Int = DEFAULT_BUDGET): Boolean

    /**
     * As [apply], but routes required-item shortfalls the bank can't cover to [onDeplete] instead of the
     * default GE buy — the loadout's `onDeplete` hook.
     */
    @Deprecated("Prefer provision(): fire-once, self-driving.")
    fun apply(loadout: Loadout, budget: Int, onDeplete: (RestockNeed) -> Unit): Boolean

    companion object {
        /** Default per-call container-action budget (deposits + withdrawals + equips). */
        const val DEFAULT_BUDGET: Int = 8
    }
}
