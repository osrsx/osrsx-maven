package io.osrsx.api


/**
 * Whole-map sailing — plan and follow a hull-aware route across the sea to anywhere reachable by water.
 * The sea counterpart of [GlobalWalker]; for manoeuvring inside the loaded scene use [LocalSailor], which
 * this delegates each leg to.
 *
 * Self-driving per the [Navigator] contract: call [pathTo] ONCE and the boat sails itself — planning a
 * global hull-legal route, then flying it leg by leg while the local tier reactively routes around live
 * hazards and rejoins the plan. Observe with a listener, [state], or `awaitArrival`.
 *
 * Requires being aboard a boat ([Sailor.isOnBoat]); [pathTo] returns false otherwise. Sailing is beta
 * content — heading/sail actuation may need per-revision tuning.
 *
 * @since 0.28.0 (was `Sailing`, which mixed the two tiers and had no config or event stream).
 */
interface GlobalSailor : Navigator<GlobalSailConfig, SailEvent> {
    override val defaultConfig: GlobalSailConfig get() = GlobalSailConfig.DEFAULT

    /**
     * The currently planned route to [dest] as tile waypoints (for overlays and previewing), or null when
     * none exists or it can't be planned. Does not begin sailing.
     */
    fun route(dest: Tile): List<Tile>? = null

    /**
     * The route currently being followed as tile waypoints — the global plan including any local detour
     * spliced into it — or null when idle.
     */
    fun route(): List<Tile>? = null

    /**
     * The NEAREST of [candidates] the boat can actually reach right now — under its current hull and water
     * capabilities — or null if none can be. Candidates are probed CONCURRENTLY on a bounded pool and a
     * hazard-locked one is rejected in microseconds, so this is cheap to call over a whole spawn list.
     *
     * Use it to CHOOSE a destination that will actually plan, rather than committing to the geometrically
     * nearest and discovering only after a stall that it was unreachable (e.g. a wreck walled off behind water
     * this boat can't cross). Does not begin sailing — feed the result to [pathTo].
     */
    fun nearestReachable(candidates: List<Tile>): Tile? = null

    /**
     * The closest tile to [target] the boat can ACTUALLY berth at — hull-legal AND reachable — searching
     * rings outward from [target] (Chebyshev), [minRing]..[maxRing], and returning the first (nearest the
     * target) that plans.
     *
     * This is the primitive for getting RIGHT NEXT TO scenery you work from the deck — a shipwreck, cargo, a
     * fishing spot. Two things set it apart from [nearestReachable]:
     *  - it ranks by proximity to the **target**, not to the boat, so it hugs the object as tightly as the
     *    hull physically allows rather than parking at the nearest reachable water; and
     *  - every returned tile is a spot the whole ROTATED HULL fits (not merely a navigable centre) AND the
     *    real planner can route to — so a wreck walled in by rock returns the tightest berth the hull can
     *    hold, never a centre-navigable pocket the boat could never occupy (the failure a plain "nearest
     *    navigable tile" search falls into).
     *
     * [target]'s own tile is typically an obstacle (the wreck itself), so it is never a candidate; start
     * [minRing] at 1. [maxRing] bounds the search — keep it at or below the activity's working range so an
     * arrival is already in range. Returns null when nothing within [maxRing] is both hull-legal and
     * reachable right now (e.g. the object is walled off behind water this boat can't cross). Does not begin
     * sailing — feed the result to [pathTo] or [LocalSailor.pathTo].
     *
     * @since 0.32.0
     */
    fun approach(target: Tile, maxRing: Int = 10, minRing: Int = 1): Tile? = null
}

/**
 * How [GlobalSailor.pathTo] plans and flies a whole-map route. The reactive, per-step behaviour is
 * configured by the local tier it delegates to — see [local].
 */
data class GlobalSailConfig(
    /** Dock/arrive when within this many tiles of the destination. */
    val arriveRadius: Int = 2,
    /** Per-search budget for the global hull-aware route search, in ms. */
    val pathfindTimeoutMs: Long = 8_000,
    /** Re-plan the global route from scratch when the local tier can't rejoin it within this many tiles. */
    val replanAfterDriftTiles: Int = 24,
    /** Give up (emit [SailEvent.Failed]) after this long without arriving. 0 = never time out. */
    val timeoutMs: Long = 600_000,
    /** The local-tier configuration used for each leg — hazard clearance, control cadence, un-wedging. */
    val local: LocalSailConfig = LocalSailConfig.DEFAULT,
) {
    companion object {
        /** Balanced defaults. */
        val DEFAULT = GlobalSailConfig()

        /** Cluttered/hazardous water — wider clearance and a longer planning budget. */
        val CAUTIOUS = GlobalSailConfig(pathfindTimeoutMs = 15_000, local = LocalSailConfig.CAUTIOUS)
    }
}
