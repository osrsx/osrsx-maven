package io.osrsx.api


/**
 * Whole-map walking — plan and follow a tile-level route anywhere on the map, using transports and teleports
 * as needed. For movement inside the already-loaded scene use [LocalWalker], which this delegates each
 * walking leg to.
 *
 * Self-driving per the [Navigator] contract: call [pathTo] ONCE and it plans, walks, opens doors, takes
 * boats and fairy rings, detours to a bank or the Grand Exchange for anything a transport needs, and
 * re-plans when something goes wrong — until it arrives. Fairy rings, charters, teleports and every other
 * transport are handled internally; there is no separate fairy-ring API.
 *
 * The walk is fully observable: pass a listener to [pathTo] for the whole [WalkEvent] stream (every
 * transport considered, excluded and why, each step, each detour), poll [state] from any thread, or suspend
 * on `awaitArrival`. Behaviour is shaped by a [WalkConfig] — per call, or ambiently via [configure].
 *
 * @since 0.28.0 (was `WebWalker`, which was caller-pumped; it now drives itself).
 */
interface GlobalWalker : Navigator<WalkConfig, WalkEvent> {
    /** The ambient config used when [pathTo] is called without one — set it with [configure]. */
    override val defaultConfig: WalkConfig

    /** Set the ambient walk configuration (clears any cached plan so the new rules take effect). */
    fun configure(config: WalkConfig)

    /**
     * A drawable, geometry-only view of the route currently being followed — the local tile path, an active
     * object shortcut, the off-scene legs ahead and the destination — for rendering an in-world overlay
     * (see [RouteView]). Reflects whatever the walker is heading to (regardless of which plugin is driving
     * it), or null when idle. Non-blocking (never pathfinds on the caller's thread) and safe to call every
     * frame from an overlay; intended to be called on the render thread where scene projection is valid.
     */
    fun routeView(): RouteView?

    /**
     * The FULL whole-map planned route currently being followed — every walked tile and transport from the
     * current position to the active destination (see [GlobalRoute]) — or null when idle. Unlike
     * [routeView] (the scene-local view of the current leg) this is the entire cross-region path, e.g. to
     * draw the plan on the world map. Non-blocking; safe to poll each frame.
     */
    fun globalRoute(): GlobalRoute?

    /**
     * The FULL whole-map planned route to an arbitrary [dest] — for previewing where a walk *would* go
     * before committing to it (e.g. after picking a location/NPC/object). Non-blocking: returns the last
     * background-computed plan and triggers a recompute when [dest] changes, so the first call for a new
     * destination may return null until the plan is ready. Never pathfinds on the caller's thread.
     */
    fun globalRoute(dest: Tile): GlobalRoute?

    /**
     * The nearest bank you can ACTUALLY reach (the tile to stand on to use it), or null if none is
     * routable. Reachability is judged by global pathfinding to the bank's customer side — a banker's
     * interior tile, or a booth's stand ring — so a wall-mounted booth you can only touch from the wrong
     * side (e.g. the Cooks' Guild from outside its gated door) is correctly skipped. [pathTo] this, then
     * open the bank. Prefer it over a raw nearest-"Bank booth" object lookup.
     */
    fun nearestBank(): Tile?

    /**
     * The carry-items the shortest route to [dest] would require you to obtain — the unmet ITEM requirements
     * (runes, tabs, staves, coins) of the transports/teleports on that route, as `need qty of ref` specs.
     * Skill/varbit/quest gates are excluded (they cost no inventory space). Empty when the route needs nothing
     * you don't already hold, or when no route is known yet (planning is async — a first call for a fresh dest
     * may return empty until the background plan is ready).
     *
     * Lets a caller budget inventory space for a trip up front — e.g. decide whether a loadout plus the runes
     * its return route needs will fit in 28 slots. Non-blocking; never pathfinds on the caller's thread.
     *
     * @since 0.31.0
     */
    fun itemsNeededFor(dest: Tile): List<ItemSpec> = emptyList()
}

/**
 * The family a transport edge belongs to — used for config gating and event reporting. Covers every
 * transport category present in the osrsx dataset (the source TSVs: agility shortcuts, boats/canoes,
 * charter ships, fairy rings, gnome gliders, hot-air balloons, magic carpets, mushtrees, minecarts,
 * quetzals, spirit trees, teleport items/spells, wilderness obelisks, …). [TRAVERSAL] (doors, gates,
 * stairs, ladders, tunnels) and [AGILITY_SHORTCUT] are "on-foot" — they are kept out of [FAST_TRAVEL]
 * so a walk-only configuration still opens doors and uses shortcuts. [OTHER] is any hub-travel edge we
 * couldn't classify yet.
 */
enum class TransportKind {
    TRAVERSAL,
    AGILITY_SHORTCUT,
    BOAT,
    CHARTER_SHIP,
    TELEPORT_ITEM,
    TELEPORT_SPELL,
    FAIRY_RING,
    SPIRIT_TREE,
    GNOME_GLIDER,
    HOT_AIR_BALLOON,
    MAGIC_CARPET,
    MUSHTREE,
    MINECART,
    QUETZAL,
    WILDERNESS_OBELISK,
    MINIGAME_TELEPORT,
    OTHER;

    companion object {
        /** Every non-on-foot family — everything except [TRAVERSAL] and [AGILITY_SHORTCUT]. */
        val FAST_TRAVEL: Set<TransportKind> get() = entries.toSet() - TRAVERSAL - AGILITY_SHORTCUT
        /** Teleport families (item tabs/jewellery + spells + minigame-group teleports). */
        val TELEPORTS: Set<TransportKind> get() = setOf(TELEPORT_ITEM, TELEPORT_SPELL, MINIGAME_TELEPORT)
    }
}

/** A transport/teleport on a planned or taken route, in API-level terms (no engine internals leaked). */
data class WalkTransport(
    val name: String,
    val from: Tile?,
    val to: Tile,
    val kind: TransportKind,
)

/** Why a transport was dropped from planning (carried by [WalkEvent.TransportExcluded]). */
enum class ExclusionReason {
    /** A declared requirement isn't met and can't be resolved (skill/quest/varbit, or an item not held/bankable). */
    REQUIREMENT_UNMET,
    /** On its shared cooldown (home/minigame teleport already used). */
    ON_COOLDOWN,
    /** Disabled by the active [WalkConfig] (family off, blacklisted, or not whitelisted). */
    CONFIG_DISABLED,
    /** Vetoed as the reverse of what we just crossed (anti-bounce). */
    BACKTRACK,
    /** Repeatedly failed to execute (object missing / couldn't interact / never landed) and was excluded. */
    TOO_MANY_FAILURES,
    /** GE-buyable but not affordable within the spend caps. */
    UNAFFORDABLE,
}

/**
 * Something that happened during a whole-map walk — emitted for EVERY step and decision, not just coarse
 * phases. Delivered to the listener passed to [GlobalWalker.pathTo] and reflected in [GlobalWalker.state].
 * Listeners can observe the whole pipeline: planning, each transport considered/excluded (with the reason),
 * stepping (local vs following a route), taking a transport, bank/GE detours, replanning, arrival and failure.
 */
sealed interface WalkEvent : NavEvent {
    /** A walk to [dest] began from [from]. */
    data class Started(override val dest: Tile, val from: Tile) : WalkEvent
    /** A route was planned: [walkLegs] walking legs and the ordered [transports] it will take. */
    data class PathPlanned(override val dest: Tile, val walkLegs: Int, val transports: List<WalkTransport>) : WalkEvent
    /** The cached route is being recomputed ([reason]: a transport was taken/excluded, or the config changed). */
    data class Replanning(override val dest: Tile, val reason: String) : WalkEvent
    /** A transport was dropped from planning ([reason] says why). */
    data class TransportExcluded(override val dest: Tile, val transport: WalkTransport, val reason: ExclusionReason) : WalkEvent
    /** Now heading to the next waypoint [target]. [local] = a direct on-screen step (dest in scene); otherwise
     *  we're following the global route toward a transport/leg. */
    data class Stepping(override val dest: Tile, val target: Tile, val local: Boolean = false) : WalkEvent
    /** About to take [transport] (we've reached its origin, or it's a teleport taken from here). */
    data class TakingTransport(override val dest: Tile, val transport: WalkTransport) : WalkEvent
    /** A transport/teleport was taken. */
    data class TransportTaken(override val dest: Tile, val transport: WalkTransport) : WalkEvent
    /** Movement stalled at [at] ([reason] describes why — e.g. a blocked path or unreachable waypoint). */
    data class Stuck(override val dest: Tile, val at: Tile, val reason: String) : WalkEvent
    /** No route to [dest] could be found ([diagnosis] from the pathfinder). */
    data class Unreachable(override val dest: Tile, val diagnosis: String) : WalkEvent
    /** Detouring to [bank] to obtain [needs] (items/coins a transport on the route requires). */
    data class BankDetour(override val dest: Tile, val bank: Tile, val needs: List<String>) : WalkEvent
    /** Withdrawing [item] from the bank during a detour. */
    data class BankWithdraw(override val dest: Tile, val item: String) : WalkEvent
    /** Chose to buy [items] at the Grand Exchange to reach [dest] ([reason]: clearly faster, or the only way). */
    data class EconomyDetour(override val dest: Tile, val items: List<String>, val reason: String) : WalkEvent
    /** Placed a GE buy offer for [item] at [price] coins each. */
    data class GeOffer(override val dest: Tile, val item: String, val price: Int) : WalkEvent
    /** Collected the bought [items] from the GE. */
    data class GeCollected(override val dest: Tile, val items: List<String>) : WalkEvent
    /** A generic diagnostic message (kept for parity with the debug logging). */
    data class Info(override val dest: Tile, val message: String) : WalkEvent
    /** Arrived at [dest]. */
    data class Arrived(override val dest: Tile) : WalkEvent
    /** The walk gave up ([reason] explains — e.g. a non-bankable requirement, or bank runs disabled). */
    data class Failed(override val dest: Tile, val reason: String) : WalkEvent
}

/**
 * Ranking = the routing COST assigned to each transport; the pathfinder measures it against walking at 1
 * per tile, so a lower cost means "more preferred". Everything is rankable, at three precedence levels
 * (first match wins):
 *  1. [transportCost] — an exact per-transport cost by name (case-insensitive substring). Highest control.
 *  2. [kindCost] — a per-family cost override (e.g. make all fairy rings cheap, or all boats expensive).
 *  3. the teleport floors — [itemTeleportMinCost] for consumable item teleports (tablets/jewellery),
 *     [teleportMinCost] for spell teleports, [homeTeleportCost] for home teleports (their long cooldown
 *     makes them a last resort). These are FLOORS (`max(baked, floor)`), not overrides.
 * A transport matched by none keeps its data-baked cost. [PREFER]/[AVOID] are handy sentinel costs the DSL's
 * `prefer()`/`avoid()` verbs use.
 *
 * Why item teleports get their OWN, higher floor: a tablet is a **consumable destroyed on use** (real GP),
 * so burning one to save a short walk is bad economy — whereas a spell teleport only spends a few cheap
 * runes. Giving tablets/jewellery a higher floor than spells means the walker only reaches for a consumable
 * once the trip is long enough to be worth it, yet still spell-teleports (and takes free travel — boats,
 * fairy rings, shortcuts) for shorter hops. The default (80 vs 20) means "a tablet must save ~80 tiles of
 * walking to be worth burning" — so a consumable is only spent on a genuinely long haul, not a short detour.
 */
data class RankingConfig(
    /** Tiles a SPELL teleport must save to be chosen (a floor). Spells only spend cheap runes, so this is
     *  low. Consumable item teleports use the higher [itemTeleportMinCost]. Low → prefer teleporting. */
    val teleportMinCost: Int = 20,
    /** Tiles a consumable ITEM teleport (tablet/jewellery) must save to be chosen (a floor). Higher than
     *  [teleportMinCost] because the item is destroyed/discharged on use — don't burn one for a short hop. */
    val itemTeleportMinCost: Int = 80,
    /** Cost floor for "Home Teleport" transports — high, because of their ~30-min cooldown. */
    val homeTeleportCost: Int = 1000,
    /** Per-family cost override (routing cost for every transport of that [TransportKind]). */
    val kindCost: Map<TransportKind, Int> = emptyMap(),
    /** Per-transport cost override by name (case-insensitive substring) — beats [kindCost]. */
    val transportCost: Map<String, Int> = emptyMap(),
) {
    companion object {
        /** Sentinel cost for `prefer()` — cheaper than almost any walk, so it's taken whenever available. */
        const val PREFER = 2
        /** Sentinel cost for `avoid()` — high, so it's only used when nothing cheaper reaches the goal. */
        const val AVOID = 500
    }
}

/** Bank/GE detour tuning: how the walker reroutes to obtain something a transport needs. */
data class DetourConfig(
    /** Max distinct banks probed for reachability before giving up on a bank detour. */
    val maxBanksProbed: Int = 8,
    /** Per-candidate-bank pathfind budget (ms) when picking a reachable bank. */
    val bankProbeMs: Long = 2000,
    /** Local path longer than the direct line × this (+ [localDetourSlack]) → hand off to the global plan. */
    val localDetourFactor: Int = 2,
    /** Tiles of slack on top of [localDetourFactor], so short obstacle weaves still walk locally. */
    val localDetourSlack: Int = 10,
)

/** Anti-bounce, retry and cooldown tuning: when a transport is vetoed or excluded after trouble. */
data class ExclusionConfig(
    /** After crossing, how long the reverse/same twin transport is vetoed (anti-bounce), in ms. */
    val reverseCooldownMs: Long = 6000,
    /** Consecutive failed takes before a transport is excluded and the route replans. */
    val transportFailLimit: Int = 3,
    /** Consecutive "interacted but never arrived" misses before a transport is excluded. */
    val crossMissLimit: Int = 3,
    /** How long an excluded (broken/blocked) transport stays out of planning, in ms. */
    val transportExcludeMs: Long = 20_000,
    /** Home-teleport family cooldown after use (excluded for this long), in ms. */
    val homeTeleportCooldownMs: Long = 30 * 60_000L,
    /** Minigame-teleport family cooldown after use, in ms. */
    val minigameTeleportCooldownMs: Long = 20 * 60_000L,
)

/** Pathfinding budgets and the radii that decide "close enough" during the on-screen follow. */
data class PathfindingConfig(
    /** Chebyshev distance to a transport origin that counts as "at origin, take it". */
    val nearRadius: Int = 2,
    /** Chebyshev distance to a walk waypoint that counts as reached. */
    val waypointArriveRadius: Int = 3,
    /** How far the safety-net will walk to a blocking gate's origin to cross it. */
    val approachRadius: Int = 16,
    /** Max range to consider taking an off-plan agility/door shortcut (~half a loaded scene). */
    val shortcutReach: Int = 52,
    /** Budget (ms) for tight reachability probes that scan many tiles. */
    val reachProbeMs: Long = 3000,
    /** Fallback A* budget (ms) for secondary searches (bank detour, far-side traces) with no explicit limit. */
    val searchBudgetMs: Long = 6000,
)

/**
 * Interaction timing for taking a transport — how long to wait for gates to open, crossings/teleports to
 * confirm, and the camera to stand down. These shape reliability + humanisation; raise them on a laggy
 * connection, lower them for snappier (but riskier) takes. NOT the local click humaniser (that is separate).
 */
data class TimingConfig(
    /** Extra open/cross wait added per tile of approach when interacting from a distance, in ms. */
    val approachMsPerTile: Long = 350,
    /** Base wait for a gate to open after the action, in ms. */
    val openBaseMs: Long = 2000,
    /** Base wait to confirm arrival on the far side of a crossing, in ms. */
    val crossConfirmMs: Long = 5000,
    /** Wait for a teleport channel to complete before confirming arrival, in ms. */
    val teleportConfirmMs: Long = 9000,
    /** Land within this many tiles of a teleport's destination to count it as taken. */
    val teleportArriveRadius: Int = 12,
)

/**
 * Economy-aware routing: when a transport needs an item the player lacks in inventory AND bank, but which
 * is tradeable and affordable, the walker can detour to the Grand Exchange to buy it — withdrawing the
 * coins from the GE's OWN bank (no separate coin-bank trip; a non-GE bank is only visited when it holds an
 * item that gets us to the GE faster, which the normal bank-detour already handles) — before continuing.
 * Only taken when the whole detour is CLEARLY faster than walking. Gated by [WalkConfig.allowGrandExchange];
 * these tune the money side.
 */
data class EconomyConfig(
    /** A detour to acquire a transport (bank/GE) is chosen over walking only when it beats the direct walk
     *  by at least this many tiles of cost. Higher = more conservative (only detour when clearly faster). */
    val detourMargin: Int = 30,
    /** How far over market price to bid when buying at the GE, so offers fill promptly (percent). */
    val gePriceMarkupPercent: Int = 10,
    /** Absolute cap: max coins to spend buying a SINGLE transport item at the GE (0 = no cap). A safety rail
     *  against a mispriced/expensive item draining the account. */
    val maxGeSpendPerItem: Int = 50_000,
    /** Relative cap: never spend more than this PERCENT of total account coins (bank + inventory) on a
     *  single transport buy. Blocks e.g. a 100k tab when the account only has 200k. (0 = no relative cap.) */
    val maxGeSpendPercentOfCoins: Int = 10,
) {
    /** Whether spending [cost] coins on one transport item is allowed, given [totalCoins] the account holds:
     *  affordable AND within both the absolute ([maxGeSpendPerItem]) and relative ([maxGeSpendPercentOfCoins])
     *  caps. Zero caps disable that check. */
    fun canSpend(cost: Int, totalCoins: Int): Boolean {
        if (cost > totalCoins) return false
        if (maxGeSpendPerItem > 0 && cost > maxGeSpendPerItem) return false
        if (maxGeSpendPercentOfCoins > 0 && cost.toLong() * 100 > totalCoins.toLong() * maxGeSpendPercentOfCoins) return false
        return true
    }
}

/**
 * Highly customizable configuration for a whole-map walk. Defaults reproduce today's behaviour: every
 * transport allowed, humanised run, bank detours on, GE buying on, no stamina potions. Build one directly
 * with `copy(...)`, pick a companion preset ([DEFAULT], [WALK_ONLY], [NO_TELEPORTS], [FASTEST], [FRUGAL]),
 * or use the [walkConfig] builder DSL. Rarely-tuned knobs are grouped into sub-configs ([ranking], [detour],
 * [exclusion], [pathfinding], [timing], [economy]) so the common fields stay at the top level.
 *
 * Transport gating is layered, evaluated per transport in this PRECEDENCE (first match wins). All name
 * matching is case-insensitive substring (so `"Home"` matches `"Lumbridge Home Teleport"`):
 *  1. name matches [blacklistedTransports] → DENY (a force-deny beats everything),
 *  2. name matches [forceAllowTransports] → ALLOW (re-enables a specific transport even if its whole
 *     [TransportKind] is disabled — this is how a family block's `include("Castle Wars")` works),
 *  3. its [TransportKind] is in [disabledKinds] → DENY (TRAVERSAL is never disabled, so basic walking
 *     never breaks),
 *  4. if [allowedTransports] is non-empty and the name matches none → DENY (global whitelist),
 *  5. otherwise → ALLOW.
 *
 * Prefer the [walkConfig] DSL's family blocks (`teleports { none(); include("Varrock") }`,
 * `minigames { include("Castle Wars") }`, …) over setting these sets by hand. Helper sets like
 * [TransportKind.FAST_TRAVEL] and [TransportKind.TELEPORTS] make common cases terse; presets
 * [WALK_ONLY]/[NO_TELEPORTS]/[FASTEST]/[FRUGAL] cover the usual shapes.
 */
data class WalkConfig(
    /** Whole transport families to exclude (see [TransportKind]). TRAVERSAL is always kept. */
    val disabledKinds: Set<TransportKind> = emptySet(),
    /** Force-deny: transport names (case-insensitive substring) never used, beating every other rule. */
    val blacklistedTransports: Set<String> = emptySet(),
    /** Force-allow: transport names (case-insensitive substring) allowed even if their [TransportKind] is
     *  in [disabledKinds] — the DSL's per-family `include(...)` populates this. */
    val forceAllowTransports: Set<String> = emptySet(),
    /** If non-empty, the ONLY non-traversal transports allowed (by name, case-insensitive substring). */
    val allowedTransports: Set<String> = emptySet(),
    /** May the walker route through farmable/planted spirit-tree patches (off by default — a player's own
     *  planted trees vary; enabling assumes the configured patches are grown). */
    val allowPlantedSpiritTrees: Boolean = false,
    /** Detour to a bank to withdraw items/coins a transport on the route needs. */
    val allowBankRuns: Boolean = true,
    /** Buy missing items at the Grand Exchange when a GE detour is CLEARLY faster than walking — e.g. a
     *  teleport we can't otherwise fuel. Bounded by [economy] (per-item + percent-of-coins spend caps and the
     *  detour margin). On by default: the walker treats the GE as an available resource like the bank. */
    val allowGrandExchange: Boolean = true,
    /** Drink stamina/energy potions when run energy is low. */
    val useStaminaPotions: Boolean = false,
    /** Run-energy percent at/below which a stamina/energy potion is drunk (when [useStaminaPotions]). */
    val staminaThreshold: Int = 20,
    /** When to enable run. */
    val runPolicy: RunPolicy = RunPolicy.Humanized,
    /** Per-search pathfinding budget for the MAIN route search (ms). Secondary searches use
     *  [PathfindingConfig.searchBudgetMs] / [PathfindingConfig.reachProbeMs]. */
    val pathfindTimeoutMs: Long = 5000,
    /** If the exact destination tile is unreachable (walled off), accept arriving at the nearest reachable
     *  tile within this many tiles instead of failing. 0 = require the exact tile. */
    val arriveRadius: Int = 0,
    /** Teleport-vs-walk ranking. */
    val ranking: RankingConfig = RankingConfig(),
    /** Bank/GE detour tuning. */
    val detour: DetourConfig = DetourConfig(),
    /** Anti-bounce / retry / cooldown tuning. */
    val exclusion: ExclusionConfig = ExclusionConfig(),
    /** Pathfinding budgets + follow radii. */
    val pathfinding: PathfindingConfig = PathfindingConfig(),
    /** Transport interaction timing. */
    val timing: TimingConfig = TimingConfig(),
    /** Economy-aware detour tuning (bank/GE buying); only active when [allowGrandExchange] is on. */
    val economy: EconomyConfig = EconomyConfig(),
) {
    /** True when [kind] is permitted (TRAVERSAL is always permitted). Kind-only — prefer [permits] which
     *  also honours the name-level force-deny/force-allow/whitelist rules. */
    fun allows(kind: TransportKind): Boolean = kind == TransportKind.TRAVERSAL || kind !in disabledKinds

    /**
     * Whether a transport named [name] of family [kind] is permitted, applying the full gating precedence
     * documented on this class (force-deny → force-allow → disabled-kind → whitelist → allow). TRAVERSAL is
     * always permitted. Name matching is case-insensitive substring.
     */
    fun permits(name: String, kind: TransportKind): Boolean {
        if (kind == TransportKind.TRAVERSAL) return true
        if (blacklistedTransports.any { name.contains(it, ignoreCase = true) }) return false
        if (forceAllowTransports.any { name.contains(it, ignoreCase = true) }) return true
        if (kind in disabledKinds) return false
        if (allowedTransports.isNotEmpty() && allowedTransports.none { name.contains(it, ignoreCase = true) }) return false
        return true
    }

    companion object {
        /** Balanced defaults — every transport allowed, humanised run, bank detours on. */
        val DEFAULT = WalkConfig()
        /** Walk on foot only — no fast travel (doors/gates/stairs + agility shortcuts still used). */
        val WALK_ONLY = WalkConfig(disabledKinds = TransportKind.FAST_TRAVEL)
        /** No teleport items or spells (boats, fairy rings, etc. still allowed). */
        val NO_TELEPORTS = WalkConfig(disabledKinds = TransportKind.TELEPORTS)
        /** Get there fastest — aggressively prefer teleports, tablets included (tiny floors), and allow every
         *  fast-travel family. */
        val FASTEST = WalkConfig(ranking = RankingConfig(teleportMinCost = 1, itemTeleportMinCost = 1, homeTeleportCost = 300))
        /** Conserve consumables — walk unless a teleport saves a lot; still uses free travel (boats, fairy
         *  rings, shortcuts) and only teleports on long hauls, tablets most reluctantly of all. */
        val FRUGAL = WalkConfig(ranking = RankingConfig(teleportMinCost = 150, itemTeleportMinCost = 250))
    }
}
