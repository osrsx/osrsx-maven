package io.osrsx.api


/**
 * Sea geometry — what the water looks like, asked rather than acted on. The sea counterpart of [Terrain]:
 * every method is a pure READ of the live sailing map (navigability, hull fit, hazards, tile type).
 * Nothing steers the boat; for that use [LocalSailor] or [GlobalSailor].
 *
 * Kept separate from [Terrain] rather than merged because boat navigability is the explicit INVERSE of
 * land walkability — land, docks and rocks BLOCK a hull where they carry a player, and open water passes
 * where it would drown one. One interface answering both would invert its own meaning depending on the
 * caller.
 *
 * The distinguishing question here is [hullFitsAt]: a boat occupies a multi-tile footprint at an
 * orientation, so "is this tile navigable" is necessary but not sufficient — a gap narrower than the beam
 * is open water the boat cannot enter.
 *
 * Sailing is beta content; this surface will grow as the local tier's collision-object routing lands.
 *
 * @since 0.28.0
 */
interface Waters {
    /**
     * Is (x, y, z) open, navigable water for a boat? The sailing analogue of [Terrain.isWalkable], and its
     * inverse in meaning: land, docks and rocks block; open water passes.
     */
    fun isNavigable(x: Int, y: Int, z: Int): Boolean

    /** As [isNavigable], for a [Tile]. */
    fun isNavigable(tile: Tile): Boolean = isNavigable(tile.x, tile.y, tile.plane)

    /**
     * Would the CURRENT boat's hull fit at [tile] on [heading] (0..15)? Unlike [isNavigable] this accounts
     * for the multi-tile footprint at that orientation, so it is the real test of whether the boat can
     * occupy a spot. False when not aboard a boat, or when any tile the hull would cover is un-navigable.
     */
    fun hullFitsAt(tile: Tile, heading: Int): Boolean = false

    /** The tiles the current boat's hull occupies right now, or empty when not aboard. */
    fun hull(): List<Tile> = emptyList()

    /**
     * Known hazard tiles within [radius] of [center] — curated hazard objects/npcs plus any synthetic
     * patches injected via [Sailor.addHazard]. These are what the local tier routes around.
     */
    fun hazardsNear(center: Tile, radius: Int): List<Tile> = emptyList()

    /**
     * The sailing tile classification at [tile] (open water, shallow, dock, land, …) as the sailing map
     * carries it, or null when outside the mapped area.
     */
    fun tileType(tile: Tile): SeaTileType? = null

    // ---- static sea data (baked into osrsx.db from the OSRS Wiki; see :osrsx-data) ----

    /**
     * Sailing docking points, nearest first from the player.
     *
     * [maxLevel] defaults to the player's own Sailing level, so the result is what you can ACTUALLY dock at.
     * [salvagingOnly] narrows to ports that can sort salvage — worth knowing that only about half of them
     * can, so "nearest port" and "nearest port that can sort" are genuinely different questions and picking
     * the wrong one sails you somewhere useless.
     *
     * Empty when the data isn't present (an older `osrsx.db`), never an exception.
     *
     * @since 0.29.0
     */
    fun ports(maxLevel: Int = -1, salvagingOnly: Boolean = false): List<SeaPort> = emptyList()

    /**
     * Shipwreck spawn tiles, nearest first from the player. [tier] filters by display name ("Small",
     * "Fisherman", …); null returns every tier the level allows.
     *
     * These are STATIC spawns — a wreck depletes to a stump and respawns, but the tile set is fixed — so
     * they are a routing hint, not a promise that a wreck is there right now. Confirm with a live scene
     * query before committing to one.
     *
     * @since 0.29.0
     */
    fun wrecks(tier: String? = null, maxLevel: Int = -1): List<SeaWreck> = emptyList()

    /**
     * Buildable boat-facility variants (reference data baked into the DB), ordered lowest tier first.
     * [type] filters by facility type ("salvaging hook", …); null returns every type.
     *
     * Each carries its Sailing + Construction requirements and its material list (as a quantified
     * `name:qty;…` string — parse with [io.osrsx.config.Quantified]) — enough to decide the best tier the
     * account can build and to provision it via a [Loadout]. Empty on an older DB without the table.
     *
     * @since 0.31.0
     */
    fun facilities(type: String? = null): List<SeaFacility> = emptyList()

    /**
     * Every OWNED boat and where it's docked — resolved from the game's static per-boat varbits plus the
     * SailingDock cache table, so it works from ANYWHERE on land (no need to be near the boat) and knows the
     * dock even for ports the account hasn't unlocked. The means to answer "where's my boat, so I can web-walk
     * to it and board" from a bank or the GE.
     *
     * Each [BoatBerth] carries the boat's hull [BoatBerth.type] (bigger is better) and its berth resolved to a
     * routable [BoatBerth.port] tile when that port is in [ports]. Empty on an older DB / off the sailing revision.
     *
     * @since 0.31.1
     */
    fun boats(): List<BoatBerth> = emptyList()

    /** The nice name of sailing dock-id [dockId] (owned or not) from the SailingDock cache table, or null.
     *  @since 0.31.1 */
    fun dockName(dockId: Int): String? = null

    /**
     * The boat's TRUE bounding box as 8 ints — four corners `x0,y0,x1,y1,x2,y2,x3,y3` in main-world LocalPoint
     * units — its authoritative `WorldEntityConfig` box rotated by the live orientation. For an overlay to draw
     * the smooth rotated hull as a POLYGON (project each corner with a local→screen projection and join them)
     * rather than the tile footprint. Purely for display; the hull-fit tests use [hullFitsAt]/tiles. Empty/null
     * off-boat.
     *
     * @since 0.33.1
     */
    fun boatBoxCorners(): IntArray? = null

}

/**
 * An owned Sailing boat and where it is docked. Read via [Waters.boats] from the game's static per-boat
 * varbits + the SailingDock cache table — so it resolves from anywhere on land.
 *
 * @property boat the owned-boat slot (1-based).
 * @property type the boat's hull type; higher is a bigger/better boat (carries the best facilities).
 * @property dockId the game dock-id the boat is berthed at.
 * @property dockName the dock's nice name (present even for ports not in the surveyed [Waters.ports]).
 * @property port the berth resolved to a routable [SeaPort] tile, or null when its dock isn't in [Waters.ports].
 *
 * @since 0.31.1
 */
data class BoatBerth(
    val boat: Int,
    val type: Int,
    val dockId: Int,
    val dockName: String?,
    val port: SeaPort?,
)

/**
 * How the sailing map classifies a tile. Coarser than the raw collision data and stable across revisions —
 * for finer detail use [Waters.isNavigable] and [Waters.hullFitsAt].
 *
 * @since 0.28.0
 */
enum class SeaTileType {
    /** Open, freely navigable water. */
    OPEN_WATER,
    /** Navigable but shallow/constrained — passable, typically slower or riskier. */
    SHALLOW,
    /** A dock or mooring — where a boat can berth. */
    DOCK,
    /** Land: never navigable. */
    LAND,
    /** A known static obstacle in the water (rocks, wreckage). */
    OBSTACLE,
    /** Mapped, but of a kind we don't classify yet. */
    OTHER,
}

/**
 * A Sailing docking point and the facilities it offers.
 *
 * @property dock where the port is. It is a map position, NOT guaranteed to be water a hull fits in — route
 *   to it with [Sailor], which is hull-aware, rather than steering at it directly.
 * @property requirement a quest or region visit gating the port, empty when there is none. Free text and
 *   NOT machine-checked: a port can be listed and still refuse you.
 *
 * @since 0.29.0
 */
data class SeaPort(
    val name: String,
    val dock: Tile,
    val sailingLevel: Int,
    val requirement: String = "",
    val shipwright: Boolean = false,
    val noticeBoard: Boolean = false,
    val salvagingStation: Boolean = false,
    val ledgerTable: Boolean = false,
    val crewRegistrar: Boolean = false,
    val bankDepositBox: Boolean = false,
)

/**
 * A shipwreck spawn tile.
 *
 * @property tier display name of the wreck tier ("Small", "Fisherman", …).
 * @property sailingLevel level required to salvage that tier.
 *
 * @since 0.29.0
 */
data class SeaWreck(val tier: String, val tile: Tile, val sailingLevel: Int)

/**
 * A buildable boat-facility variant — one tier of one facility type — with what it takes to build.
 *
 * @property type facility type, e.g. "salvaging hook".
 * @property tier tier name, e.g. "Steel"; the in-game facility name is `"$tier $type"`.
 * @property tierRank build order within the type (0 = lowest); use it to find the next tier up.
 * @property sailingLevel Sailing level required to build it.
 * @property constructionLevel Construction level required to build it.
 * @property materials the items to build it, as a quantified `name:qty;…` string (parse with
 *   [io.osrsx.config.Quantified]). Hammer + saw are needed too but are provided at the drydock.
 * @property schematic non-empty only when a read schematic gates the build (e.g. the Dragon hook).
 *
 * @since 0.31.0
 */
data class SeaFacility(
    val type: String,
    val tier: String,
    val tierRank: Int,
    val sailingLevel: Int,
    val constructionLevel: Int,
    val materials: String,
    val schematic: String,
) {
    /**
     * The in-game facility name — what the build interface lists it as. Multi-tier facilities are
     * "<tier> <type>" ("Steel salvaging hook"); single-variant facilities carry an empty [tier] and are
     * named by [type] alone ("Range", "Wind catcher").
     */
    val displayName: String get() = if (tier.isBlank()) type else "$tier $type"

    /** True when this is one of several tiers of a type (a hook/cannon/net/hold), vs a single-variant facility. */
    val tiered: Boolean get() = tier.isNotBlank()
}
