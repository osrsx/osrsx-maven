package io.osrsx.util

import java.util.concurrent.ThreadLocalRandom
import kotlin.math.roundToLong

/**
 * Central randomness source for humanized timing.
 *
 * Backed by [ThreadLocalRandom] so there's no shared-state contention across bot threads and no seeding
 * to manage. Every range is inclusive and order-insensitive — callers never have to pre-sort their args,
 * and degenerate ranges (`lo == hi`, negative spreads) collapse gracefully instead of throwing.
 *
 * Prefer these over ad-hoc `Math.random() * X` / `Random().nextInt(...)` copies: a single, testable
 * source of jitter is easier to reason about and keeps timing distributions consistent (and, per
 * `docs/DETECTION_HARDENING.md`, non-regular).
 */
object Rng {
    /** Uniform long in `[minMs, maxMs]` (inclusive). Order-insensitive; equal bounds return that value. */
    fun uniform(minMs: Long, maxMs: Long): Long {
        val lo = minOf(minMs, maxMs)
        val hi = maxOf(minMs, maxMs)
        return if (lo == hi) lo else ThreadLocalRandom.current().nextLong(lo, hi + 1)
    }

    fun uniform(minMs: Int, maxMs: Int): Long = uniform(minMs.toLong(), maxMs.toLong())

    /** Uniform int in `[lo, hi]` (inclusive) — the drop-in for scattered `randInt`/`nextInt(hi-lo)` copies. */
    fun uniformInt(lo: Int, hi: Int): Int {
        val a = minOf(lo, hi)
        val b = maxOf(lo, hi)
        return if (a == b) a else ThreadLocalRandom.current().nextInt(a, b + 1)
    }

    /**
     * Clamped normal draw: a `Gaussian(meanMs, sdMs)` sample squeezed into `[minMs, maxMs]`. Human
     * reaction and settle times are bell-shaped, not flat — most draws cluster near the mean with rare
     * tails — so this is the right shape for reaction lag and inter-action pauses.
     */
    fun gaussian(meanMs: Double, sdMs: Double, minMs: Long, maxMs: Long): Long {
        val lo = minOf(minMs, maxMs)
        val hi = maxOf(minMs, maxMs)
        if (lo == hi) return lo
        val draw = meanMs + ThreadLocalRandom.current().nextGaussian() * sdMs
        return draw.roundToLong().coerceIn(lo, hi)
    }

    /**
     * Convenience [gaussian] centered at [meanMs] with spread [sdMs], clamped to `[mean - 3σ, mean + 3σ]`
     * (and never below 0) — the usual "no absurd outliers" bound.
     */
    fun gaussian(meanMs: Long, sdMs: Long): Long =
        gaussian(
            meanMs.toDouble(),
            sdMs.toDouble(),
            (meanMs - 3 * sdMs).coerceAtLeast(0),
            meanMs + 3 * sdMs,
        )

    /** Symmetric uniform jitter: [baseMs] ± up to [spreadMs]. Never returns below 0. */
    fun jitter(baseMs: Long, spreadMs: Long): Long {
        if (spreadMs <= 0) return baseMs.coerceAtLeast(0)
        return (baseMs + uniform(-spreadMs, spreadMs)).coerceAtLeast(0)
    }

    /** `true` with probability [p] (clamped to `[0, 1]`). For "sometimes fumble / glance" style forks. */
    fun chance(p: Double): Boolean = ThreadLocalRandom.current().nextDouble() < p.coerceIn(0.0, 1.0)
}
