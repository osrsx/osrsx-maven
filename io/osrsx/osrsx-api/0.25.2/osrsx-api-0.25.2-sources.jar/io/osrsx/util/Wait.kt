package io.osrsx.util

/** Small polling helpers for tick-based game actions (DreamBot's `Sleep.sleepUntil`). */
object Wait {
    /** Humanized defaults for [until]: a small poll-cadence jitter and a Gaussian post-condition settle. */
    const val DEFAULT_POLL_MS = 20L
    const val DEFAULT_POLL_JITTER_MS = 6L
    const val DEFAULT_REACTION_MS = 60L
    const val DEFAULT_REACTION_SD_MS = 25L

    /**
     * Poll [condition] roughly every [pollMs] until it's true or [timeoutMs] elapses, then return its
     * final state. Two humanizations distinguish this from a naive fixed-interval poll:
     *
     *  - **Poll jitter** ([pollJitterMs]): the cadence is jittered by ±[pollJitterMs] so it isn't a
     *    metronomic heartbeat (perfectly regular polling is a behavioural detection tell).
     *  - **Reaction settle** ([reactionMs]/[reactionSdMs]): once the condition flips true we wait a small
     *    clamped-Gaussian delay *before* returning — a human doesn't act the very instant a state appears,
     *    they react in a randomized fraction of a tick. Loose UI/bank/GE/walking callers want this.
     *
     * The `(timeoutMs, pollMs, condition)` shape is preserved (extra params carry humanized defaults and
     * sit before the trailing lambda), so every existing call site keeps compiling. Tick-critical callers
     * that must not miss a game tick use [untilStrict] (no settle, no jitter).
     */
    fun until(
        timeoutMs: Long,
        pollMs: Long = DEFAULT_POLL_MS,
        pollJitterMs: Long = DEFAULT_POLL_JITTER_MS,
        reactionMs: Long = DEFAULT_REACTION_MS,
        reactionSdMs: Long = DEFAULT_REACTION_SD_MS,
        condition: () -> Boolean,
    ): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (condition()) {
                react(reactionMs, reactionSdMs)
                return true
            }
            try {
                Thread.sleep(Rng.jitter(pollMs, pollJitterMs).coerceAtLeast(1))
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                return condition()
            }
        }
        return condition()
    }

    /**
     * Strict, fully deterministic poll: fixed [pollMs] cadence, no jitter, and — crucially — no reaction
     * settle, so it returns the instant the condition flips. Use on tick-critical paths (boss dodges,
     * prayer flicks) and deterministic infrastructure where an added delay could miss a tick or break
     * timing assumptions.
     */
    fun untilStrict(timeoutMs: Long, pollMs: Long = DEFAULT_POLL_MS, condition: () -> Boolean): Boolean =
        until(timeoutMs, pollMs, pollJitterMs = 0, reactionMs = 0, reactionSdMs = 0, condition = condition)

    /** Sleep a uniform `[minMs, maxMs]` ms — a humanized fixed pause. Respects interruption like [until]. */
    fun sleepRand(minMs: Long, maxMs: Long) = sleep(Rng.uniform(minMs, maxMs))

    /** Sleep a clamped-Gaussian pause centered at [meanMs] with spread [sdMs]. Respects interruption. */
    fun sleepGaussian(meanMs: Long, sdMs: Long) = sleep(Rng.gaussian(meanMs, sdMs))

    /**
     * Sleep exactly [ms] ms, swallowing an interrupt by restoring the thread's interrupt flag and
     * returning (the same contract as [until]'s poll). This is the one canonical fixed-duration sleep —
     * route ad-hoc `Thread.sleep` + interrupt-flag boilerplate through here instead of re-implementing it.
     */
    fun sleep(ms: Long) {
        if (ms <= 0) return
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    /** Post-condition human reaction lag: a clamped Gaussian settle in `[0, mean + 3σ]`. */
    private fun react(meanMs: Long, sdMs: Long) {
        if (meanMs <= 0) return
        sleep(Rng.gaussian(meanMs.toDouble(), sdMs.toDouble(), 0, meanMs + 3 * maxOf(sdMs, 0)))
    }
}
