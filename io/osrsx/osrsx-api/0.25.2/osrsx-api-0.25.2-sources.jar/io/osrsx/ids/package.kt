/**
 * Typesafe, engine-free catalogs of Old School RuneScape game ids.
 *
 * Every class in this package is **generated** from RuneLite's cache-derived id tables
 * (`net.runelite.api.gameval.*`) by `tools/generate_game_ids.py`, and re-emitted as Java
 * `static final int` constant classes. This lets a plugin reference an id by name — with
 * no `net.runelite.*` dependency on the SDK surface — while the backing value stays
 * exactly the raw in-game id:
 *
 * ```kotlin
 * import io.osrsx.ids.Items
 * import io.osrsx.ids.Npcs
 *
 * inventory.getItem(Items.ABYSSAL_WHIP)      // 4151
 * npcs.closest(Npcs.GOBLIN)
 * ```
 *
 * ### The catalogs
 * - [Items] — item ids. Noted and bank-placeholder variants live under [Items.Cert] and
 *   [Items.Placeholder] (same names, the noted/placeholder id).
 * - [Npcs], [Objects] (+ [Objects2]) — scene entity ids. [Objects] is split across two
 *   classes only because its table exceeds the JVM's 65535 constant-pool limit per class.
 * - [Interfaces] — interface group ids at the top level, with a nested class per interface
 *   holding its component ids (packed `group shl 16 or child`, matching `Widget.id`).
 * - [Sprites] — sprite ids (top-level + a nested class per UI group).
 * - [Varbits], [VarPlayers] — the varbit / VarPlayer ids read via `Varps`.
 * - [Animations] — animation ids.
 * - [Inventories] — inventory container ids.
 *
 * ### Why Java `static final int`, not a Kotlin `object` of `const val`s or an `enum`
 * The largest tables (items ~33k, objects ~32k, interfaces ~27k) are far past the ~2-3k
 * constant ceiling where a Kotlin/Java `enum` still compiles (the JVM caps a class's
 * `<clinit>` at 64KB). A `static final int` is a compile-time constant — inlined at the
 * use site with no initializer code — so it scales to tens of thousands at zero runtime
 * cost, and Kotlin call sites read identically (`Items.ABYSSAL_WHIP`).
 *
 * Java rather than Kotlin `const val` (which compiles to the same bytecode) because
 * IntelliJ's decompiled-stub builder for Kotlin class files re-parses the entire class
 * file once per const property — O(N²), which made indexing the published jar take hours
 * and froze the IDE. Java constants are stubbed in a single pass.
 *
 * These files are checked in; re-run the generator when RuneLite's tables update.
 */
package io.osrsx.ids
