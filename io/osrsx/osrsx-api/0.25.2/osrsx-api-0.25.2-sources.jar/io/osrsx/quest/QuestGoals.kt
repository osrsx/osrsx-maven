package io.osrsx.quest

import io.osrsx.api.Tile
import io.osrsx.script.ScriptScope

/**
 * A **result** an action is meant to produce — a named predicate over the LIVE game state. It is the missing
 * half of the fire-once actions in [QuestActions]: pairing an action with the result it should achieve lets the
 * engine (a) SKIP the action when the result already holds (free within-stage resume) and (b) RETRY it until
 * the result holds ([achieve]). Every builder here reads only cheap live probes ([hasItem], [hasAction],
 * [inArea], container counts) — never a suspending call — so a [Goal] can be checked inside [ScriptScope.waitUntil].
 *
 * Because a [Goal] re-derives from world state on every check, an action gated on one is **regression-proof**:
 * bank/drop/lose the item it produced and the goal simply reads false again, so the step re-runs. This is why
 * item acquisition ALWAYS uses [achieve]/`until` and never the persisted [QuestStageScope.once] checkpoint.
 *
 * @since 0.21.0
 */
class Goal internal constructor(
    /** Human-readable description of the result, for status + failure messages ("holding 1×#1609"). */
    val describe: String,
    /** True when the result currently holds. Cheap, non-suspending — safe inside a poll. */
    val holds: ScriptScope.() -> Boolean,
)

/** Result: the inventory holds at least [qty] of [item]. */
fun has(item: Int, qty: Int = 1): Goal = Goal("holding $qty×#$item") { inventory.count(item) >= qty }

/** Result: the inventory holds ANY one of [items] (an id + its alternates/degrades). */
fun hasAny(vararg items: Int): Goal = Goal("holding any of ${items.toList()}") { items.any { it in inventory } }

/** Result: [item] is NO LONGER held — it was consumed/handed over/transformed (`useOn` until [gone]). */
fun gone(item: Int): Goal = Goal("no #$item held") { item !in inventory }

/** Result: object/NPC [name] (nearest to [at]) OFFERS menu [action] — e.g. a barrel now shows "Search". */
fun canDo(name: String, action: String, at: Tile? = null): Goal =
    Goal("$name offers '$action'") { hasAction(name, action, at) }

/** Result: object/NPC [name] (nearest to [at]) NO LONGER offers [action] — e.g. an opened barrel lost "Open". */
fun cantDo(name: String, action: String, at: Tile? = null): Goal =
    Goal("$name lacks '$action'") { !hasAction(name, action, at) }

/** Result: something named [name] is present in the loaded scene (object / NPC / ground item). */
fun present(name: String, at: Tile? = null): Goal = Goal("$name in scene") { isObjectPresent(name, at) }

/** Result: nothing named [name] is in the loaded scene (a dug hole filled back in, an NPC despawned). */
fun absent(name: String, at: Tile? = null): Goal = Goal("$name not in scene") { !isObjectPresent(name, at) }

/** Result: the player stands inside [area] (a crossing/cutscene dropped us in the right zone). */
fun inside(area: Area): Goal = Goal("inside area") { inArea(area) }

/** Result: the player is on plane [z] (climbed to/from a floor, dropped underground). */
fun onPlane(z: Int): Goal = Goal("on plane $z") { me?.tile()?.plane == z }

/**
 * Escape hatch for a result not covered by the builders above — supply the [describe] text and the predicate:
 * `goal("chemicals identified") { hasItem(NITROGLYCERIN) && hasItem(AMMONIUM_NITRATE) }`.
 */
fun goal(describe: String, holds: ScriptScope.() -> Boolean): Goal = Goal(describe, holds)

/**
 * Perform [action] until [result] holds, RETRYING up to [tries] times (each try waits [perTryMs] for the result
 * to land, polling every [pollMs]). A **no-op if [result] already holds** — so a stage that re-runs on resume
 * skips a step whose result is already in the world. Throws [QuestActionFailed] if the result never materialises.
 *
 * This is the produce-a-result primitive that collapses the `while (!hasItem(X)) { act(); waitUntil { hasItem(X) } }`
 * boilerplate — for RNG drops (pickpocket → skull, pan → cup), fills (vial → liquid), transforms (identify),
 * and single-shot gets alike. Prefer the `until =` sugar on [search]/[pickpocket]/[useOn]/[interact]/[loot] for
 * the one-liner; drop to [achieve] when the producing body is a small sequence.
 *
 * @since 0.21.0
 */
suspend fun ScriptScope.achieve(
    result: Goal,
    tries: Int = 8,
    perTryMs: Long = 6_000,
    pollMs: Long = 500,
    action: suspend ScriptScope.() -> Unit,
): Boolean {
    if (result.holds(this)) return true
    var attempt = 0
    while (attempt < tries && !isStopping) {
        action()
        if (waitUntil(perTryMs, pollMs) { result.holds(this) }) return true
        attempt++
    }
    // One last check (the deadline poll may have just missed a tick) before declaring failure.
    if (result.holds(this)) return true
    throw QuestActionFailed("achieve — result never reached: ${result.describe} (after $tries attempts)")
}

/**
 * Run [block] only when [result] does NOT already hold — a readable, regression-proof CHECKPOINT for a run of
 * steps that together produce [result]. On resume the block is skipped once its result is in the world, and
 * because [result] re-derives from live state, losing that result (banking the produced item) correctly makes
 * the block run again. Names the ugly `if (!hasA && !hasB && …)` guard:
 * `unless(has(Items.DIGEXPERTSCROLL)) { …get the talisman + turn it in… }`.
 *
 * @since 0.21.0
 */
suspend fun ScriptScope.unless(result: Goal, block: suspend ScriptScope.() -> Unit) {
    if (!result.holds(this)) block()
}
