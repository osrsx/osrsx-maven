package io.osrsx.quest

import io.osrsx.api.DataStore

/**
 * The per-account persisted skip-list for a quest STAGE's irreversible steps ([QuestStageScope.once]). Keyed by
 * quest name + the current progress-var value, so it auto-invalidates the moment the stage advances (a load for
 * a different var reads empty). Backed by [DataStore] (a per-account SQLite file that survives client restarts,
 * and never throws — a read/write failure degrades to "nothing remembered", i.e. full replay).
 *
 * ONLY [QuestStageScope.once] writes here, and only for effects the game never reverts (learning a recipe,
 * revealing a wall, seeing a cutscene). Item acquisition is NEVER persisted — it uses [achieve]/`until`, which
 * re-derive from live state and so re-run when the item is lost. And the driver ([toScript]) can [clear] the
 * whole cursor and replay a stage from scratch whenever it detects no forward progress, so a stale/bad skip can
 * never hard-deadlock the quest.
 *
 * Stored value format (one string per quest key): the stage-var value, then one label per line:
 * `"6\ndescend-west-reveal-wall\nlearn-recipe-from-doug"`. Newline is a safe separator — a [QuestStageScope.once]
 * label is a single-line human string, never multi-line.
 *
 * @since 0.21.0
 */
internal class QuestCursor(
    private val store: DataStore,
    private val quest: String,
    private val stageVar: Int,
) {
    private val done: MutableSet<String> = load()

    /** How many steps are marked done for the current stage window — the driver's forward-progress signal. */
    val doneCount: Int get() = done.size

    fun isDone(label: String): Boolean = label in done

    /** Record [label] as completed (persists immediately, so it survives a restart mid-stage). */
    fun mark(label: String) {
        if (done.add(label)) persist()
    }

    /** Forget every checkpoint for this quest — the driver's stall backstop: forces a full stage replay. */
    fun clear() {
        done.clear()
        store.remove(NS, quest)
    }

    private fun load(): MutableSet<String> {
        val raw = store.get(NS, quest) ?: return linkedSetOf()
        val lines = raw.split('\n')
        // A stored record for a DIFFERENT stage var is stale (we've advanced) → start fresh.
        if (lines.firstOrNull()?.toIntOrNull() != stageVar) return linkedSetOf()
        return lines.drop(1).filterTo(linkedSetOf()) { it.isNotEmpty() }
    }

    private fun persist() {
        store.put(NS, quest, (listOf(stageVar.toString()) + done).joinToString("\n"))
    }

    private companion object {
        const val NS = "quests.cursor"
    }
}
