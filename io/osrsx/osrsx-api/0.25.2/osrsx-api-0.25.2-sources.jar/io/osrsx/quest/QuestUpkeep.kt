package io.osrsx.quest

import io.osrsx.script.ScriptScope

/**
 * The reactive-upkeep plumbing: a quest declares `upkeep { eatIfLow(50); cureVenom() }` and that block runs on a
 * throttle **inside the long poll loops** ([walkTo]/[approach]/[take]) — so healing and curing happen continuously,
 * including WHILE web-walking between objectives, not only between stages ([beforeEach] already covers the latter).
 *
 * Mechanism: the quest coroutine is confined to its plugin's single loop thread for its whole life (the runner
 * has no dispatcher and never hops threads), so a [ThreadLocal] is a safe, dependency-free carrier — the driver
 * arms it once and the poll loops drain it. No coroutine-context surgery, no SDK-interface change.
 *
 * @since 0.22.0
 */

private class UpkeepState(val block: suspend ScriptScope.() -> Unit) {
    var lastRunMs: Long = 0
    var running: Boolean = false // reentrancy guard — upkeep must never re-enter itself
}

/** Per-thread (⇒ per-plugin) installed upkeep. Safe as a ThreadLocal: the script never leaves its loop thread. */
private val UPKEEP = ThreadLocal<UpkeepState?>()

/** Arm (or clear, with null) the upkeep block for the CURRENT loop thread. Called once by the driver. */
internal fun installUpkeep(block: (suspend ScriptScope.() -> Unit)?) {
    UPKEEP.set(block?.let { UpkeepState(it) })
}

/**
 * Run the installed upkeep block if at least [minGapMs] has elapsed since its last run — otherwise a cheap no-op.
 * Reentrancy-guarded, and it SWALLOWS a [QuestActionFailed] so a hiccup in upkeep (nothing to eat, a missed click)
 * can never abort the host action it's interleaved into.
 */
internal suspend fun ScriptScope.tickUpkeep(minGapMs: Long = 700) {
    val s = UPKEEP.get() ?: return
    if (s.running || nowMs() - s.lastRunMs < minGapMs) return
    s.running = true
    try {
        s.block(this)
    } catch (_: QuestActionFailed) {
        // upkeep is best-effort maintenance — never let it fail the walk/gather it's riding inside
    } finally {
        s.lastRunMs = nowMs()
        s.running = false
    }
}

/**
 * [ScriptScope.waitUntil], but it runs [tickUpkeep] each poll — the upkeep-aware wait the long movement/gather
 * loops use so healing/curing fires mid-walk. Identical semantics otherwise (→ true when [condition] holds, →
 * false at [timeoutMs], cooperative [park] between polls). Short waits (dialogue continues, equip confirms)
 * deliberately keep the plain [ScriptScope.waitUntil] — upkeep mid-dialogue could misclick.
 */
internal suspend fun ScriptScope.waitUntilUpkeep(timeoutMs: Long, pollMs: Long, condition: () -> Boolean): Boolean {
    val deadline = nowMs() + timeoutMs
    while (true) {
        checkStop()
        if (condition()) return true
        tickUpkeep()
        val remaining = deadline - nowMs()
        if (remaining <= 0) return condition() // one final check at the deadline
        park(minOf(pollMs, remaining))
    }
}
