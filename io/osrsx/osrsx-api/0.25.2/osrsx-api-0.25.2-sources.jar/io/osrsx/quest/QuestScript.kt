package io.osrsx.quest

import io.osrsx.script.Script
import io.osrsx.script.ScriptDslPlugin
import io.osrsx.script.ScriptScope
import io.osrsx.script.script

/**
 * Compile a [Quest] to a runnable [Script] — the whole quest is one cooperative coroutine on the existing
 * [io.osrsx.script.ScriptRunner]. The driver: read the progress var, provision on a fresh start, run the
 * stage that handles the current var value, and repeat until FINISHED. No reactive state detection, no
 * headless Quest-Helper host — one var read per loop and idempotent actions.
 *
 * @since 0.20.0
 */
fun Quest.toScript(): Script = script(name) { drive(this@toScript) }

private suspend fun ScriptScope.drive(quest: Quest) {
    // Prerequisite skills — asserted once (log-only; we still attempt, and provisioning/actions surface the rest).
    quest.needs.skills.forEach { (skill, lvl) ->
        val have = skills.real(skill)
        if (have < lvl) log.w("quest '${quest.name}': needs $skill $lvl (have $have) — may get stuck")
    }

    // Complete when the progress var reaches [finishedValue] OR advances past every stage we defined — the
    // latter makes completion robust to an imprecise finishedValue (a common unknown for f2p varplayer quests
    // whose Quest Helper completeValue is -1): once the var is beyond the last stage, the quest is done.
    val lastStageVar = quest.stages.flatMap { it.varValues }.maxOrNull() ?: quest.finishedValue
    // Stall backstop for the persisted `once` cursor: track the stage window we're in and how many passes have
    // made NO forward progress (var unchanged AND no new checkpoint). After [STALL_PASSES] such passes we wipe the
    // stage's checkpoints and replay it in full, so a stale/regressed/misused `once` skip can never hard-deadlock.
    var stallVar = Int.MIN_VALUE
    var noProgress = 0
    // Arm the quest's reactive upkeep on THIS loop thread so it fires inside the long walks/gathers (eat/cure
    // mid-route); always cleared in the finally so a hot-reloaded plugin can't inherit a stale block.
    installUpkeep(quest.upkeep)
    try {
    while (!isStopping) {
        advanceIncidentalDialogue() // clear stray continue-only chat before doing anything (see below)
        val v = quest.progress.read(varps)
        // A custom [complete] predicate (for a bitmask/region-based quest) replaces the default var-threshold check.
        val done = quest.complete?.invoke(this) ?: (v >= quest.finishedValue || v > lastStageVar)
        if (done) {
            dataStore.remove("quests.cursor", quest.name) // tidy the persisted cursor once the quest is done
            status("${quest.name} — complete ✓"); return
        }

        // Fresh-start provisioning ONLY (v == NOT_STARTED): the loadout deposits foreign junk to free space,
        // which is safe before the quest starts but would bank quest-progress items once it's underway.
        if (v == NOT_STARTED && !quest.needs.isEmpty) {
            val lo = quest.needs.toLoadout(this)
            if (!loadouts.isSatisfied(lo)) {
                status("${quest.name} — provisioning")
                loadouts.apply(lo)
                park(600)
                continue
            }
        }

        // Recommended provisioning (best-effort): after needs, before the quest starts. Bounded tries so an
        // unaffordable/uncoverable `wants` item is simply done without rather than blocking the start.
        if (v == NOT_STARTED && !quest.wants.isEmpty) {
            val lo = quest.wants.toLoadout(this)
            var tries = 0
            while (!isStopping && !loadouts.isSatisfied(lo) && tries++ < 3) {
                status("${quest.name} — provisioning (recommended)")
                loadouts.apply(lo)
                park(600)
            }
        }

        val stage = quest.stageFor(v)
        if (stage == null) { status("${quest.name} — waiting (var=$v)"); sleep(1200); continue }

        // Fresh cursor per pass (a cheap local-SQLite read); it auto-resets to empty when [v] differs from the
        // stored stage var. Reset the stall counter whenever we enter a NEW stage window.
        val cursor = QuestCursor(dataStore, quest.name, v)
        if (v != stallVar) { stallVar = v; noProgress = 0 }
        val doneBefore = cursor.doneCount

        status("${quest.name} — ${stage.label}")
        try {
            quest.beforeEach?.invoke(this)
            stage.body(QuestStageScope(this, cursor))
            yieldTick() // re-read the var; if the stage advanced it we move on, else the stage re-runs (idempotent)
        } catch (e: QuestActionFailed) {
            // The failed action already blocked/retried internally and gave up — the stage ABORTS here rather
            // than falling through to its next action (which would run without the failed one's outcome, e.g.
            // talking on without the quest item it should be holding). Log where it died and re-run the stage
            // from the top after a beat: the actions are idempotent, so completed steps no-op on the retry.
            log.w("quest '${quest.name}' [${stage.label}]: ${e.message} — re-running the stage")
            sleep(2_000)
        }

        // Forward progress = the var advanced OR a new `once` checkpoint landed this pass. Otherwise count the
        // stall; on the threshold, clear the checkpoints so the next pass replays the whole stage from scratch.
        val advanced = quest.progress.read(varps) != v || cursor.doneCount > doneBefore
        if (advanced) {
            noProgress = 0
        } else if (++noProgress >= STALL_PASSES) {
            log.w("quest '${quest.name}' [${stage.label}]: no progress in $noProgress passes — clearing checkpoints, full replay")
            cursor.clear()
            noProgress = 0
        }
    }
    } finally {
        installUpkeep(null)
    }
}

/** Consecutive no-progress stage passes before the driver wipes the persisted [QuestStageScope.once] cursor and
 *  replays the stage in full — the backstop that stops a stale/bad checkpoint skip from hard-deadlocking. */
private const val STALL_PASSES = 4

/**
 * Auto-advance an INCIDENTAL **continue-only** dialogue — a greeting/refusal/message that fires from an
 * object interaction, entering an area, or a cutscene ending, OUTSIDE any explicit [talkTo] (e.g. the
 * Rehnison door's "Go away. We don't want any.", or the "You tie the rope to the grill." objectbox after a
 * `useOn`). Run at the top of every driver loop so such chat can never wedge an action or make a stage fall
 * through. Options-bearing dialogues are deliberately left UNTOUCHED — a real choice belongs to a stage's
 * [talkTo] with its stated options, never a blind auto-pick. The guard bounds a genuinely stuck prompt (one
 * that reports "can continue" but won't close) so this can't spin forever.
 */
private suspend fun ScriptScope.advanceIncidentalDialogue() {
    var guard = 0
    while (dialogues.inDialogue() && dialogues.getOptions().isEmpty() && !isStopping && guard++ < 15) {
        if (!dialogues.continueAuto()) break
        park(650)
    }
}

/**
 * A [io.osrsx.plugin.Plugin] that runs a single [Quest] authored with the [quest] DSL. Override [define] with
 * the quest; the base drives it on the coroutine engine (via [ScriptDslPlugin]) and renders a status panel.
 *
 * ```
 * class CooksAssistant : QuestScript() {
 *     override fun define() = quest("Cook's Assistant", varPlayer(VarPlayers.COOKQUEST), finished = 2) { … }
 * }
 * ```
 *
 * @since 0.20.0
 */
abstract class QuestScript : ScriptDslPlugin() {

    /** The quest this plugin runs. Pure (no [ctx]) — the DSL only records declarations + action lambdas. */
    abstract fun define(): Quest

    final override fun script(): Script = define().toScript()
}
