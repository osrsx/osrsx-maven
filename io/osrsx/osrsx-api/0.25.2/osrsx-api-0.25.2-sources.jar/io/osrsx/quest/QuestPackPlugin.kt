package io.osrsx.quest

import io.osrsx.script.Script
import io.osrsx.script.ScriptDslPlugin
import io.osrsx.script.script

/**
 * A [io.osrsx.plugin.Plugin] that bundles MANY quests and runs the one picked in config — the efficient
 * shape for authoring/porting a large quest library (one build verifies every quest). Subclasses supply a
 * [catalog] (display name → quest builder) and the [selected] name; the base drives the chosen quest on the
 * coroutine engine.
 *
 * ```
 * class QuestPack : QuestPackPlugin() {
 *     object Config : PluginConfig("quests") {
 *         var quest by enumItem("quest", "Quest", QUESTS.keys.first(), options = QUESTS.keys.toList())
 *     }
 *     override fun config() = Config
 *     override fun catalog() = QUESTS
 *     override fun selected() = Config.quest
 * }
 * ```
 *
 * @since 0.20.0
 */
abstract class QuestPackPlugin : ScriptDslPlugin() {

    /** Display name → quest builder, for every quest this pack can run. */
    abstract fun catalog(): Map<String, () -> Quest>

    /** The currently-selected quest's display name (typically from config). */
    abstract fun selected(): String

    final override fun script(): Script {
        val build = catalog()[selected()] ?: catalog().values.firstOrNull()
        return build?.invoke()?.toScript() ?: script("quest") { status("No quest selected"); sleep(3_000) }
    }
}
