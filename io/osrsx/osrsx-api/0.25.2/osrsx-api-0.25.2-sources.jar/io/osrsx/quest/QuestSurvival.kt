package io.osrsx.quest

import io.osrsx.ids.VarPlayers
import io.osrsx.script.ScriptScope

/**
 * Survival helpers for quests whose route crosses aggressive or poisonous monsters — read the player's
 * poison/venom state and drink the right cure. All are cheap live-state reads (safe inside a poll / an
 * [upkeep] block).
 *
 * Poison state is the RuneLite [VarPlayers.POISON] (varp 102), whose sign/magnitude encode everything (fork
 * `VarPlayer.java`, mirrored by the client's `PoisonPlugin`): `< 0` we're already immune (a cure is active),
 * `0` clean, `1..999_999` ordinary poison ticking, `>= 1_000_000` envenomed.
 *
 * @since 0.22.0
 */

/** The venom cutoff — at or above this the poison varp means ENVENOMED, below it (and > 0) ordinary poison. */
private const val VENOM_THRESHOLD = 1_000_000

/** Anti-venom / anti-venom+ / extended anti-venom+ (4→1 doses) — the ONLY potions that cure venom (they also cure poison). */
private val VENOM_CURES = intArrayOf(
    12913, 12915, 12917, 12919,   // Anti-venom+ (4..1)
    12905, 12907, 12909, 12911,   // Anti-venom (4..1)
    29824, 29827, 29830, 29833,   // Extended anti-venom+ (4..1)
)

/** Antidote++ / antidote+ / super-antipoison / antipoison (4→1 doses) — cure ordinary poison only, not venom. */
private val POISON_CURES = intArrayOf(
    5952, 5954, 5956, 5958,       // Antidote++ (4..1)
    5943, 5945, 5947, 5949,       // Antidote+ (4..1)
    181, 183, 185,                // Super-antipoison (3..1)
    2448,                         // Super-antipoison (4)
    2446, 175, 177, 179,          // Antipoison (4..1)
)

/** True while ordinary poison is ticking (not venom, and not already cured/immune). */
fun ScriptScope.isPoisoned(): Boolean = varps.varp(VarPlayers.POISON) in 1 until VENOM_THRESHOLD

/** True while envenomed (poison varp at or past the venom cutoff). */
fun ScriptScope.isEnvenomed(): Boolean = varps.varp(VarPlayers.POISON) >= VENOM_THRESHOLD

/** True while taking poison OR venom damage — a cure is warranted (false if clean, or already immune from a prior cure). */
fun ScriptScope.isPoisonedOrEnvenomed(): Boolean = varps.varp(VarPlayers.POISON) > 0

/**
 * Drink a held cure if we're poisoned or envenomed — the reactive counter to the aggressive/poisonous monsters a
 * quest route passes. A no-op if we're clean (or already immune, varp < 0) or hold no suitable cure, so it's safe
 * to call every poll (e.g. from an [upkeep] block, which is exactly what runs it mid-walk).
 *
 * Picks the RIGHT cure for the state: envenomed → only an anti-venom clears it; ordinary poison → any antidote /
 * antipoison (venom cures work too, but those are tried last so they're saved for actual venom). Returns whether
 * a potion was drunk.
 */
suspend fun ScriptScope.cureVenom(): Boolean {
    val v = varps.varp(VarPlayers.POISON)
    if (v <= 0) return false
    val cures = if (v >= VENOM_THRESHOLD) VENOM_CURES else POISON_CURES + VENOM_CURES
    val potion = cures.asSequence().mapNotNull { inventory.getItem(it) }.firstOrNull() ?: return false
    inventory.interact(potion, "Drink")
    park(600)
    return true
}
