package io.osrsx.quest

import io.osrsx.api.ItemRef
import io.osrsx.api.Loadout
import io.osrsx.api.OsrsxDsl
import io.osrsx.api.RestockSpec
import io.osrsx.api.Skill
import io.osrsx.api.Varps
import io.osrsx.api.loadout

/**
 * A quest as **data + actions**, not text. The runtime engine ([toScript]) drives it: read the quest's
 * progress var, run the [QuestStage] that handles that value, repeat. Because we perform the actions, we
 * never *detect* fine-grained state — the var is a coarse resume pointer and each action observes its own
 * completion. This is the osrsx counterpart to RuneLite's Quest Helper, which only *highlights* for a human;
 * here every step is an executable, idempotent SDK action.
 *
 * Build one with the [quest] DSL. Run it from a [QuestScript] plugin (single quest) or a quest-pack host.
 *
 * @since 0.20.0
 */
class Quest internal constructor(
    val name: String,
    /** The engine varbit/varplayer Jagex increments as the quest progresses — our stage selector + resume anchor. */
    val progress: QuestVar,
    /** The var value at (or above) which the quest is FINISHED. */
    val finishedValue: Int,
    /** Bring-list provisioned on a fresh start (never mid-quest, so quest-progress items are never banked). */
    val needs: Needs,
    /** Recommended, best-effort provisioning (bank, else an affordable GE buy) on a fresh start — see [QuestBuilder.wants]. */
    val wants: Wants,
    /** Optional guard run before EVERY stage pass — see [QuestBuilder.beforeEach]. */
    val beforeEach: (suspend io.osrsx.script.ScriptScope.() -> Unit)?,
    /** Optional reactive maintenance run on a throttle INSIDE the long walks/gathers — see [QuestBuilder.upkeep]. */
    val upkeep: (suspend io.osrsx.script.ScriptScope.() -> Unit)?,
    /** Optional custom "is the quest finished?" test — for quests whose progress var isn't monotonic (a bitmask,
     *  a region-based maze). When set it REPLACES the default `v >= finishedValue || v > lastStage` check. */
    val complete: (io.osrsx.script.ScriptScope.() -> Boolean)?,
    /** Optional fallback stage run when no [stages] entry matches the current var — see [QuestBuilder.otherwise]. */
    val defaultStage: QuestStage?,
    /** Ordered stages, each handling one or more progress-var values. */
    val stages: List<QuestStage>,
) {
    /** The stage handling progress-var value [v], the [defaultStage] if none matches, or null. */
    fun stageFor(v: Int): QuestStage? = stages.firstOrNull { v in it.varValues } ?: defaultStage
}

/** One stage of a quest: the actions to run while the progress var equals one of [varValues]. */
class QuestStage internal constructor(
    val label: String,
    val varValues: Set<Int>,
    /** The stage's actions — an ordered, idempotent [suspend] body over a [QuestStageScope] (a [io.osrsx.script.ScriptScope]
     *  plus the persisted [QuestStageScope.once] checkpoint). */
    val body: suspend QuestStageScope.() -> Unit,
)

/** How a quest's progress is read from the engine — a varbit or a varplayer. */
sealed interface QuestVar {
    fun read(varps: Varps): Int
}

private class QuestVarbit(val id: Int) : QuestVar {
    override fun read(varps: Varps): Int = varps.varbit(id)
}

private class QuestVarPlayer(val id: Int) : QuestVar {
    override fun read(varps: Varps): Int = varps.varp(id)
}

/** The quest's progress is a **varbit** (`io.osrsx.ids.Varbits.*`). */
fun varbit(id: Int): QuestVar = QuestVarbit(id)

/** The quest's progress is a **varplayer** (`io.osrsx.ids.VarPlayers.*`). */
fun varPlayer(id: Int): QuestVar = QuestVarPlayer(id)

/** The progress-var value of a not-yet-started quest. */
const val NOT_STARTED: Int = 0

// -------------------------------------------------------------------------------------------------------
// DSL
// -------------------------------------------------------------------------------------------------------

/**
 * Author a [Quest].
 *
 * ```
 * quest("Cook's Assistant", varPlayer(VarPlayers.COOKQUEST), finished = 2) {
 *     needs { item(Items.EGG); item(Items.BUCKET_OF_MILK); item(Items.POT_OF_FLOUR) }
 *     stage(NOT_STARTED) { talkTo("Cook", at = Tiles.LUMBRIDGE_KITCHEN) { choose("Yes.") } }
 *     stage(1)           { give("Cook", Items.EGG, Items.BUCKET_OF_MILK, Items.POT_OF_FLOUR) }
 * }
 * ```
 *
 * @since 0.20.0
 */
fun quest(name: String, progress: QuestVar, finished: Int, block: QuestBuilder.() -> Unit): Quest =
    QuestBuilder(name, progress, finished).apply(block).build()

@OsrsxDsl
class QuestBuilder internal constructor(
    private val name: String,
    private val progress: QuestVar,
    private val finished: Int,
) {
    private var needs = Needs()
    private var wants = Wants()
    private var beforeEach: (suspend io.osrsx.script.ScriptScope.() -> Unit)? = null
    private var upkeep: (suspend io.osrsx.script.ScriptScope.() -> Unit)? = null
    private var complete: (io.osrsx.script.ScriptScope.() -> Boolean)? = null
    private var defaultStage: QuestStage? = null
    private val stages = mutableListOf<QuestStage>()

    /** Declare what the quest needs, provisioned on a fresh start (bank → GE → inventory). */
    fun needs(block: NeedsBuilder.() -> Unit) {
        needs = NeedsBuilder().apply(block).build()
    }

    /**
     * Declare RECOMMENDED (not required) items — provisioned best-effort on a fresh start: withdrawn from the
     * bank if present, else bought from the GE only when affordable within [budgetGp] (across the whole list,
     * capped at coins on hand). Anything neither banked nor affordable is simply done without — a `wants` item
     * never blocks the quest. Use for food, an antipoison, weight-reducing gear: things that help but aren't
     * mandatory. Provisioned AFTER [needs], and (like needs) only when the quest hasn't started.
     *
     * ```
     * wants(budget = 8_000) { food(6); anyOf(Items.ANTIPOISON4, Items.ANTIDOTE4) }
     * ```
     */
    fun wants(budget: Int = 10_000, block: WantsBuilder.() -> Unit) {
        wants = WantsBuilder().apply(block).build(budget)
    }

    /**
     * Reactive maintenance run on a ~700ms throttle INSIDE the long movement/gather loops (`walkTo`/`approach`/
     * `take`) as well as between stages — so it fires WHILE web-walking, not only at stage boundaries. The place
     * for "keep me alive on the way there": `upkeep { eatIfLow(50); cureVenom() }`.
     *
     * Must be CHEAP and inventory-only — it runs between polls of an in-flight walk, so it must NOT itself walk
     * (issuing another `walkTo` would fight the host walk) and must not throw meaningfully (a thrown
     * [QuestActionFailed] is swallowed so upkeep can never abort the action it rides inside).
     */
    fun upkeep(body: suspend io.osrsx.script.ScriptScope.() -> Unit) { upkeep = body }

    /**
     * Run [body] before EVERY stage pass — an opportunistic guard for cross-stage concerns, e.g. grabbing a
     * mid-quest item whenever we happen to be near its spawn:
     * `beforeEach { if (!hasItem(PICTURE) && isObjectPresent(PICTURE)) take(PICTURE) }`.
     *
     * Must be idempotent and CHEAP in the common case (scene/inventory probes, not walks) — it runs on every
     * driver loop. A [QuestActionFailed] thrown inside it aborts the pass exactly like a stage action would
     * (logged, then the loop retries).
     */
    fun beforeEach(body: suspend io.osrsx.script.ScriptScope.() -> Unit) { beforeEach = body }

    /**
     * A stage handling progress-var value(s) [values]. Its [body] is an ordered list of idempotent actions;
     * when the var advances past [values] the engine moves on, and re-entering the stage after a restart just
     * re-runs the not-yet-done tail (actions no-op when already satisfied).
     */
    fun stage(vararg values: Int, label: String = "Stage ${values.joinToString(",")}", body: suspend QuestStageScope.() -> Unit) {
        stages += QuestStage(label, values.toSet(), body)
    }

    /**
     * The fallback stage — run whenever the progress var matches no explicit [stage]. For a quest whose var isn't a
     * clean per-stage counter (a random-room maze dispatched by zone, a bitmask var), put the dispatch here and use
     * [complete] to say when it's done. There is at most one; a later call replaces it.
     */
    fun otherwise(label: String = "Active", body: suspend QuestStageScope.() -> Unit) {
        defaultStage = QuestStage(label, emptySet(), body)
    }

    /**
     * Custom "is the quest finished?" test, REPLACING the default `var >= finished` check — for a quest whose
     * progress var isn't monotonic (a bitmask, or completion best read from the world: `complete { varps.varp(X) != 0
     * && me?.tile() !in mazeArea }`). Evaluated each loop before stage dispatch; true ⇒ the driver stops.
     */
    fun complete(predicate: io.osrsx.script.ScriptScope.() -> Boolean) { complete = predicate }

    internal fun build(): Quest = Quest(name, progress, finished, needs, wants, beforeEach, upkeep, complete, defaultStage, stages.toList())
}

// -------------------------------------------------------------------------------------------------------
// Requirements
// -------------------------------------------------------------------------------------------------------

/** One item the quest must bring, over its id alternates (any one satisfies). */
class NeedItem internal constructor(val ids: List<Int>, val amount: Int, val equip: Boolean)

/** Declarative bring-list + prerequisites; compiled to a [Loadout] at runtime (so `food` picks the best in-bank). */
class Needs internal constructor(
    val items: List<NeedItem> = emptyList(),
    val foodAmount: Int = 0,
    val coins: Int = 0,
    val skills: Map<Skill, Int> = emptyMap(),
) {
    val isEmpty: Boolean get() = items.isEmpty() && foodAmount == 0 && coins == 0
}

@OsrsxDsl
class NeedsBuilder internal constructor() {
    private val items = mutableListOf<NeedItem>()
    private var foodAmount = 0
    private var coins = 0
    private val skills = mutableMapOf<Skill, Int>()

    /** Bring [amount] of item [id]. */
    fun item(id: Int, amount: Int = 1) { items += NeedItem(listOf(id), amount, equip = false) }

    /** Bring [amount] satisfied by ANY of [ids] (preferred first). */
    fun anyOf(vararg ids: Int, amount: Int = 1) { items += NeedItem(ids.toList(), amount, equip = false) }

    /** Have [ids] WORN (provisioned equipped). */
    fun equip(vararg ids: Int) { for (id in ids) items += NeedItem(listOf(id), 1, equip = true) }

    /** Bring [amount] of the best tanking food currently in the bank. */
    fun food(amount: Int = 6) { foodAmount = amount }

    /** Bring [amount] coins. */
    fun coins(amount: Int) { coins = amount }

    /** A skill level the quest needs (asserted before starting; blocks with a clear reason if unmet). */
    fun skill(skill: Skill, level: Int) { skills[skill] = level }

    internal fun build(): Needs = Needs(items.toList(), foodAmount, coins, skills.toMap())
}

// -------------------------------------------------------------------------------------------------------
// Recommended items (wants) — best-effort, affordability-gated
// -------------------------------------------------------------------------------------------------------

/** Declarative RECOMMENDED bring-list + a GE spend budget; compiled to a best-effort [Loadout] at provision time. */
class Wants internal constructor(
    val items: List<NeedItem> = emptyList(),
    val foodAmount: Int = 0,
    /** Total gp the provisioner may spend buying wanted items from the GE (also capped at coins on hand). */
    val budgetGp: Int = 0,
) {
    val isEmpty: Boolean get() = items.isEmpty() && foodAmount == 0
}

@OsrsxDsl
class WantsBuilder internal constructor() {
    private val items = mutableListOf<NeedItem>()
    private var foodAmount = 0

    /** Want [amount] of item [id]. */
    fun item(id: Int, amount: Int = 1) { items += NeedItem(listOf(id), amount, equip = false) }

    /** Want [amount] satisfied by ANY of [ids] (preferred first) — e.g. any dose of an antipoison. */
    fun anyOf(vararg ids: Int, amount: Int = 1) { items += NeedItem(ids.toList(), amount, equip = false) }

    /** Want [ids] WORN if affordable (weight-reducing gear). */
    fun equip(vararg ids: Int) { for (id in ids) items += NeedItem(listOf(id), 1, equip = true) }

    /** Want [amount] of the best tanking food the bank holds (never bought — food is situational). */
    fun food(amount: Int = 6) { foodAmount = amount }

    internal fun build(budgetGp: Int): Wants = Wants(items.toList(), foodAmount, budgetGp)
}

private const val COINS = 995

/**
 * Compile [Wants] to a best-effort [Loadout]: each item is withdrawn from the bank if present, else marked for a
 * GE buy ONLY while the running GE spend stays within [Wants.budgetGp] (and coins on hand). Bank-only and
 * unaffordable items are declared `optional` (or omitted), so provisioning never blocks on a recommended item.
 * Affordability is computed here because the loadout engine has no gp budget — it buys whatever it's told to.
 */
internal fun Wants.toLoadout(scope: io.osrsx.script.ScriptScope): Loadout {
    var remaining = budgetGp.coerceAtMost(scope.bank.count(COINS) + scope.inventory.count(COINS)).toLong()
    return loadout("Wants") {
        for (n in items) {
            val ids = n.ids.filter { it > 0 }
            if (ids.isEmpty()) continue
            val qty = n.amount.coerceAtLeast(1)
            val banked = ids.any { scope.bank.count(it) >= qty }
            val buyId = ids.firstOrNull { scope.prices.price(it) > 0 || scope.grandExchange.guidePrice(it) > 0 }
            val unit = buyId?.let { scope.prices.price(it).takeIf { p -> p > 0 } ?: scope.grandExchange.guidePrice(it) } ?: 0
            val cost = unit.toLong() * qty * 130 / 100 // +30% headroom, matching the needs restock markup
            when {
                // In the bank → withdraw only (optional: never buys, never blocks provisioning).
                banked ->
                    if (n.equip) equip(ItemRef.AnyOf(ids), quantity = qty, optional = true)
                    else item(ItemRef.AnyOf(ids), quantity = qty, minimum = qty, optional = true)
                // Buyable AND within the remaining budget → allow a GE buy (a restock only fires when non-optional).
                buyId != null && cost in 1..remaining -> {
                    remaining -= cost
                    val restock = RestockSpec(ItemRef.ById(buyId), qty, markupPercent = 30)
                    if (n.equip) equip(ItemRef.AnyOf(ids), quantity = qty, optional = false, restock = restock)
                    else item(ItemRef.AnyOf(ids), quantity = qty, minimum = qty, optional = false, restock = restock)
                }
                // Neither banked nor worth buying → omit entirely (a recommended item we simply do without).
                else -> {}
            }
        }
        if (foodAmount > 0) {
            val foodId = FOOD_BY_HEAL.firstOrNull { scope.bank.count(it) + scope.inventory.count(it) > 0 }
            if (foodId != null) item(ItemRef.ById(foodId), quantity = foodAmount, minimum = foodAmount, optional = true)
        }
    }
}

/** Common tanking foods, best heal first — the runtime provisioner brings the highest-ranked one the bank holds. */
internal val FOOD_BY_HEAL = intArrayOf(
    13441, 391, 11936, 397, 385, 3144, 7946, 365, 373, 379, 351, 361, 329, 333, 1891, 2309, 2140, 2142,
)

/**
 * Compile the [Needs] to a [Loadout] using the live containers/prices (so `food` resolves to the best banked
 * food, and buyable items get a GE restock). Runs at provisioning time on the driver's scope.
 */
internal fun Needs.toLoadout(scope: io.osrsx.script.ScriptScope): Loadout = loadout("Quest") {
    for (n in items) {
        val ids = n.ids.filter { it > 0 }
        if (ids.isEmpty()) continue
        val qty = n.amount.coerceAtLeast(1)
        val buyId = ids.firstOrNull { scope.prices.price(it) > 0 || scope.grandExchange.guidePrice(it) > 0 }
        val restock = buyId?.let { RestockSpec(ItemRef.ById(it), qty, markupPercent = 30) }
        if (n.equip) equip(ItemRef.AnyOf(ids), quantity = qty, optional = buyId == null, restock = restock)
        else item(ItemRef.AnyOf(ids), quantity = qty, minimum = qty, optional = buyId == null, restock = restock)
    }
    if (coins > 0) item(ItemRef.ById(995), quantity = coins, minimum = coins, optional = true)
    if (foodAmount > 0) {
        val foodId = FOOD_BY_HEAL.firstOrNull { scope.bank.count(it) + scope.inventory.count(it) > 0 }
        if (foodId != null) item(ItemRef.ById(foodId), quantity = foodAmount, minimum = foodAmount, optional = true)
    }
}
