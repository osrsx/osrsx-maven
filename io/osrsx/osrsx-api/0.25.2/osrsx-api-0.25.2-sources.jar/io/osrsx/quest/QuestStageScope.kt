package io.osrsx.quest

import io.osrsx.api.OsrsxDsl
import io.osrsx.script.ScriptScope

/**
 * The receiver a [QuestStage] body runs against. It IS a [ScriptScope] (by delegation, so every quest action —
 * [talkTo], [interact], [achieve], [unless], … — is in scope exactly as before) plus one extra construct:
 * [once], a persisted single-run checkpoint.
 *
 * Existing stage bodies need no change: they only use [ScriptScope] members, and a [QuestStageScope] is a
 * [ScriptScope]. Reach for [once] only for the narrow case [achieve]/[unless] can't cover — see its contract.
 *
 * @since 0.21.0
 */
@OsrsxDsl
class QuestStageScope internal constructor(
    scope: ScriptScope,
    private val cursor: QuestCursor?,
) : ScriptScope by scope {

    /**
     * Run [body] AT MOST ONCE per stage window, remembering it across restarts. Once [body] completes, the
     * step is [labelled][label] done in the persisted cursor and SKIPPED on every later re-entry of the stage
     * (until the progress var advances, which invalidates the cursor).
     *
     * Use it ONLY for a step whose effect the game NEVER reverts and that leaves NOTHING observable to re-derive
     * from — learning a recipe from an NPC, revealing a blast wall, watching a cutscene. Re-running such a step
     * is otherwise harmless-but-wasteful (a repeated walk + dialogue); [once] elides that on resume.
     *
     * NEVER use [once] to obtain an item. If the item is later banked/dropped/lost, the skip would strand the
     * quest (the acquire step never re-runs). Item acquisition uses [achieve]/`until`, which read live state and
     * so re-run automatically when the item is gone. As a final backstop the driver CLEARS all [once] marks and
     * replays the whole stage if it makes no forward progress for several passes — so even a misused [once] or
     * an unforeseen regression self-recovers rather than hard-sticking.
     *
     * [label] identifies the step (and is shown as the status while it runs) — keep it stable and unique within
     * the stage. A [body] that throws [QuestActionFailed] is NOT marked done (it will retry on the next pass).
     */
    suspend fun once(label: String, body: suspend ScriptScope.() -> Unit) {
        if (cursor == null) { body(); return } // no persistence sink → just run it (still correct, just not skipped)
        if (cursor.isDone(label)) { status("✓ $label"); return }
        status(label)
        body()
        cursor.mark(label)
    }
}
