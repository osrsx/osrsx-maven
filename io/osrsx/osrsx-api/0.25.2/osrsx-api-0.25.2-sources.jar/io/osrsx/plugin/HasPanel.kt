package io.osrsx.plugin

/**
 * A plugin capability: draw **floating in-game panel(s)** each UI frame. Unlike a docked [HasMenu] flyout,
 * these are lightweight, ImGui-backed windows rendered over the game — translucent, with a RuneLite-style
 * border — that are **interactive** (buttons, inputs, pickers all work) and **repositionable by
 * alt+dragging**, the way RuneLite lets you move overlays. The engine owns the window chrome (background,
 * border, alt+drag, input capture); the plugin just draws content through [Gfx2D].
 *
 * **Windows are implicit.** The root scope of [onPanel] is itself a panel window titled the plugin name; it
 * is shown only on frames that actually drew something at the root — there is no visibility flag to manage,
 * and no draw calls means no window. Call [Gfx2D.overlay] to open additional named windows; a plugin that
 * draws *only* `overlay(...)` windows (and nothing at the root) shows just those.
 *
 * Pick the capability that fits: [HasMenu] (a docked sidebar panel), [HasPanel] (these floating panels),
 * [HasOverlay] (world-projected graphics on the scene). A menu body and a panel both draw through [Gfx2D].
 *
 * ```
 * class Miner : Plugin(), HasPanel {
 *     override fun onPanel(gfx: Gfx2D) {
 *         gfx.text("Ore mined: $mined")            // fills the implicit "Miner" window
 *         if (gfx.button("Reset")) mined = 0
 *         gfx.overlay("Rock") { it.text("next: $target") }   // a second, separate window
 *     }
 * }
 * ```
 */
interface HasPanel {
    /**
     * Render this plugin's panel content for the current frame. Root-scope draws fill the implicit
     * plugin-named window (shown only if it drew); [Gfx2D.overlay] opens additional windows.
     */
    fun onPanel(gfx: Gfx2D)
}
