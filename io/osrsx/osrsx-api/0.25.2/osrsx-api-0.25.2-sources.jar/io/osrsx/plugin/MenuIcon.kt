package io.osrsx.plugin

/**
 * The glyph shown on a plugin's [HasMenu] rail item. A curated set of FontAwesome 6 (solid) icons the
 * osrsx editor bundles — pick the closest fit, or wrap any other FontAwesome codepoint with [custom].
 *
 * [codepoint] is the FontAwesome PUA codepoint (in `0xF000..0xF8FF`) the engine renders; it is a plain
 * `Int` and carries no engine types, so the SDK stays engine-free. A codepoint the bundled icon font
 * doesn't provide simply renders blank, so stick to the named constants unless you know the glyph exists.
 */
data class MenuIcon(val codepoint: Int) {
    companion object {
        val PUZZLE = MenuIcon(0xF12E)     // puzzle-piece
        val WRENCH = MenuIcon(0xF0AD)     // wrench
        val GEAR = MenuIcon(0xF013)       // gear / cog
        val SLIDERS = MenuIcon(0xF1DE)    // sliders
        val LIST = MenuIcon(0xF03A)       // list
        val CHART = MenuIcon(0xF080)      // chart-bar
        val GAUGE = MenuIcon(0xF624)      // gauge
        val ROBOT = MenuIcon(0xF544)      // robot
        val BOLT = MenuIcon(0xF0E7)       // bolt
        val FIRE = MenuIcon(0xF06D)       // fire
        val FLASK = MenuIcon(0xF0C3)      // flask
        val FISH = MenuIcon(0xF578)       // fish
        val TREE = MenuIcon(0xF1BB)       // tree
        val HAMMER = MenuIcon(0xF6E3)     // hammer
        val GEM = MenuIcon(0xF3A5)        // gem
        val COINS = MenuIcon(0xF51E)      // coins
        val MAP = MenuIcon(0xF279)        // map
        val COMPASS = MenuIcon(0xF14E)    // compass
        val CROSSHAIRS = MenuIcon(0xF05B) // crosshairs
        val SHIELD = MenuIcon(0xF3ED)     // shield-halved
        val HEART = MenuIcon(0xF004)      // heart
        val STAR = MenuIcon(0xF005)       // star
        val SKULL = MenuIcon(0xF54C)      // skull
        val BOOK = MenuIcon(0xF02D)       // book
        val FLAG = MenuIcon(0xF024)       // flag
        val BELL = MenuIcon(0xF0F3)       // bell
        val EYE = MenuIcon(0xF06E)        // eye

        /**
         * Wrap an arbitrary FontAwesome 6 (solid) PUA codepoint not in the curated set above. The codepoint
         * must be in `0xF000..0xF8FF` and provided by the bundled `fa-solid-900` font, or it renders blank.
         */
        fun custom(codepoint: Int): MenuIcon = MenuIcon(codepoint)
    }
}
