package io.osrsx.plugin

/**
 * A plugin capability: draw **world-projected** graphics over the game scene each frame — tile highlights,
 * labels, paths, debug geometry. The engine registers/removes an above-scene overlay for a [Plugin] that
 * implements this on enable/disable (no manual `ctx.overlays()` wiring), and hands [onOverlay] a [Gfx3D]
 * that projects world [io.osrsx.api.Tile]s to the canvas for you.
 *
 * This is the in-world counterpart to [HasPanel] (which draws ImGui windows over the game, not world-space
 * graphics). It runs on the render thread — keep it quick and read-only; draw nothing to hide for a frame.
 * For persistent, animated scene markers prefer the retained [io.osrsx.api.Highlights] service, which is
 * itself built on [Gfx3D].
 */
interface HasOverlay {
    /** Paint this plugin's world-space graphics for one frame via [gfx]. */
    fun onOverlay(gfx: Gfx3D)
}
