package io.osrsx.plugin

/**
 * One frame's interaction state of a rectangular hit-region on a [GfxCanvas] (see [GfxCanvas.hit]).
 * Immediate-mode: [clicked]/[rightClicked] are true only on the frame the press happens.
 */
class GfxHit(
    /** The mouse is over the region this frame (and the canvas itself is hovered — an overlapping
     *  window on top of the canvas suppresses this, so hits never leak through other UI). */
    val hovered: Boolean,
    /** Left mouse button was pressed this frame while [hovered]. */
    val clicked: Boolean,
    /** Right mouse button was pressed this frame while [hovered]. */
    val rightClicked: Boolean,
) {
    companion object {
        /** The no-interaction result (headless engines, mouse elsewhere). */
        val NONE = GfxHit(hovered = false, clicked = false, rightClicked = false)
    }
}

/**
 * A raw immediate-mode drawing surface handed to a [Gfx2D.canvas] block — free-form shapes
 * (lines, boxes, circles) and positioned text, plus rectangular hit-testing so regions can react
 * to hover and clicks. Built for custom widgets the structured [Gfx2D] vocabulary can't express,
 * e.g. a grid of cells, a minimap, a progress mosaic.
 *
 * All coordinates are **canvas-local pixels**: `(0, 0)` is the canvas's top-left, x grows right,
 * y grows down, and drawing is clipped to the canvas bounds. Every colour is a packed
 * **`0xAARRGGBB` int** (see [io.osrsx.api.packArgb]) — same convention as [Gfx2D].
 *
 * Redraw everything every frame (nothing is retained); read [hit] *before* drawing a region to
 * pick its hover/pressed styling in the same frame:
 *
 * ```
 * gfx.canvas("grid", width = 0f, height = 96f) { c ->
 *     for (i in 0 until 5) {
 *         val x = i * 20f
 *         val h = c.hit(x, 0f, 18f, 18f, onClick = { toggle(i) })
 *         c.rectFilled(x, 0f, 18f, 18f, if (h.hovered) 0xFF5B8CFF.toInt() else 0xFF222532.toInt(), rounding = 3f)
 *     }
 * }
 * ```
 */
interface GfxCanvas {
    /** Canvas width in pixels (resolved: a fill-width canvas reports its actual width). */
    val width: Float

    /** Canvas height in pixels. */
    val height: Float

    /** Mouse x in canvas-local coords. Only meaningful while [mouseOver]; may be outside `0..width`. */
    val mouseX: Float

    /** Mouse y in canvas-local coords. Only meaningful while [mouseOver]; may be outside `0..height`. */
    val mouseY: Float

    /** True while the mouse is over the canvas and no other UI window is on top of it. */
    val mouseOver: Boolean

    /** A straight line from `(x1, y1)` to `(x2, y2)`, [thickness] px wide. */
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, argb: Int, thickness: Float = 1f)

    /** A box **outline** at `(x, y)` sized `w`×`h`; [rounding] > 0 rounds the corners by that radius. */
    fun rect(x: Float, y: Float, w: Float, h: Float, argb: Int, thickness: Float = 1f, rounding: Float = 0f)

    /** A **filled** box at `(x, y)` sized `w`×`h`; [rounding] > 0 rounds the corners by that radius. */
    fun rectFilled(x: Float, y: Float, w: Float, h: Float, argb: Int, rounding: Float = 0f)

    /** A circle **outline** centred on `(cx, cy)` with [radius] px. */
    fun circle(cx: Float, cy: Float, radius: Float, argb: Int, thickness: Float = 1f)

    /** A **filled** circle centred on `(cx, cy)` with [radius] px. */
    fun circleFilled(cx: Float, cy: Float, radius: Float, argb: Int)

    /** Raw text with its top-left at `(x, y)` in the current UI font (no wrapping; clipped at the bounds). */
    fun text(x: Float, y: Float, argb: Int, s: String)

    /** Rendered width of [s] in the current UI font, for centring/right-aligning [text]. */
    fun textWidth(s: String): Float

    /** Line height of the current UI font, for vertically centring [text]. */
    fun textHeight(): Float

    /**
     * Hit-test the rectangle at `(x, y)` sized `w`×`h` against the mouse. Immediate-mode: call it
     * every frame for every interactive region, *before* drawing the region, and style off the
     * result. Clicks on the canvas are consumed by the UI (they don't fall through to the game).
     */
    fun hit(x: Float, y: Float, w: Float, h: Float): GfxHit

    /**
     * [hit] with callback sugar: [onHover] runs every frame the region is hovered, [onClick] /
     * [onRightClick] on the frame it's clicked. Also returns the [GfxHit] so styling can reuse it.
     */
    fun hit(
        x: Float, y: Float, w: Float, h: Float,
        onHover: (() -> Unit)? = null,
        onClick: (() -> Unit)? = null,
        onRightClick: (() -> Unit)? = null,
    ): GfxHit {
        val h2 = hit(x, y, w, h)
        if (h2.hovered) onHover?.invoke()
        if (h2.clicked) onClick?.invoke()
        if (h2.rightClicked) onRightClick?.invoke()
        return h2
    }
}
