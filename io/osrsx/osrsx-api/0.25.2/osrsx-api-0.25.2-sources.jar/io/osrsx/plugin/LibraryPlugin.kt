package io.osrsx.plugin

/**
 * Marks a [Plugin] as a **library** — a plugin whose real purpose is to provide shared code (and,
 * optionally, services) that *other* plugins depend on, rather than to run automation of its own.
 *
 * A library is **functionally an ordinary plugin**: it has the full lifecycle and may implement any
 * capability. Implementing this interface changes only how it is *packaged and treated*:
 *  - it is auto-published to the osrsx Maven repo on registry approval, so other plugins can
 *    `compileOnly` it and the host can auto-install it;
 *  - other plugins may declare a dependency on it (required or optional) via the `osrsxPlugin { }`
 *    Gradle block, and the host makes its classes visible to those dependents;
 *  - the Plugin Manager renders it distinctly, and disabling a library that has enabled **required**
 *    dependents prompts the user (it will cascade-disable those dependents).
 *
 * By convention a library declares **no** [config] (it is not user-facing automation), and typically no
 * [onLoop] — but neither is enforced; a library may do both if it needs to.
 *
 * Declare one by implementing the interface alongside [Plugin], and set `library = true` in the plugin's
 * `osrsxPlugin { }` Gradle block so it is packaged and published as a library:
 *
 * ```
 * @PluginDescriptor(name = "Skilling Library", description = "Shared skilling primitives.")
 * class SkillingLibrary : Plugin(), LibraryPlugin
 * ```
 */
interface LibraryPlugin
