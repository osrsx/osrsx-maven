package io.osrsx.config

/**
 * The schema of a **repeatable** config group declared with [PluginConfig.repeatable]: a variable-length
 * list of rows, each row an instance of [template] (a small set of sub-settings). The user adds/removes
 * rows at runtime; the row count and every row's values persist under flat, indexed keys derived from
 * [key] (see [countKey] / [rowKey]). [maxRows] `> 0` caps how many rows can be added.
 *
 * Sub-item keys in [template] are **local** (e.g. `"item"`, `"action"`); the panel and the read-side
 * delegate rebind them to `"<key>.<row>.<localKey>"` per row, so two groups can reuse the same local keys.
 */
data class RepeatableSpec(
    val key: String,
    val addLabel: String,
    val template: List<ConfigItem>,
    val maxRows: Int = 0,
) {
    /** The hidden INT key holding the current row count. */
    fun countKey(): String = "$key.count"

    /** The persisted key for [local] sub-setting of row [row]. */
    fun rowKey(row: Int, local: String): String = "$key.$row.$local"
}

/**
 * Builder for a [PluginConfig.repeatable] row template. Each method declares one sub-setting of a row,
 * mirroring the top-level `xItem` factories (minus the delegate — rows are read via [Row]). Conditions
 * ([visibleIf]/[enabledIf]) reference *local* sub-keys and evaluate per row.
 *
 * ```kotlin
 * val rules by repeatable("rules", "Loot rules", addLabel = "Add rule") {
 *     item("item", "Item")
 *     enumField("action", "Action", "Keep", listOf("Keep", "Bank", "Drop"))
 *     int("min", "Min qty", 1, 1, 10_000)
 * }
 * ```
 */
class RepeatableTemplate internal constructor() {
    private val _fields = mutableListOf<ConfigItem>()
    internal val fields: List<ConfigItem> get() = _fields

    fun bool(key: String, name: String, default: Boolean = false, description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.BOOL, default, description, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun int(key: String, name: String, default: Int, min: Int = 0, max: Int = 0, description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null, step: Int = 1) {
        _fields += ConfigItem(key, name, ConfigType.INT, default, description, min, max, step = step, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun float(key: String, name: String, default: Double, min: Double = 0.0, max: Double = 0.0, description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null, step: Double = 0.0) {
        _fields += ConfigItem(key, name, ConfigType.FLOAT, default, description, floatMin = min, floatMax = max, floatStep = step, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun string(key: String, name: String, default: String = "", description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.STRING, default, description, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun color(key: String, name: String, default: String = "#FFFFFFFF", description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.COLOR, default, description, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun enumField(key: String, name: String, default: String, options: List<String>, description: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.ENUM, default, description, options = options, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun item(key: String, name: String, default: String = "", description: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.ITEM, default, description, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun npc(key: String, name: String, default: String = "", description: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.NPC, default, description, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf)
    }

    fun sceneObject(key: String, name: String, default: String = "", description: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null) {
        _fields += ConfigItem(key, name, ConfigType.OBJECT, default, description, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf)
    }
}

/**
 * One row of a [PluginConfig.repeatable] group: a read-only, type-tolerant view over that row's values,
 * keyed by the *local* sub-keys declared in the [RepeatableTemplate]. Missing values fall back to the
 * sub-setting's default.
 */
class Row internal constructor(private val values: Map<String, Any?>) {
    /** Raw value for [local] (or its default), or `null` if [local] is not in the template. */
    operator fun get(local: String): Any? = values[local]

    fun string(local: String): String = values[local]?.toString() ?: ""
    fun int(local: String): Int = (values[local] as? Number)?.toInt() ?: values[local]?.toString()?.toIntOrNull() ?: 0
    fun double(local: String): Double = (values[local] as? Number)?.toDouble() ?: values[local]?.toString()?.toDoubleOrNull() ?: 0.0
    fun bool(local: String): Boolean = values[local] as? Boolean ?: values[local]?.toString()?.toBoolean() ?: false

    /** The local sub-keys present in this row. */
    val keys: Set<String> get() = values.keys
}
