package io.osrsx.config

/**
 * A read-only snapshot of the current config values, keyed by [ConfigItem.key]. [Condition]s evaluate
 * against this. The client backs one with the live [ConfigStore]; a unit test can pass a plain map
 * (`ConfigValues { map[it] }`).
 */
fun interface ConfigValues {
    /** The current value of the item with this [key] (coerced to its type), or `null` if unknown. */
    operator fun get(key: String): Any?
}

/**
 * A boolean predicate over *other* config values — the expressive core that lets one setting depend on
 * others with full and / or / not logic. It is pure **data** (no lambdas), so it is introspectable,
 * unit-testable, and safe to evaluate headlessly; the same tree drives both UI visibility/enablement and
 * any tooling. Build them with the DSL helpers ([isTrue], [eq], [and], …) rather than the constructors:
 *
 * ```kotlin
 * // Show the spec-weapon picker only in advanced mode AND when either custom or override is on:
 * visibleIf = isTrue("advanced") and (eq("mode", "Custom") or isTrue("override"))
 * ```
 */
sealed interface Condition {
    /** Evaluate this predicate against [values]. */
    fun test(values: ConfigValues): Boolean

    /** True when [key]'s value is boolean-true (an unset / non-bool value counts as false). */
    data class IsTrue(val key: String) : Condition {
        override fun test(values: ConfigValues) = values[key] == true
    }

    /** True when [key]'s value equals [value] (type-tolerant: `"5" == 5`, enum-name strings match). */
    data class Eq(val key: String, val value: Any?) : Condition {
        override fun test(values: ConfigValues) = valuesEqual(values[key], value)
    }

    /** True when [key]'s value equals any of [values] (type-tolerant, like [Eq]). */
    data class OneOf(val key: String, val values: List<Any?>) : Condition {
        override fun test(values: ConfigValues) = this.values.any { valuesEqual(values[key], it) }
    }

    /** True when [key]'s value is a non-blank string (an item/npc/name picker that has a pick). */
    data class NotBlank(val key: String) : Condition {
        override fun test(values: ConfigValues) = !values[key]?.toString().isNullOrBlank()
    }

    /** True when [key]'s numeric value is strictly greater than [value]. */
    data class GreaterThan(val key: String, val value: Int) : Condition {
        override fun test(values: ConfigValues) = ((values[key] as? Number)?.toInt() ?: 0) > value
    }

    /** True when [key]'s numeric value is strictly less than [value]. */
    data class LessThan(val key: String, val value: Int) : Condition {
        override fun test(values: ConfigValues) = ((values[key] as? Number)?.toInt() ?: 0) < value
    }

    /** True when *every* child holds. */
    data class And(val conditions: List<Condition>) : Condition {
        override fun test(values: ConfigValues) = conditions.all { it.test(values) }
    }

    /** True when *any* child holds. */
    data class Or(val conditions: List<Condition>) : Condition {
        override fun test(values: ConfigValues) = conditions.any { it.test(values) }
    }

    /** True when the wrapped condition does not hold. */
    data class Not(val condition: Condition) : Condition {
        override fun test(values: ConfigValues) = !condition.test(values)
    }

    companion object {
        /** Equality that tolerates the string-typed persistence of config values (`true`/`"true"`, `5`/`"5"`). */
        internal fun valuesEqual(a: Any?, b: Any?): Boolean =
            a == b || a?.toString() == b?.toString()
    }
}

// ---- DSL ---------------------------------------------------------------------------------------------
// Small top-level builders so a config reads declaratively:  `visibleIf = isTrue("a") and eq("mode","X")`.

/** [key] is boolean-true. */
fun isTrue(key: String): Condition = Condition.IsTrue(key)

/** [key] is not boolean-true (unset counts as false → this is true). */
fun isFalse(key: String): Condition = Condition.Not(Condition.IsTrue(key))

/** [key] equals [value] (type-tolerant). */
fun eq(key: String, value: Any?): Condition = Condition.Eq(key, value)

/** [key] does not equal [value]. */
fun notEq(key: String, value: Any?): Condition = Condition.Not(Condition.Eq(key, value))

/** [key] equals one of [values] — the natural fit for an ENUM setting. */
fun oneOf(key: String, vararg values: Any?): Condition = Condition.OneOf(key, values.toList())

/** [key]'s string value is non-blank (e.g. an item picker has a selection). */
fun notBlank(key: String): Condition = Condition.NotBlank(key)

/** [key]'s string value is blank/unset. */
fun blank(key: String): Condition = Condition.Not(Condition.NotBlank(key))

/** [key]'s number is > [value]. */
fun greaterThan(key: String, value: Int): Condition = Condition.GreaterThan(key, value)

/** [key]'s number is < [value]. */
fun lessThan(key: String, value: Int): Condition = Condition.LessThan(key, value)

/** Negate a condition. */
fun not(condition: Condition): Condition = Condition.Not(condition)

/** Both must hold. Flattens nested [Condition.And]s so the tree stays shallow. */
infix fun Condition.and(other: Condition): Condition =
    Condition.And((if (this is Condition.And) conditions else listOf(this)) + other)

/** Either must hold. Flattens nested [Condition.Or]s so the tree stays shallow. */
infix fun Condition.or(other: Condition): Condition =
    Condition.Or((if (this is Condition.Or) conditions else listOf(this)) + other)
