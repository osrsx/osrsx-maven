package io.osrsx.combat

import io.osrsx.api.Events
import io.osrsx.api.Subscription
import io.osrsx.api.events.GameTick
import io.osrsx.api.subscribe
import java.util.concurrent.ConcurrentHashMap

/**
 * A game-tick counter + named tick edges, for combat logic that reasons in ticks (attack cadences,
 * threat TTLs, phase timers). Fills the SDK gap of "no tick-count accessor": [start] it on the plugin's
 * [Events] bus and it counts [GameTick]s; readers on any thread get a coherent [now].
 *
 * [markEdge]/[sinceEdge] name interesting moments ("entered", "lastBossAttack") so callers write
 * `clock.sinceEdge("entered") > 750` instead of bookkeeping their own volatile tick stamps.
 *
 * Writes come from the client thread (the event handler); reads from the plugin loop — the fields are
 * volatile/concurrent accordingly. For tests, drive [onTick] directly.
 *
 * @since 0.25.0
 */
class TickClock {

    @Volatile private var tick = 0
    private val edges = ConcurrentHashMap<String, Int>()

    /** The last seen game-tick count (0 until the first tick). */
    val now: Int get() = tick

    /** Count ticks from [events]; keep the [Subscription] to stop (or let plugin stop clean it up). */
    fun start(events: Events): Subscription = events.subscribe<GameTick> { onTick(it.tick) }

    /** Feed one tick (the [start] handler calls this; tests call it directly). */
    fun onTick(tickCount: Int) { tick = tickCount }

    /** Stamp the current tick under [key] (overwrites). */
    fun markEdge(key: String) { edges[key] = tick }

    /** Ticks since [markEdge]-ed [key], or [Int.MAX_VALUE] if never marked. */
    fun sinceEdge(key: String): Int = edges[key]?.let { tick - it } ?: Int.MAX_VALUE

    /** Remove a named edge (e.g. on fight reset). */
    fun clearEdge(key: String) { edges.remove(key) }

    /** Forget all edges (new fight/run). Does not reset [now]. */
    fun reset() = edges.clear()
}
