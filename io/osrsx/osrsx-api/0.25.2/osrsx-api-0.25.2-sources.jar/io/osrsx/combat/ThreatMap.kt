package io.osrsx.combat

import io.osrsx.api.Tile
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

/**
 * The transient area threats of a boss fight — chasing tornadoes, damaging floor tiles, a boss's
 * footprint — as a queryable set with tick TTLs and a conservative chase projection. Event handlers
 * [add]/remove threats (thread-safe); the fight loop takes ONE [snapshot] per poll and queries that.
 *
 * **Marshalling contract** (the reason snapshots exist): a threat's position is a provider so an
 * NPC-backed threat tracks its live tile — but reading a wrapped NPC is a client-thread marshal.
 * [snapshot] resolves every provider EXACTLY ONCE; all per-tile queries ([Snapshot.isThreatened] —
 * called ~120× per dodge scan) are then pure in-memory math. Never hand the planner a predicate that
 * reads live entities per tile. Cheaper still: NPC-backed providers can return a tile mirrored from an
 * event handler (`@Volatile` field written on NpcSpawned/GameTick) so even the once-per-poll resolve
 * never leaves the loop thread.
 *
 * [Entry.chasePerTick] inflates the threatened radius by `chase × lookahead` — a conservative disc
 * that over-marks rather than under-marks (missing a hit tile loses the fight; avoiding an extra tile
 * costs nothing).
 *
 * @since 0.25.0
 */
class ThreatMap {

    /** One live threat. Remove via [Handle.remove]; expiry via [prune]. */
    class Entry internal constructor(
        internal val tileOf: () -> Tile?,
        internal val radius: Int,
        internal val expiresAtTick: Int,
        internal val chasePerTick: Int,
    )

    /** Removal handle returned by [add]. */
    inner class Handle internal constructor(private val entry: Entry) {
        fun remove() { entries.remove(entry) }
    }

    private val entries = CopyOnWriteArrayList<Entry>()

    /**
     * Register a threat. [ttlTicks] from [nowTick] (Int.MAX_VALUE = until removed); [radius] in Chebyshev
     * tiles around its position; [chasePerTick] tiles of movement per tick (a chasing tornado = 1).
     * [tile] is resolved once per [snapshot] — see the marshalling contract above.
     */
    fun add(nowTick: Int, ttlTicks: Int = Int.MAX_VALUE, radius: Int = 0, chasePerTick: Int = 0, tile: () -> Tile?): Handle {
        val expiry = if (ttlTicks == Int.MAX_VALUE) Int.MAX_VALUE else nowTick + ttlTicks
        val e = Entry(tile, radius, expiry, chasePerTick)
        entries.add(e)
        return Handle(e)
    }

    /** Register a STATIC tile threat (damaging floor) — a constant provider, nothing to marshal. */
    fun addStatic(tile: Tile, nowTick: Int, ttlTicks: Int = Int.MAX_VALUE, radius: Int = 0): Handle =
        add(nowTick, ttlTicks, radius, chasePerTick = 0) { tile }

    /** Drop expired entries — call once per tick (or per fight poll). */
    fun prune(nowTick: Int) {
        entries.removeAll { it.expiresAtTick <= nowTick }
    }

    /**
     * Resolve every live threat's position ONCE and return a pure in-memory view for this poll's
     * queries. Threats with an unresolvable position (their NPC left the scene) are skipped — pair
     * with despawn-driven [Handle.remove].
     */
    fun snapshot(nowTick: Int, lookaheadTicks: Int = 1): Snapshot {
        val look = lookaheadTicks.coerceAtLeast(0)
        val zones = ArrayList<Zone>(entries.size)
        for (e in entries) {
            if (e.expiresAtTick <= nowTick) continue
            val at = e.tileOf() ?: continue
            zones.add(Zone(at, e.radius + e.chasePerTick * look))
        }
        return Snapshot(zones)
    }

    /** Live (unexpired) threat count, including position-unresolved ones (diagnostics). */
    fun size(nowTick: Int): Int = entries.count { it.expiresAtTick > nowTick }

    /** Drop everything (fight over). */
    fun clear() = entries.clear()

    internal class Zone(val at: Tile, val reach: Int)

    /**
     * One poll's resolved threat geometry — all queries are allocation-free integer math, safe to call
     * hundreds of times per poll from any thread.
     */
    class Snapshot internal constructor(private val zones: List<Zone>) {

        /** Is [t] inside any resolved threat zone (radius + chase projection)? */
        fun isThreatened(t: Tile): Boolean = zones.any { z ->
            z.at.plane == t.plane && maxOf(abs(z.at.x - t.x), abs(z.at.y - t.y)) <= z.reach
        }

        /** Any resolved threat at all this poll? (Cheap "is the arena hot" probe.) */
        fun any(): Boolean = zones.isNotEmpty()

        /** Resolved threat count this poll. */
        val size: Int get() = zones.size
    }
}
