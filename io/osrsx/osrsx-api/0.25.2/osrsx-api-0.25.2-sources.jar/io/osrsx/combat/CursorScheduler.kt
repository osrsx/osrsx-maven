package io.osrsx.combat

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Deadline math for deterministic cursor arrival: the mouse stays humanised (glides, jitter, dwell),
 * but a deadline-critical click — the prayer switch before the next boss attack, the dodge step inside
 * a warning window — must have the cursor AT its target when the moment comes. Two cooperating pieces:
 *
 *  - [CursorScheduler]: given "click due at [dueAtMs]" and a travel estimate, when must the glide START
 *    ([latestStartMs]/[mustStartNow])? Combined with pre-hover ([wantsPreHover]): in every idle poll,
 *    park the cursor on the NEXT expected target (the prayer widget, the boss hull) so the eventual
 *    click is a ~zero-travel dwell — arrival is then trivially deterministic and the humanisation risk
 *    collapses to click latency alone.
 *  - [MouseTravelModel]: a learned distance→duration model. The EXACT path is
 *    [io.osrsx.api.Mouse.planMove] (path pre-generated, duration known by construction — schedule with
 *    that whenever possible); [io.osrsx.api.Mouse.travelTime] is the engine's estimate for a not-yet-
 *    planned move. This model RECORDS the observed durations of the session's actual gestures and
 *    predicts conservatively (mean + [safetySigmas]·σ per pixel) — the cross-check and the fallback
 *    when no plan exists yet. Feed it every timed gesture.
 *
 * Pure and unit-testable; the fight controller owns the policy of WHAT to pre-hover (next prayer,
 * next weapon slot) — see the Gauntlet plugin's fight ladder.
 *
 * @since 0.25.0
 */
class CursorScheduler(
    /** Slack subtracted from every deadline — absorbs poll latency + click dwell. */
    private val safetyMarginMs: Long = 120,
    /** Cursor already within this many px of the target counts as hovered (no staging needed). */
    private val hoverRadiusPx: Double = 12.0,
) {

    /** The latest wall-clock ms a glide of [travelMs] may start and still arrive by [dueAtMs]. */
    fun latestStartMs(dueAtMs: Long, travelMs: Long): Long = dueAtMs - travelMs - safetyMarginMs

    /** True when the glide must start THIS poll to make the deadline. */
    fun mustStartNow(nowMs: Long, dueAtMs: Long, travelMs: Long): Boolean =
        nowMs >= latestStartMs(dueAtMs, travelMs)

    /** True when even starting now misses [dueAtMs] — the caller should escalate (hurry, or accept). */
    fun isLate(nowMs: Long, dueAtMs: Long, travelMs: Long): Boolean =
        nowMs + travelMs + safetyMarginMs > dueAtMs

    /**
     * Should an idle poll pre-position the cursor? True when nothing hotter is pending ([idle]), a next
     * target is known, and the cursor isn't already hovering it ([distancePx] > hover radius).
     */
    fun wantsPreHover(idle: Boolean, distancePx: Double): Boolean =
        idle && distancePx > hoverRadiusPx

    /** Is the cursor effectively ON the target already? */
    fun isHovered(distancePx: Double): Boolean = distancePx <= hoverRadiusPx
}

/**
 * Session-learned mouse glide timing: record each observed humanised gesture ([record]) and ask
 * [estimateMs] for a CONSERVATIVE prediction of a glide over a given pixel distance. Starts from a
 * prior matching [io.osrsx.api.Mouse.travelTime]'s default and converges to the live humanizer's real
 * pace; the estimate includes [safetySigmas] standard deviations of the observed per-pixel spread, so
 * scheduled starts err early, never late.
 *
 * Single-threaded (feed and query from the fight loop).
 *
 * @since 0.25.0
 */
class MouseTravelModel(
    private val safetySigmas: Double = 2.0,
    /** Prior: base reaction/settle ms + per-pixel ms (matches the Mouse.travelTime default heuristic). */
    priorBaseMs: Double = 90.0,
    priorPerPxMs: Double = 0.65,
) {
    private var baseMs = priorBaseMs
    private var perPx = priorPerPxMs
    private var perPxVar = 0.05 // variance of the per-pixel rate estimate
    private var samples = 0

    /** Record one observed gesture: it covered [distancePx] and took [tookMs]. */
    fun record(distancePx: Double, tookMs: Long) {
        if (distancePx < 4 || tookMs <= 0) return // clicks-in-place teach nothing about glide pace
        val rate = (tookMs - baseMs).coerceAtLeast(1.0) / distancePx
        val alpha = 0.2 // EWMA — recent gestures dominate (humanizer settings can change mid-session)
        val delta = rate - perPx
        perPx += alpha * delta
        perPxVar = (1 - alpha) * (perPxVar + alpha * delta * delta)
        samples++
    }

    /** Conservative estimate (ms) for a glide covering [distancePx]. */
    fun estimateMs(distancePx: Double): Long {
        val sigma = sqrt(abs(perPxVar))
        return (baseMs + distancePx * (perPx + safetySigmas * sigma)).toLong()
    }

    /** How many gestures have been learned from (gate scheduling trust on a minimum). */
    fun sampleCount(): Int = samples
}
