package io.osrsx.combat

import java.util.Random

/**
 * Human-imperfect prayer-flick timing — a port of the extracted boss-lib's `FlickController` (proven by
 * the Brutus + Demonic Gorilla plugins), rehomed in the SDK so every combat plugin shares it. Models a
 * player lazy-flicking a protection prayer around each incoming hit, deliberately **not** like a machine:
 *
 *  - never a metronomic 600 ms rhythm — the "lead" (how early you click before the hit) and "hold" (how
 *    long you keep it up) are re-jittered every cycle;
 *  - anticipates the tick like a human (clicks slightly *before* the hit), with the occasional slow
 *    "react-after" flick;
 *  - every so often it **whiffs** entirely — prayer down when the hit lands. The miss rate is low enough
 *    to boss through with food, high enough to read as human rather than a perfect flicker.
 *
 * Usage: call [onTick] from a `GameTick` handler; poll [prayerWanted] from the fast combat loop and
 * toggle quick-prayer to match. [attackEveryTicks] > 1 flicks only on the boss's actual hit ticks
 * (e.g. the Hunllef swings every 5 ticks).
 *
 * @since 0.25.0
 */
class PrayerFlicker(
    private val attackEveryTicks: Int = 1,
    private val missChance: Double = 0.05,
    private val lateChance: Double = 0.08,
    seed: Long? = null,
) {
    private val rng = if (seed != null) Random(seed) else Random()
    private var lastTickMs = 0L
    private var periodMs = 600L
    private var tickCount = 0
    private var windowOpen = 0L
    private var windowClose = 0L

    /** Feed each game tick (its wall-clock ms). Learns the real cadence and schedules the next flick window. */
    fun onTick(nowMs: Long) {
        if (lastTickMs > 0) {
            val dt = nowMs - lastTickMs
            if (dt in 450..820) periodMs = (periodMs + dt) / 2 // smooth toward the true tick period
        }
        lastTickMs = nowMs
        tickCount++
        if (attackEveryTicks > 1 && tickCount % attackEveryTicks != 0) { windowOpen = 0; windowClose = 0; return }
        val nextHit = nowMs + periodMs
        when {
            rng.nextDouble() < missChance -> { windowOpen = 0; windowClose = 0 }        // whiffed flick → take the hit
            rng.nextDouble() < lateChance -> {                                          // slow, reactive flick
                windowOpen = nextHit + 30 + rng.nextInt(140)
                windowClose = windowOpen + 120 + rng.nextInt(150)
            }
            else -> {                                                                   // normal anticipatory flick
                val lead = 40 + rng.nextInt(180)                                        // click 40–220 ms early
                windowOpen = nextHit - lead
                windowClose = nextHit + 90 + rng.nextInt(160)                           // keep it up a touch after
            }
        }
    }

    /** Whether the protection prayer should be UP right now — poll this often from the combat loop. */
    fun prayerWanted(nowMs: Long): Boolean = windowClose > 0 && nowMs in windowOpen..windowClose
}
