package io.osrsx.combat

/**
 * Counts the local player's attacks mod [period], for bosses that react to your Nth hit (the Hunllef
 * changes its overhead prayer to the style of every 6th player attack). The caller maps its own
 * animation ids to attacks and — critically — tells the counter whether each attack ADVANCES the true
 * counter: an attack the boss's current overhead BLOCKS does not (splashes do). Poll [attacksUntilNth]
 * to pre-arrange the Nth hit's style ([nthIsNext] ⇒ arrange it now).
 *
 * The boss's live overhead icon is ground truth for when the flip actually happened — call
 * [onOverheadFlipped] on that observation so a miscount can never persist past one period. Pure and
 * single-threaded.
 *
 * @since 0.25.0
 */
class PlayerAttackCounter(private val period: Int = 6) {

    init {
        require(period > 0) { "period must be positive" }
    }

    /** Advancing attacks made in the current period (0 ≤ count < period). */
    var count: Int = 0
        private set

    /** Attacks (that advance) remaining until the Nth — 1 ⇒ the NEXT attack is the Nth. */
    val attacksUntilNth: Int get() = period - count

    /** True when the NEXT advancing attack is the Nth (arrange its style now). */
    val nthIsNext: Boolean get() = attacksUntilNth == 1

    /**
     * Record an attack. [advances] = false for an attack blocked by the boss's current overhead
     * (blocked hits do not move the true counter; unblocked splashes DO).
     */
    fun attack(advances: Boolean = true) {
        if (!advances) return
        count = (count + 1) % period
    }

    /** The boss's overhead flip was OBSERVED — the period completed, whatever our count said. */
    fun onOverheadFlipped() { count = 0 }

    /** New fight. */
    fun reset() { count = 0 }
}
