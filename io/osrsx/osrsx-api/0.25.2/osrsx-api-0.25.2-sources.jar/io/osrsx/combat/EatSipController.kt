package io.osrsx.combat

/**
 * When to eat/sip during a fight — the decision half only (pure, testable); the fight controller
 * executes the returned [Consume] with its own clicks. Encodes the shared boss-fight food policy:
 *
 *  - eat at/below the configured threshold, ALWAYS at/below the hard floor (≥2× the boss's current
 *    max hit — never be one-shottable);
 *  - panic slot: at the hard floor prefer the no-delay combo food when one is available;
 *  - pace consumptions ([minGapMs]) — no machine-gun eating;
 *  - **suppressed** while a higher-priority action is due this poll ([switchDue] — a prayer/weapon
 *    switch beats food by one poll, never by more);
 *  - **preferred** while dodging ([dodging]) — movement ticks are free, the community-standard window.
 *
 * @since 0.25.0
 */
class EatSipController(
    private val eatAtHp: Int,
    private val hardFloorHp: Int,
    private val sipPrayerAt: Int,
    private val minGapMs: Long = 1_800,
) {

    /** What to consume now. */
    enum class Consume { EAT, EAT_PANIC, SIP }

    private var lastConsumeMs = Long.MIN_VALUE / 2 // "never" — the gap must not gate the FIRST consumption

    /**
     * Decide for this poll. [hp]/[prayer] are current points; [nowMs] the loop clock; [switchDue] true
     * when a prayer/weapon switch wants this poll; [dodging] true while executing a dodge (free ticks);
     * [hasPanicFood] whether a no-delay combo food is held.
     */
    fun decide(
        hp: Int,
        prayer: Int,
        nowMs: Long,
        switchDue: Boolean = false,
        dodging: Boolean = false,
        hasPanicFood: Boolean = false,
    ): Consume? {
        val panic = hp <= hardFloorHp
        if (!panic && switchDue) return null                       // a due switch wins the poll — except in panic
        if (!panic && nowMs - lastConsumeMs < minGapMs) return null // paced; panic overrides the gap too
        return when {
            panic -> if (hasPanicFood) Consume.EAT_PANIC else Consume.EAT
            hp <= eatAtHp && (dodging || !urgentOnly) -> Consume.EAT
            prayer <= sipPrayerAt -> Consume.SIP
            else -> null
        }
    }

    /** Record that the decided consumption was actually clicked (starts the pacing gap). */
    fun consumed(nowMs: Long) { lastConsumeMs = nowMs }

    /** Reserved for a stricter mode (eat only in dodge windows); off in v1. */
    private val urgentOnly = false
}
