package io.osrsx.combat

import io.osrsx.api.Overhead

/**
 * Tracks a fixed-rotation boss's attack phase — "N attacks of style A, then style B, …" (the Hunllef:
 * 4 attacks per style, opens ranged, alternates ranged↔magic; Jad/Zulrah-family bosses fit too) — so a
 * fight controller can pre-switch its protection prayer instead of reacting to every hit.
 *
 * Feed it what the fight actually observes, most-authoritative first:
 *  - [attackObserved] with the attack's style read from its projectile id — **ground truth**. A style
 *    that contradicts the expectation resyncs the tracker to it (we missed something; believe the game).
 *  - [countingEvent] for an attack that consumes a rotation slot but carries no style of its own
 *    (the Hunllef's tornado summon). Non-counting specials (its stomp) are simply never fed.
 *  - [telegraph] when the boss plays a style-switch telegraph animation — a hard resync to "a fresh
 *    phase of [next] is about to begin", making the counter self-healing against any drift.
 *
 * Poll [expectedStyle] (what to pray against now) and [attacksLeftInPhase] (pre-switch when it hits 0
 * — the next attack opens the other phase). Pure and single-threaded: drive it from one place.
 *
 * @since 0.25.0
 */
class BossRotationTracker(
    private val attacksPerPhase: Int,
    private val opening: Overhead,
    private val nextPhase: (Overhead) -> Overhead,
) {

    init {
        require(attacksPerPhase > 0) { "attacksPerPhase must be positive" }
    }

    /** The style the CURRENT phase attacks with — pray against this. */
    var expectedStyle: Overhead = opening
        private set

    /** Rotation slots left in the current phase (0 ⇒ the NEXT attack starts the next phase). */
    var attacksLeftInPhase: Int = attacksPerPhase
        private set

    /** Total counting attacks observed this fight (the metronome anchor). */
    var totalAttacks: Int = 0
        private set

    /**
     * A counting attack landed with a KNOWN [style] (from its projectile id). If it matches the current
     * phase (or the just-due next phase), the rotation advances normally; a contradicting style resyncs
     * the tracker to the observed phase — projectiles are ground truth, the counter is only prediction.
     * Returns true when the observation fit the expectation (false = a resync happened).
     */
    fun attackObserved(style: Overhead): Boolean {
        totalAttacks++
        if (attacksLeftInPhase == 0) advancePhase()
        if (style == expectedStyle) {
            consumeSlot()
            return true
        }
        // Desync: believe the projectile. This attack is the first observed of ITS phase.
        expectedStyle = style
        attacksLeftInPhase = attacksPerPhase
        consumeSlot()
        return false
    }

    /** A counting attack with no style signal of its own (consumes a slot of the current phase). */
    fun countingEvent() {
        totalAttacks++
        if (attacksLeftInPhase == 0) advancePhase()
        consumeSlot()
    }

    /** The boss telegraphed that a fresh phase of [next] begins now — hard resync (counter refilled). */
    fun telegraph(next: Overhead) {
        expectedStyle = next
        attacksLeftInPhase = attacksPerPhase
    }

    /** New fight — back to the opening phase. */
    fun reset() {
        expectedStyle = opening
        attacksLeftInPhase = attacksPerPhase
        totalAttacks = 0
    }

    private fun consumeSlot() {
        attacksLeftInPhase--
        if (attacksLeftInPhase < 0) attacksLeftInPhase = 0
    }

    private fun advancePhase() {
        expectedStyle = nextPhase(expectedStyle)
        attacksLeftInPhase = attacksPerPhase
    }
}
