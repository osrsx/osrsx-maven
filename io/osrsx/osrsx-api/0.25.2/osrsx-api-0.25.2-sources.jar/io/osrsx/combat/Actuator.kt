package io.osrsx.combat

import java.util.concurrent.atomic.AtomicReference

/**
 * The single actuation slot of a reactive fight: senses (event handlers, on any thread) [offer]
 * intents; the fight loop [take]s the highest-priority one per poll and executes it. Exactly one
 * pending intent exists at a time — a higher-priority offer REPLACES a lower one (the replaced intent
 * is simply dropped; senses re-offer every poll from current state, so nothing is lost), and a
 * lower-priority offer while something hotter is pending is ignored.
 *
 * Execution stays on the loop thread (SDK interactions are synchronous there); preemption of an
 * ENGINE-side in-flight mouse glide is the executor's job — the convention is to call
 * `mouse.abortMove()` before executing a [Priority.DODGE]/[Priority.PROTECTION] intent so a stale
 * lower-priority glide can't finish under it.
 *
 * ```
 * actuator.offer(Actuator.Intent(Actuator.Priority.DODGE, "sidestep") { … })
 * // fight poll:
 * actuator.take()?.let { intent ->
 *     if (intent.priority >= Actuator.Priority.PROTECTION) mouse.abortMove()
 *     mouse.withHurry { intent.execute() }
 * }
 * ```
 *
 * @since 0.25.0
 */
class Actuator {

    /** Intent priorities, hottest first — the Hunllef ladder's order. Higher ordinal = more urgent. */
    enum class Priority { ATTACK, WEAPON_SWITCH, EAT_SIP, DODGE, PROTECTION }

    /** One actuation intent: [execute] runs on the fight-loop thread when the intent is taken. */
    class Intent(
        val priority: Priority,
        val label: String,
        val execute: () -> Unit,
    )

    private val pending = AtomicReference<Intent?>(null)

    /** Offer an intent; it becomes pending only if hotter than what's already pending. Thread-safe. */
    fun offer(intent: Intent) {
        pending.updateAndGet { cur ->
            if (cur == null || intent.priority.ordinal > cur.priority.ordinal) intent else cur
        }
    }

    /** Take (and clear) the pending intent, or null. Call once per fight poll from the loop thread. */
    fun take(): Intent? = pending.getAndSet(null)

    /** What's pending without consuming it (overlay/diagnostics). */
    fun peek(): Intent? = pending.get()

    /** Drop any pending intent (fight over / state reset). */
    fun clear() { pending.set(null) }
}
