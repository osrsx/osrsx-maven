package io.osrsx.api.events

import io.osrsx.api.Npc
import io.osrsx.api.SceneEntity
import io.osrsx.api.SceneObject
import io.osrsx.api.Skill
import io.osrsx.api.Tile

/**
 * First-class, SDK-owned game events. Plugins subscribe to THESE (via `events.subscribe<GameTick>{}`,
 * `on<GameTick>{}`, or `@Subscribe`) instead of the raw RuneLite event classes, so a plugin's event handlers
 * carry no engine dependency — the engine adapts RuneLite events into these at the boundary.
 * Every payload is an SDK type ([SceneEntity]/[Npc]/[Skill]/enum) or a primitive.
 *
 * Handlers for these run on the client thread as the event fires (keep them quick and non-blocking).
 */

/**
 * A game tick (~600ms). [tick] is the client tick count.
 *
 * **Choosing a snapshot cadence**: both this and [ClientTick] fire on the client thread and both may
 * snapshot game state into volatile fields — pick per datum by how often it actually changes. Game-tick
 * data (varbits, inventory, overhead icons, whole-tile positions, animation starts) belongs here —
 * snapshotting it faster reads the same value ~30× over. Frame-interpolated data (projectile flight
 * positions, [io.osrsx.api.Npc.localPoint] for hull tracking) belongs in a [ClientTick] handler.
 */
data class GameTick(val tick: Int)

/**
 * A client frame tick (every rendered frame, ~20ms — higher frequency than [GameTick]). The snapshot
 * cadence for data that changes BETWEEN game ticks: interpolated NPC/projectile positions, on-screen
 * hulls a cursor plan aims at. Keep these handlers especially cheap — they run ~50×/s on the client
 * thread. See [GameTick] for choosing between the two.
 */
class ClientTick

/** The client's high-level state changed (login screen, loading, logged in, hopping, …). */
data class GameStateChanged(val state: GameStateType)

/** SDK mirror of the client's high-level game state — no engine GameState on the boundary. */
enum class GameStateType { STARTING, LOGIN_SCREEN, AUTHENTICATOR, LOADING, LOGGED_IN, CONNECTION_LOST, HOPPING, UNKNOWN }

/** XP gained (or a level change) in a skill — fired as a stat updates. */
data class XpGained(val skill: Skill, val xp: Int, val level: Int)

/** An actor's animation changed. [source] is the NPC/Player now playing [animation] (-1 = idle). */
data class AnimationChanged(val source: SceneEntity, val animation: Int)

/** An actor started or stopped interacting with (targeting) another. [target] is null when it stopped. */
data class InteractingChanged(val source: SceneEntity, val target: SceneEntity?)

/** A hitsplat landed on [target]. [mine] is true when it's damage I dealt/received; [type] is the raw id. */
data class HitsplatApplied(val target: SceneEntity, val amount: Int, val mine: Boolean, val type: Int)

/** A chat message. [type] is the RuneLite message-type name (e.g. "GAMEMESSAGE", "PUBLICCHAT"). */
data class ChatMessage(val type: String, val sender: String?, val message: String)

/** A menu option was clicked. Pure strings/id — no engine MenuEntry on the boundary. */
data class MenuOptionClicked(val option: String, val target: String, val id: Int)

/** A varbit or varp changed. [varbitId] is -1 for a varp change; [varpId] is -1 for a varbit change. */
data class VarbitChanged(val varbitId: Int, val varpId: Int, val value: Int)

/** An item container changed (inventory, bank, equipment, …). [containerId] identifies which one. */
data class ItemContainerChanged(val containerId: Int)

/** An NPC spawned into the loaded scene. */
data class NpcSpawned(val npc: Npc)

/** An NPC despawned from the loaded scene. */
data class NpcDespawned(val npc: Npc)

/**
 * A projectile entered flight — fired **once per projectile** (the engine dedups the underlying
 * per-cycle movement event, so a handler never sees the same projectile twice). The projectile id is
 * the discriminator boss plugins key on (e.g. the Hunllef's magic vs ranged vs prayer-disable attacks).
 *
 * @param sourceTile where it launched from (usually the attacker), or null when off-scene.
 * @param targetTile where it will land, or null for an actor-tracking projectile with no fixed tile.
 * @param targetsMe true when the local player is the projectile's interacting target.
 * @param remainingCycles client cycles until impact at fire time — a tick-conversion hint (~30/tick).
 * @since 0.25.0
 */
data class ProjectileLaunched(
    val id: Int,
    val sourceTile: Tile?,
    val targetTile: Tile?,
    val targetsMe: Boolean,
    val remainingCycles: Int,
)

/**
 * An NPC's definition changed in place (transmog) — same scene NPC, new composition. Bosses use this
 * for phase changes (e.g. the Hunllef's id tracks its overhead prayer), so this is the edge-triggered
 * companion to polling [Npc.id]. [npc] already reflects the NEW definition; [oldId] is what it was.
 *
 * @since 0.25.0
 */
data class NpcChanged(val npc: Npc, val oldId: Int)

/**
 * A game object spawned into the loaded scene (including an existing object being replaced in place —
 * a depleted resource node's twin, a boss arena hazard tile appearing). @since 0.25.0
 */
data class GameObjectSpawned(val obj: SceneObject)

/** A game object despawned from the loaded scene (or was replaced — see [GameObjectSpawned]). @since 0.25.0 */
data class GameObjectDespawned(val obj: SceneObject)

/**
 * An actor's spot-anim (graphic) changed. [source] is the NPC/Player now showing [graphic] (-1 = none) —
 * a secondary telegraph channel for boss specials (freezes, venom, spawn effects). @since 0.25.0
 */
data class GraphicChanged(val source: SceneEntity, val graphic: Int)

/**
 * An actor died. The kill/death confirmation signal — no animation-id heuristics needed. [isMe] is true
 * when the dead actor is the local player (death-recovery / hardcore guards key on it). @since 0.25.0
 */
data class ActorDeath(val source: SceneEntity, val isMe: Boolean)
