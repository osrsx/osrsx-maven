package io.osrsx.api

/** Withdraw [amount] of [ref] from the bank ([noted] = as bank notes). @since 0.4.0 */
data class Withdrawal(val ref: ItemRef, val amount: Int, val noted: Boolean = false)

/** Deposit [amount] of [ref] into the bank (`amount <= 0` = deposit-all). @since 0.4.0 */
data class Deposit(val ref: ItemRef, val amount: Int)

/** A required item the bank couldn't fully cover — the restock trigger ([shortfall] still missing). @since 0.4.0 */
data class RestockNeed(val item: LoadoutItem, val shortfall: Int)

/**
 * The reconciliation diff between the live containers and a [Loadout]: what to deposit (foreign + excess),
 * what to withdraw (deficits the bank can cover), what to equip (carried but must be worn), and what to
 * restock (required deficits the bank can't cover). [satisfied] is the dry-run "already there?" answer.
 *
 * @since 0.4.0
 */
data class LoadoutPlan(
    val deposits: List<Deposit>,
    val withdrawals: List<Withdrawal>,
    val equips: List<ItemRef>,
    val restocks: List<RestockNeed>,
) {
    /** True when the live containers already meet the loadout (nothing to deposit/withdraw/equip). */
    val satisfied: Boolean get() = deposits.isEmpty() && withdrawals.isEmpty() && equips.isEmpty()
}

/**
 * Reconciles the live inventory + equipment toward a declarative [Loadout] using ONLY osrsx's synthetic
 * bank / Grand Exchange interaction (no packets, no field writes) — the plugin-facing surface of the
 * engine's `RestockService`. Build a loadout with [build] (or [Loadout.build]), then drive [apply] each
 * plugin loop until it returns true, exactly like [BankCache.ensureFresh] and [Bank.openNearest].
 *
 * Obtain it from [PluginContext.loadouts] / the `loadouts` authoring sugar.
 *
 * @since 0.4.0
 */
interface Loadouts {

    /** Build a [Loadout] with the [LoadoutBuilder] DSL — sugar for [Loadout.build]. */
    fun build(name: String, block: LoadoutBuilder.() -> Unit): Loadout = Loadout.build(name, block)

    /** The current diff against [loadout], reading the bank only when it's open (else deficits are assumed
     *  withdrawable). */
    fun plan(loadout: Loadout): LoadoutPlan

    /** Dry-run: does the live inventory/equipment ALREADY satisfy [loadout]? (Ignores the bank.) */
    fun isSatisfied(loadout: Loadout): Boolean

    /**
     * Advance one loop-step toward [loadout]; returns true once satisfied (and closes the bank). Opens the
     * nearest bank if needed, then deposits, withdraws and equips up to [budget] container actions this call.
     * Depleted required items the bank can't cover fire the default depletion hook (a marked-up instant GE buy).
     */
    fun apply(loadout: Loadout, budget: Int = DEFAULT_BUDGET): Boolean

    /**
     * As [apply], but routes required-item shortfalls the bank can't cover to [onDeplete] instead of the
     * default GE buy — the loadout's `onDeplete` hook.
     */
    fun apply(loadout: Loadout, budget: Int, onDeplete: (RestockNeed) -> Unit): Boolean

    companion object {
        /** Default per-call container-action budget (deposits + withdrawals + equips). */
        const val DEFAULT_BUDGET: Int = 8
    }
}
