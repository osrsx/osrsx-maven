package io.osrsx.api

import java.awt.Shape

/**
 * Anything a plugin can click in the world or on the screen. The SDK-facing surface of the engine's
 * interaction wrappers (the concrete impls live in `io.osrsx.wrappers` inside the client and drive the
 * virtual mouse / camera / menu selection). No `net.runelite.*` on this boundary — positions are exposed
 * as [Tile] via [SceneEntity.tile]; on-screen geometry uses the JDK's [java.awt.Shape].
 */
interface Interactable {
    /** Display name (e.g. the NPC/object/item name), or null when unknown / off-scene. */
    fun name(): String?

    /** The on-screen clickable region (convex hull / clickbox), or null if off-screen. */
    fun clickbox(): Shape?

    /** Move the mouse over this entity without clicking. */
    fun hover(): Boolean

    /**
     * Interact with this entity. With [action] null, performs the default left-click; a non-null [action]
     * (e.g. "Attack", "Bank") selects that menu option.
     */
    fun interact(action: String? = null): Boolean

    /**
     * A **precise** (tracking-triggerbot) interaction — the fix for the "clicked where the tile/NPC/object
     * *used to be*" miss that plagues the ordinary [interact] path while the avatar is moving. Instead of
     * moving to one screen point that goes stale mid-flight, it HOMES the humanised cursor onto this
     * entity's LIVE clickbox (re-read every client tick, so the cursor follows the target as it steps or as
     * the camera drifts while you walk) and commits only once the cursor has rested inside that fresh
     * clickbox for [PreciseConfig.dwellMs]. With [action] null it left-clicks the locked point; a non-null
     * [action] right-clicks the locked point and picks that menu row (or left-clicks when it is already the
     * live default). Returns true if it locked on and clicked; false if the target never settled under the
     * cursor (a tight loop can just retry next tick). See [Mouse.moveTracking].
     *
     * The default implementation falls back to [interact] — engines without tracking support degrade to the
     * ordinary interaction, so this is always safe to call.
     *
     * @since 0.11.0
     */
    fun interactPrecise(action: String? = null, config: PreciseConfig = PreciseConfig()): Boolean = interact(action)

    /**
     * Like [hover], but PRECISE: home the cursor onto this entity's live clickbox (tracking it as it moves)
     * and settle there without clicking — e.g. to pre-position the cursor so a follow-up [interactPrecise]
     * commits instantly. Returns true once the cursor has locked onto the fresh clickbox. The default
     * implementation falls back to [hover].
     *
     * @since 0.11.0
     */
    fun hoverPrecise(config: PreciseConfig = PreciseConfig()): Boolean = hover()
}

/**
 * A world entity (NPC, object, player, ground item) — an [Interactable] with a world position and
 * distance, plus verified/multi-option interaction helpers. Concrete impls are the engine's
 * `io.osrsx.wrappers.Entity` subclasses.
 */
interface SceneEntity : Interactable {
    /** World tile of this entity, or null if not in the scene. */
    fun tile(): Tile?

    /**
     * INTERPOLATED sub-tile scene position in local units (128 = 1 tile), or null when off-scene. Finer
     * than [tile] (whole-tile) and — unlike world [tile] — expressed in the loaded scene's own frame, so
     * `x / 128` / `y / 128` are the scene-tile coords (0..103). Available on every scene entity including
     * the LOCAL PLAYER (via `me`), e.g. for instance room-grid math where world coords are templated.
     *
     * @since 0.25.1
     */
    fun localPoint(): java.awt.Point? = null

    /** Chebyshev distance (tiles) from the local player; [Int.MAX_VALUE] if either is off-scene. */
    fun distance(): Int

    /**
     * The rendered TILE HEIGHT of this entity's position (engine units; more negative = higher up), or 0 when
     * off-scene. This is the only way to tell apart stacked areas the game overlays at the SAME world tile and
     * plane — most notably the Motherlode Mine's two floors (the upper floor is well below the lower's height,
     * ~< -490). Compare an object's [tileHeight] to the local player's to know they're on the same floor.
     *
     * @since 0.11.2
     */
    fun tileHeight(): Int = 0

    /**
     * A fast, VERIFIED default left-click: hover, confirm the live top menu entry really is [action] on
     * [target] (defaults to this entity's name), then left-click. No right-click fallback — returns false
     * if it can't confirm, so a tight loop can just retry next tick.
     */
    fun leftClickIfDefault(action: String, target: String? = null): Boolean

    /**
     * Right-click once and select the FIRST of [actions] (in preference order) present in the live context
     * menu — for entities whose composition actions are empty but whose live menu carries the real options.
     */
    fun interactAny(actions: List<String>, target: String? = null): Boolean
}
