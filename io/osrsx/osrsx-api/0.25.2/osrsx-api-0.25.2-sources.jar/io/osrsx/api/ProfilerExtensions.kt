package io.osrsx.api

/**
 * Kotlin-idiomatic sugar over [Profiler]. These are `inline`, so when profiling is disabled the compiler
 * collapses the whole call to just running your block — no lambda allocation, no interface dispatch, no
 * timestamps. That is what makes it safe to sprinkle `section(...) { … }` through hot paths in shipping code.
 *
 * Java callers use the [Profiler] members directly ([Profiler.time], [Profiler.span]); these are Kotlin-only.
 */

/**
 * Time [block] under [label] — the Kotlin-idiomatic, zero-overhead-when-off form of [Profiler.time].
 * Records wall-clock and marshalls even if [block] throws.
 *
 * ```
 * val fish = profiler.section("fishing-tick") { onLoop() }
 * ```
 */
inline fun <T> Profiler.section(label: String, block: () -> T): T {
    if (!enabled) return block()
    val span = span(label)
    return try {
        block()
    } finally {
        span.close()
    }
}

/**
 * Run [block] and return how many client-thread marshalls it incurred (0 when profiling is off). The
 * quickest way to answer "how many game-thread hops does this operation cost?" — the number to minimise when
 * chasing the "many small marshalls instead of one wrapped scope" inefficiency.
 *
 * ```
 * val hops = profiler.measureMarshalls { walking.clickWalk(target) }
 * if (hops > 4) log.w("clickWalk cost $hops marshalls — batch the reads")
 * ```
 */
inline fun Profiler.measureMarshalls(label: String = "measure", block: () -> Unit): Long {
    if (!enabled) {
        block()
        return 0L
    }
    val span = span(label)
    return try {
        block()
        span.marshalls()
    } finally {
        span.close()
    }
}

/**
 * Run [block] only when profiling is enabled — for instrumentation whose *setup* is too expensive to build
 * unconditionally (formatting a big label, snapshotting state). The recording calls themselves are already
 * cheap no-ops when disabled, so you rarely need this; reach for it only around genuinely costly prep.
 */
inline fun Profiler.whenEnabled(block: Profiler.() -> Unit) {
    if (enabled) block()
}

/** [section] straight from a plugin body: `profile("tick") { … }` with no `profiler.` prefix. */
inline fun <T> PluginApi.profile(label: String, block: () -> T): T = profiler.section(label, block)

/**
 * Render this report as a compact, aligned, human-readable table — for `log`-ing, dumping to a report file,
 * or eyeballing over the debug socket. Timers are shown with their marshalls-per-run so the offenders stand
 * out at a glance.
 */
fun ProfileReport.render(): String {
    if (timers.isEmpty() && counters.isEmpty() && gauges.isEmpty()) return "profiler: (no data)"
    val sb = StringBuilder()
    sb.append("profiler report — window ").append(windowMillis).append("ms\n")

    if (timers.isNotEmpty()) {
        sb.append("\ntimers (by total time):\n")
        val w = timers.maxOf { it.label.length }.coerceIn(8, 40)
        sb.append("  %-${w}s %8s %10s %9s %11s\n".format("label", "runs", "total ms", "avg ms", "marsh/run"))
        for (t in timers) {
            sb.append(
                "  %-${w}s %8d %10.2f %9.3f %11.1f\n".format(
                    t.label.take(w), t.count, t.totalMs, t.avgMs, t.marshallsPerRun,
                ),
            )
        }
    }
    if (counters.isNotEmpty()) {
        sb.append("\ncounters:\n")
        val w = counters.maxOf { it.label.length }.coerceIn(8, 40)
        for (c in counters) sb.append("  %-${w}s %12d\n".format(c.label.take(w), c.value))
    }
    if (gauges.isNotEmpty()) {
        sb.append("\ngauges (last / min / mean / max):\n")
        val w = gauges.maxOf { it.label.length }.coerceIn(8, 40)
        for (g in gauges) {
            sb.append(
                "  %-${w}s %10.2f %10.2f %10.2f %10.2f\n".format(g.label.take(w), g.last, g.min, g.mean, g.max),
            )
        }
    }
    return sb.toString()
}
