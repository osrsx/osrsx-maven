package io.osrsx.api

/**
 * One valued bank holding: [quantity] of item [id] worth [value] gp in total (unit price × quantity, with
 * coins/platinum tokens valued from their face amount). Returned by [Bank.topValue].
 *
 * @since 0.4.0
 */
data class ValuedStack(val id: Int, val quantity: Int, val value: Long)

/**
 * A ranked bank valuation: the [top] most-valuable stacks (highest first) and the [total] value of every
 * stack considered.
 *
 * @since 0.4.0
 */
data class BankValuation(val top: List<ValuedStack>, val total: Long)
