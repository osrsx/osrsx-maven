package io.osrsx.api

import java.util.stream.Stream

/**
 * A fluent, composable, path-aware query over one scene-entity type — the plugin-facing surface of the
 * engine's query engine (`io.osrsx.methods.query`). Every entity type ([NpcQuery] / [PlayerQuery] /
 * [GameObjectQuery] / [GroundItemQuery]) exposes the SAME verbs via the self-type [Q], so the surface is
 * uniform and discoverable — the analogue of DreamBot's `*Query` builders, but engine-free.
 *
 * Lazy: intermediate ops ([keepIf] / [named] / [within] / [sortNearest] / …) only record intent; the scene
 * snapshot is read and streamed once, at a terminal ([list] / [first] / [nearest] / [count] / …). Results
 * are instanced, so a query is safe to build and reuse without touching global state.
 *
 * Path-distance sorts ([sortNearestPath] / [nearestByPath]) pre-compute each candidate's walk distance ONCE
 * before sorting, so pathfinding never runs inside a comparator.
 *
 * A query **is** an [Iterable], so — once you've filtered/sorted it — the whole Kotlin standard library is
 * available directly: `for (goblin in npcs.query().named("Goblin"))`, `objects.query().named("Bank booth")
 * .map { it.tile() }`, `npcs.query().alive().minByOrNull { it.distance() }`, `.groupBy { it.id }`, etc.
 * Iterating snapshots the results once (like any terminal). For lazy pipelines use [asSequence].
 *
 * @param T the scene-entity type this query yields (an [SceneEntity] subtype).
 * @param Q the concrete query self-type, so intermediate ops return the specific query for chaining.
 * @since 0.4.0
 */
interface Query<T : SceneEntity, Q : Query<T, Q>> : Iterable<T> {

    /**
     * Snapshot the surviving results and iterate them — this is what makes a query usable in `for (x in q)`
     * and with every stdlib collection op (`map`/`filter`/`associateBy`/`minByOrNull`/…). Equivalent to
     * `list().iterator()`.
     */
    override fun iterator(): Iterator<T> = list().iterator()

    /** A lazy [Sequence] over the surviving results, for stdlib sequence pipelines without a Java [Stream]. */
    fun asSequence(): Sequence<T> = list().asSequence()

    // ---- intermediate ops (filters) ----

    /** Keep only entities matching [predicate]. */
    fun keepIf(predicate: (T) -> Boolean): Q

    /** Drop entities matching [predicate]. */
    fun removeIf(predicate: (T) -> Boolean): Q

    /** Alias for [keepIf]. */
    fun filter(predicate: (T) -> Boolean): Q

    /** Keep entities whose name equals [name] (case-insensitive). */
    fun named(name: String): Q

    /** Keep entities whose name contains [part] (case-insensitive). */
    fun nameContains(part: String): Q

    /** Keep entities within Chebyshev [radius] tiles of the local player. */
    fun within(radius: Int): Q

    /** Keep entities within Chebyshev [radius] tiles of [center]. */
    fun within(center: Tile, radius: Int): Q

    /** Keep entities inside the axis-aligned box with corners [a] and [b] (inclusive), on [a]'s plane. */
    fun withinArea(a: Tile, b: Tile): Q

    /** Keep only entities the local pathfinder can actually reach (accounts for walls/rivers/fences). */
    fun reachable(): Q

    // ---- intermediate ops (sort / slice) ----

    /** Sort by an arbitrary [comparator] (replaces any prior sort). */
    fun sort(comparator: Comparator<T>): Q

    /** Sort nearest-first by Chebyshev (straight-line) distance from the local player. */
    fun sortNearest(): Q

    /** Sort furthest-first by Chebyshev distance from the local player. */
    fun sortFurthest(): Q

    /** Sort nearest-first by PATH distance (walk distance around walls); unreachable candidates rank last. */
    fun sortNearestPath(): Q

    /** Sort furthest-first by PATH distance; unreachable candidates rank first. */
    fun sortFurthestPath(): Q

    /** Skip the first [count] results (after filtering/sorting). */
    fun skip(count: Int): Q

    /** Keep at most [maxSize] results (after filtering/sorting). */
    fun limit(maxSize: Int): Q

    /** Run [action] over each surviving result (for debugging/inspection) without altering the set. */
    fun peek(action: (T) -> Unit): Q

    /** Escape hatch: replace the surviving result list with [processor]'s output (after sort, before slice). */
    fun postProcess(processor: (List<T>) -> List<T>): Q

    // ---- terminals ----

    /** All surviving results, filtered → sorted → post-processed → skipped → limited. */
    fun list(): List<T>

    /** The first surviving result, or null. */
    fun first(): T?

    /** Number of surviving results. */
    fun count(): Int

    /** True if any entity survives the filters. */
    fun any(): Boolean

    /** True if no entity survives the filters. */
    fun isEmpty(): Boolean

    /** A uniformly random surviving result, or null. */
    fun random(): T?

    /** A Java [Stream] over the surviving results, for authors who want the stream API directly. */
    fun stream(): Stream<T>

    /** Fold the surviving results with [aggregator] (escape hatch to arbitrary reductions). */
    fun <R> aggregate(aggregator: (List<T>) -> R): R

    /** Nearest by Chebyshev (straight-line) distance from the local player; ignores any set sort/slice. */
    fun nearest(): T?

    /** Nearest by PATH distance around walls; unreachable candidates rank last. Ignores any set sort/slice. */
    fun nearestByPath(): T?
}

/**
 * Fluent query over live NPCs — obtained from [Npcs.query]. Adds NPC-specific filters on top of the shared
 * [Query] verbs.
 *
 * @since 0.4.0
 */
interface NpcQuery : Query<Npc, NpcQuery> {
    /** Keep NPCs whose id is any of [ids]. */
    fun id(vararg ids: Int): NpcQuery

    /** Keep NPCs whose menu actions include [action] (case-insensitive), e.g. "Attack"/"Talk-to". */
    fun withAction(action: String): NpcQuery

    /** Keep NPCs that are not dead/dying. */
    fun alive(): NpcQuery

    /** Keep NPCs currently interacting with (targeting) the local player. */
    fun targetingMe(): NpcQuery
}

/**
 * Fluent query over live players (including the local player) — obtained from [Players.query].
 *
 * @since 0.4.0
 */
interface PlayerQuery : Query<Player, PlayerQuery> {
    /** Keep players whose combat level is in `[min, max]`. */
    fun combatLevel(min: Int, max: Int): PlayerQuery

    /** Keep players that are currently walking/running. */
    fun moving(): PlayerQuery
}

/**
 * Fluent query over scene objects (game objects plus wall/decorative/ground objects) — obtained from
 * [GameObjects.query].
 *
 * @since 0.4.0
 */
interface GameObjectQuery : Query<SceneObject, GameObjectQuery> {
    /** Keep objects whose id is any of [ids]. */
    fun id(vararg ids: Int): GameObjectQuery

    /** Keep objects whose live menu actions include [action] (case-insensitive), e.g. "Open"/"Mine". */
    fun withAction(action: String): GameObjectQuery
}

/**
 * Fluent query over ground items in the loaded scene — obtained from [GroundItems.query].
 *
 * @since 0.4.0
 */
interface GroundItemQuery : Query<GroundItem, GroundItemQuery> {
    /** Keep ground items whose id is any of [ids]. */
    fun id(vararg ids: Int): GroundItemQuery

    /** Keep ground items whose stack quantity is at least [amount]. */
    fun quantityAtLeast(amount: Int): GroundItemQuery
}
