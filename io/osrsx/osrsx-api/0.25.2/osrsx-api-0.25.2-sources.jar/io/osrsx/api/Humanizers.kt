package io.osrsx.api

/**
 * Background-humanizer partitioning a plugin may need while it drives the cursor itself — e.g. a boss
 * plugin whose hover-wander owns the mouse for the whole fight silences the generic idle-mouse drift so
 * it can't pull the cursor off the dodge tile. An engine-adjacent, first-party surface (like
 * [CameraControl]).
 */
interface Humanizers {
    /** Enable/disable the idle-mouse humanizer. Returns the PREVIOUS state so a plugin can restore it on stop. */
    fun setIdleMouse(enabled: Boolean): Boolean

    /** Whether the idle-mouse humanizer is currently enabled. */
    fun idleMouseEnabled(): Boolean

    // ---- click-placement policy (@since 0.4.0) ----

    /**
     * This plugin's active click-placement policy — where inside a target's clickbox a synthetic click
     * lands. See [ClickConfig].
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun clickConfig(): ClickConfig = ClickConfig()

    /**
     * Set this plugin's click-placement policy while it drives the cursor. Returns the PREVIOUS config so a
     * plugin can restore it on stop (mirroring [setIdleMouse]).
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun setClickConfig(config: ClickConfig): ClickConfig = ClickConfig()
}
