package io.osrsx.api

import java.awt.Color

/** Default highlight lifetime when a caller doesn't pass one — one minute. */
const val DEFAULT_HIGHLIGHT_MS: Long = 60_000L

/** Pass as the duration to keep a highlight up until it is removed by hand — it never auto-expires. */
const val HIGHLIGHT_FOREVER: Long = -1L

/**
 * How a highlight's shape is drawn: a hollow [OUTLINE] (default), a translucent [FILL], or [BOTH].
 */
enum class HighlightShape { OUTLINE, FILL, BOTH }

/**
 * An opacity pulse — the highlight's alpha lerps smoothly between [minAlpha] and [maxAlpha] and back over
 * [periodMs] (a sine, so it eases at the extremes). This is the "blink" effect. Alphas are 0f..1f
 * multipliers applied on top of the base colour's own alpha.
 */
data class Blink(
    val periodMs: Long = 1_000L,
    val minAlpha: Float = 0.15f,
    val maxAlpha: Float = 1f,
)

/**
 * A colour animation — the highlight lerps through [colors] in order over [periodMs], smoothly blending
 * between adjacent stops. While set it overrides [HighlightStyle.color]. A single-element list is just a
 * constant colour. Needs at least one colour.
 *
 * @property pingPong true = bounce A→B→…→A→…→B (default); false = loop A→B→…→A wrapping back to the first.
 */
data class ColorCycle(
    val colors: List<Int>,
    val periodMs: Long = 2_000L,
    val pingPong: Boolean = true,
) {
    init { require(colors.isNotEmpty()) { "ColorCycle needs at least one colour" } }

    /** Vararg ARGB `0xAARRGGBB` stops. */
    constructor(vararg colors: Int, periodMs: Long = 2_000L, pingPong: Boolean = true) :
        this(colors.toList(), periodMs, pingPong)

    /** Vararg [java.awt.Color] stops (each converted to ARGB, alpha honoured). */
    constructor(vararg colors: Color, periodMs: Long = 2_000L, pingPong: Boolean = true) :
        this(colors.map { it.rgb }, periodMs, pingPong)
}

/**
 * How a highlight looks. Every field has a sensible default, so a bare `HighlightStyle()` is a solid cyan
 * outline. Build variants with `copy(...)`, e.g. `HighlightStyle(color = Color.RED, shape = HighlightShape.BOTH)`.
 *
 * @property color the base ARGB `0xAARRGGBB` colour (used unless [colorCycle] is set). Its alpha is honoured.
 * @property shape [OUTLINE][HighlightShape.OUTLINE] / [FILL][HighlightShape.FILL] / [BOTH][HighlightShape.BOTH].
 * @property borderWidth outline stroke width in pixels (ignored for a pure fill).
 * @property fillOpacity alpha multiplier (0f..1f) for the fill; the outline uses the colour's own alpha.
 * @property blink optional opacity pulse (see [Blink]).
 * @property colorCycle optional colour animation (see [ColorCycle]); overrides [color] while present.
 * @property label optional text drawn at the highlight (entity/tile centre).
 */
data class HighlightStyle(
    val color: Int = 0xFF00FFFF.toInt(), // cyan
    val shape: HighlightShape = HighlightShape.OUTLINE,
    val borderWidth: Float = 2f,
    val fillOpacity: Float = 0.2f,
    val blink: Blink? = null,
    val colorCycle: ColorCycle? = null,
    val label: String? = null,
) {
    /** [color] from a [java.awt.Color] (its alpha channel is honoured). */
    constructor(
        color: Color,
        shape: HighlightShape = HighlightShape.OUTLINE,
        borderWidth: Float = 2f,
        fillOpacity: Float = 0.2f,
        blink: Blink? = null,
        colorCycle: ColorCycle? = null,
        label: String? = null,
    ) : this(color.rgb, shape, borderWidth, fillOpacity, blink, colorCycle, label)

    /** [color] from float components (each `0f..1f`). */
    constructor(
        r: Float, g: Float, b: Float, a: Float = 1f,
        shape: HighlightShape = HighlightShape.OUTLINE,
        borderWidth: Float = 2f,
        fillOpacity: Float = 0.2f,
        blink: Blink? = null,
        colorCycle: ColorCycle? = null,
        label: String? = null,
    ) : this(packArgb(r, g, b, a), shape, borderWidth, fillOpacity, blink, colorCycle, label)
}

/**
 * A live handle to one active highlight, returned by every [Highlights] call. Keep it to remove the
 * highlight early or to re-style/extend it; drop it and the highlight still auto-expires on its timer.
 */
interface Highlight {
    /** True until [remove]d or the timer expires. */
    val active: Boolean

    /** Remove this highlight now. Idempotent — a second call is a no-op. */
    fun remove()

    /** Replace the visual style (e.g. flip the colour when the plugin's state changes). */
    fun restyle(style: HighlightStyle)

    /** Reset the remaining lifetime to [durationMs] from now ([HIGHLIGHT_FOREVER] = never expire). */
    fun keepFor(durationMs: Long)
}

/**
 * Draw attention to things on the game scene — tiles, objects, NPCs, players, ground items. Each call
 * paints an outline or fill over the target and returns a [Highlight] handle you can [remove][Highlight.remove]
 * at any time; otherwise it auto-expires after [durationMs] (default [DEFAULT_HIGHLIGHT_MS] = 1 minute,
 * or [HIGHLIGHT_FOREVER] to persist until removed).
 *
 * An entity highlight tracks the entity as it moves (it re-reads the live on-screen shape each frame) and
 * disappears while the entity is off-screen. All highlights are scoped to the calling plugin and cleared
 * automatically when it stops, so a forgotten handle can't leak paint into another plugin's session.
 *
 * ```kotlin
 * val boss = npcs.closest("General Graardor") ?: return
 * val h = highlights.highlight(boss, HighlightStyle(color = Color.RED, shape = HighlightShape.BOTH,
 *                                                   blink = Blink()))
 * // ...later, when the fight ends:
 * h.remove()
 * ```
 */
interface Highlights {
    /** Highlight a live scene [entity] (NPC / object / player / ground item); follows it as it moves. */
    fun highlight(
        entity: SceneEntity,
        style: HighlightStyle = HighlightStyle(),
        durationMs: Long = DEFAULT_HIGHLIGHT_MS,
    ): Highlight

    /** Highlight a world [tile]. */
    fun highlight(
        tile: Tile,
        style: HighlightStyle = HighlightStyle(),
        durationMs: Long = DEFAULT_HIGHLIGHT_MS,
    ): Highlight

    /** Highlight several [tiles] (e.g. an area) as one highlight under a single handle. */
    fun highlight(
        tiles: Collection<Tile>,
        style: HighlightStyle = HighlightStyle(),
        durationMs: Long = DEFAULT_HIGHLIGHT_MS,
    ): Highlight

    /** Remove every highlight this plugin has created. */
    fun clear()
}
