package io.osrsx.api

/**
 * The typed command set broadcast across the local osrsx client mesh. A closed, sealed protocol — decoded
 * only into these known shapes — so a received frame can never inflate into an arbitrary object graph.
 * Every command is executed on the receiving client through osrsx's synthetic-input APIs, never packets.
 *
 * @since 0.4.0
 */
sealed class MeshCommand {

    /** Follow a player by display name (the broadcaster fills in its own name for a "follow me"). */
    data class Follow(val playerName: String) : MeshCommand()

    /** Web-walk to a world tile. */
    data class WalkTo(val x: Int, val y: Int, val plane: Int) : MeshCommand()

    /** Use an inventory item (by id) on a scene entity resolved by [target]. */
    data class UseItemOn(val itemId: Int, val target: MeshTarget) : MeshCommand()

    /** An open extension slot for plugin-defined commands; the payload is opaque to the mesh. */
    data class Custom(val payload: String) : MeshCommand()
}

/** The kinds of scene entity a [MeshCommand.UseItemOn] can name, each resolvable by id on the receiver. @since 0.4.0 */
enum class MeshTargetKind { NPC, GAME_OBJECT, GROUND_ITEM }

/**
 * A scene target addressed by [kind] + entity [id], with the broadcaster's world tile ([x]/[y]/[plane])
 * carried as a locality hint (the receiver resolves the nearest matching id — coordinates disambiguate).
 *
 * @since 0.4.0
 */
data class MeshTarget(val kind: MeshTargetKind, val id: Int, val x: Int, val y: Int, val plane: Int)

/** A single-method receiver so callers can pass a lambda to [CommandMesh.onCommand]. @since 0.4.0 */
fun interface MeshCommandHandler {
    fun onCommand(command: MeshCommand)
}

/**
 * The plugin-facing facade over the authenticated cross-client command mesh: one object a controller uses to
 * [broadcast] interaction commands to every other osrsx client on this machine, while transparently
 * receiving peers' commands (executed for you via synthetic input, and observable via [onCommand]).
 *
 * The wire format, HMAC signing, machine binding and de-duplication are all engine-internal — callers never
 * touch them. Obtain it from [PluginContext.mesh] / the `mesh` authoring sugar.
 *
 * @since 0.4.0
 */
interface CommandMesh {

    /** Begin receiving (and executing) peers' commands. Idempotent-safe to call once at startup. */
    fun start()

    /** Broadcast [command] to every peer client. */
    fun broadcast(command: MeshCommand)

    /** Send [command] to the mesh — an alias for [broadcast] (the mesh is broadcast-addressed). */
    fun send(command: MeshCommand) = broadcast(command)

    /** "Follow me": tell peers to follow the given local player (typically this client's display name). */
    fun broadcastFollowMe(myName: String) = broadcast(MeshCommand.Follow(myName))

    /**
     * Observe commands received from peers (in addition to the engine executing them). Returns a
     * [Subscription] whose cancellation removes the handler.
     */
    fun onCommand(handler: MeshCommandHandler): Subscription
}
