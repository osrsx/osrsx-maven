package io.osrsx.api

/**
 * Read the player's game variables — **VarPlayers** ("varps") and **varbits**. These are the low-level
 * integer state flags the game server keeps per account, and are frequently the ONLY way to observe a
 * piece of game state from a plugin: quest stages, interface toggles, unlock flags, and the state of many
 * skilling objects (e.g. the four Fossil Island bird-house spaces) are exposed by the engine as a
 * varp/varbit value with no scene object or widget to read instead.
 *
 * A **varp** is a whole player variable addressed by its VarPlayer id. A **varbit** is a named bit-range
 * packed inside some varp, addressed by its own varbit id — the game defines thousands of them. Reference
 * them by name from the SDK's typesafe id catalog: [io.osrsx.ids.VarPlayers] / [io.osrsx.ids.Varbits]
 * (e.g. `varp(VarPlayers.BIRDHOUSE_TRANSMIT_A)`, `varbit(Varbits.FOSSIL_ACTIVITY_VALLEYBIRDHOUSE)`).
 *
 * Reads reflect the latest values the client has received from the server. They are marshalled onto the
 * client thread internally, so a plugin may call them from its loop thread like any other accessor.
 */
interface Varps {
    /** The value of VarPlayer [id] (a "varp"), or 0 when the id has not been set. See [io.osrsx.ids.VarPlayers]. */
    fun varp(id: Int): Int

    /** The value of varbit [id] (a bit-range packed inside some varp), or 0 when unset/unknown. See [io.osrsx.ids.Varbits]. */
    fun varbit(id: Int): Int
}
