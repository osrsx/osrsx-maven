package io.osrsx.api

/**
 * Humanised virtual-keyboard control — the keyboard counterpart of [Mouse], obtained from
 * [PluginContext.keyboard]. Keystrokes are fed through the client's synthetic-input pipeline (the same
 * one Space-to-continue and the bank search already use), so they register regardless of OS focus and
 * carry the engine's humanised typing cadence.
 *
 * Most plugins should NOT need this — [Dialogues], [Bank] and [GrandExchange] already type for you.
 * This surface exists for interfaces the higher-level APIs don't model: free-text prompts, arbitrary
 * numeric "Enter amount:" inputs (e.g. the Blast Furnace coffer), and interface keybinds.
 */
interface Keyboard {

    /** Type [text] char by char with humanised delays; optionally press Enter afterwards. */
    fun type(text: String, pressEnterAfter: Boolean = false)

    /** Type [text] like a human: humanised delays, thinking pauses and the occasional self-corrected
     *  typo. Prefer this for anything a player would genuinely type (names, amounts, search terms). */
    fun typeHuman(text: String, pressEnterAfter: Boolean = false)

    /** Press and release the virtual key [keyCode] (a `java.awt.event.KeyEvent.VK_*` constant). */
    fun pressKey(keyCode: Int)

    /** Hold [keyCode] down for [durationMs] (e.g. arrow keys for camera rotation). */
    fun holdKey(keyCode: Int, durationMs: Long)

    fun pressEnter()
    fun pressSpace()
    fun pressEscape()
    fun pressBackspace()

    /** Tap function key [n] (1..12) with a short humanised hold — interface keybinds. No-op outside 1..12. */
    fun pressFunctionKey(n: Int)

    /** True while a chatbox text/number input prompt ("Enter amount:", a search box, name entry) is
     *  open and consuming keystrokes. Poll this after the click that opens a prompt, before typing. */
    fun inputOpen(): Boolean

    /**
     * Type [amount] into the chatbox numeric prompt and press Enter, first waiting up to [timeoutMs]
     * for the prompt to actually open (typing before it opens would leak digits into public chat).
     * Blocks the calling loop thread while waiting. False if the prompt never opened.
     */
    fun enterAmount(amount: Int, timeoutMs: Long = 2500L): Boolean
}
