package io.osrsx.api


/**
 * A drawable, geometry-only snapshot of the route the [WebWalker] is currently following — everything an
 * overlay needs to render the active path, resolved by the engine so a plugin never touches the pathfinder
 * or scene internals. All positions are world [Tile]s; the plugin just projects and draws them.
 *
 * Obtain it with [WebWalker.routeView] each frame (it is non-blocking and null when the walker is idle).
 * The engine computes it exactly as the built-in overlay did: the collision-aware local tile path toward the
 * next waypoint, an off-plan object shortcut when one is being taken, the off-scene legs ahead, and the
 * destination marker — with the same anti-flicker hold, so drawing it reproduces the original overlay.
 */
data class RouteView(
    /** The final destination the walk is heading to. */
    val destination: Tile,
    /** The collision-aware local tile path from the player toward [target] — draw it as a connected line.
     *  Empty when the next waypoint is off-scene (follow [legs] instead). Has ≥ 2 tiles when present. */
    val localPath: List<Tile>,
    /** The on-foot waypoint currently being walked to (the end of [localPath]), or null when off-scene. */
    val target: Tile?,
    /** An off-plan object shortcut (tunnel/stile/gap) being taken instead of the long way around — not part
     *  of [legs] (the planner walked "through" the missing-collision wall), so draw it explicitly. Null when
     *  no shortcut applies. */
    val shortcut: WalkTransport?,
    /** The remaining route legs ahead (walk waypoints + transports), for the off-scene "ahead" guide. */
    val legs: List<RouteLeg>,
)

/**
 * The FULL whole-map planned route to a destination — every walked tile across all legs, in order, plus the
 * transports/teleports taken along the way. Where [RouteView] is the scene-local detail of the *active* walk
 * (the on-screen leg + a coarse ahead-guide), this is the entire cross-region path from the current position
 * to the destination — ideal for drawing the plan on the world map or minimap, or previewing a route to a
 * candidate destination before committing to walk.
 *
 * Obtain it via [WebWalker.globalRoute]. Non-blocking (returns the last background-computed plan and triggers
 * a recompute when the destination changes); null when no route is known yet.
 */
data class GlobalRoute(
    /** The destination this route reaches. */
    val destination: Tile,
    /** Every tile walked across the whole route, in order (all walking legs concatenated end to end). */
    val tiles: List<Tile>,
    /** The transports/teleports on the route, in order. */
    val transports: List<WalkTransport>,
)

/** One leg of a [RouteView]: a walk to a waypoint, or a transport/teleport to take. */
sealed interface RouteLeg {
    /** Where this leg ends (a walk waypoint, or a transport's landing tile). */
    val to: Tile

    /** Walk (locally) to [to]. */
    data class Walk(override val to: Tile) : RouteLeg
    /** Take [transport] (its [WalkTransport.to] is where it lands). */
    data class Transport(val transport: WalkTransport) : RouteLeg {
        override val to: Tile get() = transport.to
    }
}
