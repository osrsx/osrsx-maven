package io.osrsx.api

/** A named place (city, landmark, teleport destination) paired with its tile — from [Locations.places]. */
data class NamedTile(val name: String, val tile: Tile)

/** World-wide object/NPC location lookup (backed by the offline SQLite store). */
interface Locations {
    fun all(name: String): List<Tile>
    fun nearest(name: String): Tile?
    fun allObjects(name: String): List<Tile>
    fun allObjects(id: Int): List<Tile>
    fun nearestObject(name: String): Tile?
    fun nearestObject(id: Int): Tile?
    fun allNpcs(name: String): List<Tile>
    fun allNpcs(id: Int): List<Tile>
    fun nearestNpc(name: String): Tile?
    fun nearestNpc(id: Int): Tile?

    /**
     * The curated catalog of NAMED PLACES — in-game world-map labels (cities, landmarks: "Varrock",
     * "Grand Exchange") plus teleport destinations ("Falador Teleport") — each with its tile. For a
     * location picker/autocomplete; [place] resolves one by name.
     */
    fun places(): List<NamedTile>

    /** The tile of the named place [name] (case-insensitive exact match, from [places]), or null. */
    fun place(name: String): Tile?

    /**
     * The nearest tile of object [name] that sits in a CLUSTER — at least [minCount] of that object within
     * [radius] tiles — so a skiller travels to a real patch (a forest, a mining cluster) rather than a lone
     * catalogued object that merely happens to be closest (e.g. an ornamental tree by the GE). Falls back
     * to the nearest single object when no cluster qualifies.
     */
    fun nearestCluster(name: String, minCount: Int, radius: Int): Tile?
}
