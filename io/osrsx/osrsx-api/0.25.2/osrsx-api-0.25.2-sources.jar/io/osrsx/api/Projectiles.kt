package io.osrsx.api

/**
 * Read the projectiles currently in flight — the poll-style companion to the
 * [io.osrsx.api.events.ProjectileLaunched] event. The event tells you an attack fired; this answers
 * "is a projectile of id X in the air at me right now?" (e.g. gating a pre-impact prayer drop, or
 * distinguishing an unattributed hitsplat from floor damage while stationary).
 *
 * @since 0.25.0
 */
interface Projectiles {
    /** A snapshot of every projectile currently in flight in the loaded scene. */
    fun active(): List<ProjectileInfo>
}

/**
 * One in-flight projectile. [remainingCycles] is client cycles (~30 per game tick) until impact —
 * compare against a threshold rather than exact values; it decreases every frame.
 *
 * @since 0.25.0
 */
data class ProjectileInfo(
    val id: Int,
    /** Current interpolated position's tile, or null when unresolved. */
    val position: Tile?,
    /** The tile it will land on, or null for an actor-tracking projectile with no fixed endpoint. */
    val targetTile: Tile?,
    /** True when the local player is the projectile's interacting target. */
    val targetsMe: Boolean,
    val remainingCycles: Int,
)
