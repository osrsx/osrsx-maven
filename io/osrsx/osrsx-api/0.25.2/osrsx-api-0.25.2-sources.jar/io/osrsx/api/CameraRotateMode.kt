package io.osrsx.api

/**
 * How the [Camera] physically turns.
 *
 * - [MOUSE] — the classic middle-mouse drag. Realistic, but it competes for the single shared mouse
 *   gesture lock, so a turn cannot overlap a click/walk: one waits for the other.
 * - [KEYBOARD] — the game's arrow keys, HELD for the length of the turn (never tapped). This runs on a
 *   separate input path from the mouse, so a turn happens CONCURRENTLY with mouse work instead of
 *   contending for it.
 * - [AUTO] — keyboard only while the mouse is busy (or a walk click is imminent), mouse otherwise. So a
 *   turn never has to wait out a click, yet keeps the finely-tuned mouse-drag behaviour when the mouse
 *   is free.
 * - [DEFAULT] — follow the client-wide "Rotation method" setting (the initial state of every caller).
 *
 * Set a caller's preference with [Camera.rotateVia]; it applies to that caller's [Camera.rotateToYaw],
 * [Camera.rotateToPitch], [Camera.rotateTo] and [Camera.dragRotate].
 */
enum class CameraRotateMode { DEFAULT, MOUSE, KEYBOARD, AUTO }
