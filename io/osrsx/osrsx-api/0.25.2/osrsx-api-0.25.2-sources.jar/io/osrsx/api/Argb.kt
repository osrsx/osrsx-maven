package io.osrsx.api

import java.awt.Color

/**
 * Colour helpers shared by the plugin-graphics surfaces ([io.osrsx.plugin.Gfx2D], [io.osrsx.plugin.Gfx3D])
 * and the retained [Highlights] service. The single colour representation across the whole graphics API is a
 * packed **`0xAARRGGBB` int**; these pack the two friendlier inputs (float components and [java.awt.Color])
 * into it. Every colour-taking method/constructor on those surfaces exposes float and `Color` conveniences
 * that funnel through this into its one real `Int`-ARGB path.
 */

/** Pack float RGBA components (each `0f..1f`, clamped) into a `0xAARRGGBB` int. [a] defaults to opaque. */
fun packArgb(r: Float, g: Float, b: Float, a: Float = 1f): Int {
    fun ch(v: Float): Int = (v.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
    return (ch(a) shl 24) or (ch(r) shl 16) or (ch(g) shl 8) or ch(b)
}

/** A [java.awt.Color] as a `0xAARRGGBB` int (its alpha channel is honoured). */
fun argbOf(color: Color): Int = color.rgb
