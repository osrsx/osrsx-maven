package io.osrsx.api

/**
 * The osrsx **auto-questing** seam: a data-only view over the client's embedded Quest Helper knowledge
 * engine. The engine (osrsx-core) hosts the vendored Quest Helper headless — wiring it into the live
 * RuneLite injector / event bus / config manager, which a plugin can never reach — and publishes this
 * interface through the [ServiceRegistry] under [Quests]. A plugin looks it up
 * (`ctx.services().get<Quests>("1.0.0")`) and drives each computed step with the ordinary automation
 * accessors ([Walking], [Npcs], [Dialogues], …).
 *
 * The whole point of the seam is that **no `net.runelite.*` or `com.questhelper.*` type ever crosses it**:
 * the engine translates Quest Helper's live [com.questhelper.steps.QuestStep] into the plain
 * [QuestStepInfo] below (positions as [Tile], ids as `Int`), so the driver stays a first-class SDK plugin.
 *
 * Typical loop (see the standalone Auto Quest plugin):
 * ```
 * val quests = ctx.services().get<Quests>("1.0.0") ?: return NO_LOOP
 * if (!quests.isActive()) quests.resolve(configName)?.let { quests.start(it) }
 * val step = quests.currentStep() ?: return 800
 * // ...dispatch step.kind through ctx.walking()/npcs()/dialogues()...
 * ```
 *
 * @since 0.19.0
 */
interface Quests {
    /**
     * Resolve a quest by its Quest Helper display name (e.g. "Cook's Assistant") or its enum-constant name
     * (case-insensitive, spaces or underscores), or null if Quest Helper doesn't know it.
     */
    fun resolve(nameOrConst: String): QuestRef?

    /**
     * Instantiate + activate [quest] as the hosted quest, replacing any currently-hosted one. Returns true
     * once it started; false if Quest Helper failed to construct it. Runs on the engine's client thread.
     */
    fun start(quest: QuestRef): Boolean

    /** Stop driving the current quest and release its engine/event-bus wiring. No-op if none is active. */
    fun stop()

    /** True while a quest is loaded and being hosted. */
    fun isActive(): Boolean

    /** True when the hosted quest's state is FINISHED. */
    fun isComplete(): Boolean

    /** True when the hosted quest has NOT been started in-game yet (state NOT_STARTED). The driver runs its
     *  depositing front-load ONLY when this is true — a fresh start has no quest-progress items to bank; once
     *  in progress the inventory holds items obtained during the quest that aren't in the bring-list, which the
     *  front-load would otherwise deposit as "foreign". @since 0.19.2 */
    fun notStarted(): Boolean

    /** True if the hosted quest's general requirements (skills, prereq quests, …) are all met — i.e. it is
     *  safe to attempt hands-off. False when no quest is hosted. */
    fun clientMeetsRequirements(): Boolean

    /**
     * The concrete step to perform right now, already resolved through Quest Helper's conditional/owner-step
     * machinery (and past its per-floor staircase/ladder navigation branches), as a plain [QuestStepInfo] —
     * or null when no quest is hosted / no step is computed yet. Re-read each loop; the engine advances the
     * underlying step as the quest's progress var changes.
     */
    fun currentStep(): QuestStepInfo?

    /** The quest's whole declared required-item list (for up-front provisioning), or empty. */
    fun itemRequirements(): List<QuestItemReq>

    /** The item requirements of the CURRENT step only (for just-in-time provisioning that won't re-buy an
     *  item an earlier step already consumed), or empty. */
    fun activeStepItemRequirements(): List<QuestItemReq>
}

/**
 * An opaque handle to a Quest Helper quest resolved via [Quests.resolve]. [name] is the display name (for
 * UI / config persistence); [id] is the engine's stable identifier used to re-select it in [Quests.start].
 */
data class QuestRef(val name: String, val id: String)

/**
 * The kind of a [QuestStepInfo], already narrowed by the engine from Quest Helper's step class hierarchy so
 * the driver dispatches on a flat enum instead of `net.runelite`/`questhelper` `instanceof` checks.
 * [PUZZLE], [WIDGET] and [UNKNOWN] are steps osrsx does not reliably automate — the driver pauses for manual
 * takeover and auto-resumes once the quest var advances.
 */
enum class StepKind {
    /** Talk-to / pickpocket / trade an NPC ([QuestStepInfo.npcIds], [QuestStepInfo.npcName]). */
    NPC,

    /** Perform an emote at/near an NPC ([QuestStepInfo.emoteSpriteId], [QuestStepInfo.npcName]). */
    NPC_EMOTE,

    /** Interact with a scene object ([QuestStepInfo.objectIds]). */
    OBJECT,

    /** Perform an emote at a location ([QuestStepInfo.emoteSpriteId]). */
    EMOTE,

    /** Dig with a spade at [QuestStepInfo.targetTile]. */
    DIG,

    /** Walk to [QuestStepInfo.targetTile] (or, if [QuestStepInfo.combineItemIdGroups] names two held items,
     *  combine them) — the plain detailed step. */
    WALK,

    /** A puzzle step — pause for manual takeover. */
    PUZZLE,

    /** An interface/widget step — pause for manual takeover. */
    WIDGET,

    /** An unrecognised step type — pause for manual takeover. */
    UNKNOWN,
}

/** One dialogue option Quest Helper declared for a step: match by [text] (contains, case-insensitive) or,
 *  when the menu is by-position, by 1-based [id] (`<= 0` if none). */
data class QuestChoice(val text: String?, val id: Int)

/**
 * A flat, engine-free snapshot of the current Quest Helper step. Only the fields relevant to the step's
 * [kind] are populated; the rest are empty/null/-1. Positions are [Tile]; entities are id lists.
 */
data class QuestStepInfo(
    /** The narrowed step kind the driver dispatches on. */
    val kind: StepKind,
    /** The step's joined instruction text (for verb inference, combat detection, and display). */
    val text: String,
    /** The step's target location, or null if it carries none. */
    val targetTile: Tile?,
    /** Candidate NPC ids for an [StepKind.NPC] step (any one matches), or empty. */
    val npcIds: List<Int>,
    /** The step's NPC name, if any ([StepKind.NPC] / [StepKind.NPC_EMOTE]). */
    val npcName: String?,
    /** Candidate object ids for an [StepKind.OBJECT] step (any one matches), or empty. */
    val objectIds: List<Int>,
    /** The emote sprite id for an [StepKind.EMOTE] / [StepKind.NPC_EMOTE] step, or -1. */
    val emoteSpriteId: Int,
    /** Quest-Helper-declared dialogue options for this step (empty when it guides none). */
    val dialogueChoices: List<QuestChoice>,
    /** For a "use A on B" combine: the id-alternates of each item Quest Helper highlighted in the inventory
     *  (the driver picks two held items, one per group, and combines them). Empty for a plain walk step. */
    val combineItemIdGroups: List<List<Int>>,
    /** The inventory item to USE on this [StepKind.OBJECT] (Quest Helper's step item-icon), or -1. When set
     *  and the item is held, the driver uses that item on the object instead of a plain interact — e.g. BKF's
     *  "USE the cabbage on the hole". @since 0.19.1 */
    val useItemId: Int = -1,
)

/**
 * A Quest Helper item requirement, flattened for the driver's provisioner/equipper. [ids] are the id
 * alternates (any one satisfies); [qty] is the required count; [isActual] is Quest Helper's
 * `isActualItem` (only real, obtainable items are provisioned); [mustBeEquipped] marks items that must be
 * worn for the step (equipped just-in-time).
 */
data class QuestItemReq(
    val ids: List<Int>,
    val qty: Int,
    val name: String,
    val isActual: Boolean,
    val mustBeEquipped: Boolean,
)
