package io.osrsx.api

/**
 * Per-plugin telemetry: emit named events and metrics that the engine ships to the osrsx backend, where a
 * plugin author sees them on the dev portal (scoped to their OWN plugins) and admins see them fleet-wide.
 *
 * Every call is auto-scoped to the CALLING plugin by the engine (identity comes from the plugin's loop
 * thread, exactly like [Profiler]), so two plugins using the same metric name never collide and a plugin
 * can only ever emit under its own id.
 *
 * **Cheap and safe.** Shipping is buffered and best-effort off the hot path; when the client has no
 * upstream session, or telemetry is disabled, every method here is a no-op. Nothing throws, so you can
 * leave `telemetry.*` calls in shipping code freely. Values passed in [event] `data` should be
 * JSON-friendly (String / Number / Boolean / null); anything else is stringified.
 *
 * ```
 * // in onLoop, after banking a haul:
 * telemetry.count("logs_banked", 28)
 * telemetry.gauge("gp_per_hour", gpPerHour)
 * telemetry.event("trip_complete", mapOf("trips" to trips, "profit" to profit))
 * ```
 *
 * Obtain it via [PluginContext.telemetry] or, inside a plugin body, the `telemetry` sugar on [PluginApi].
 * This is the coarse, ship-it-home surface; for local, in-process performance analysis (client-thread
 * marshall attribution) use [Profiler] instead.
 */
interface Telemetry {
    /** Whether telemetry is currently being shipped. When `false`, every method here is a no-op — cheap to
     *  read, so you can guard genuinely expensive `data` construction behind it. */
    val enabled: Boolean

    /**
     * Record a named event with optional structured fields. [type] is a short stable slug
     * (`"trip_complete"`, `"level_up"`, `"target_lost"`); [data] is any extra context, keyed by field name.
     * Buffered and shipped in batches; a no-op when [enabled] is `false`.
     */
    fun event(type: String, data: Map<String, Any?> = emptyMap())

    /** Increment a named counter by [amount] (default 1) — running tallies like items gained, tasks done,
     *  retries. Aggregated client-side and flushed periodically. Cheap no-op when disabled. */
    fun count(name: String, amount: Long = 1)

    /** Record a point-in-time numeric sample under [name] — gp/hr, xp/hr, queue depth, distance-to-target.
     *  Aggregated client-side (last/min/max/mean) and flushed periodically. Cheap no-op when disabled. */
    fun gauge(name: String, value: Double)
}
