package io.osrsx.api

/**
 * Account-wide break coordination, published once to the [ServiceRegistry]. Every plugin consults the
 * SAME manager before acting ([mayAct]), so breaks apply to the whole account instead of each plugin
 * scheduling its own — the coordination the antiban work in task 8 builds on. A plugin can publish its
 * own [BreakManager] to override the default policy.
 */
interface BreakManager {
    /** True while a break is active — plugins should idle (do nothing) until it ends. */
    fun onBreak(): Boolean

    /** Convenience for `!onBreak()` — the guard a plugin puts at the top of its loop. */
    fun mayAct(): Boolean = !onBreak()

    /** Milliseconds until the next scheduled break starts, or 0 while already on break. */
    fun timeUntilBreakMs(): Long

    /** Force a break now for [durationMs]. */
    fun startBreak(durationMs: Long)

    /** End any active break immediately and reschedule the next one. */
    fun endBreak()

    // ---- break lifecycle hooks (@since 0.4.0) ----

    /**
     * Register a veto [guard] consulted just before a break starts: return false to hold the break off
     * *right now* (mid-action, in combat, a step from the bank …). ALL registered guards must allow before
     * the account logs out. [name] keys the registration; returns a [Subscription] that unregisters it.
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun registerGuard(name: String, guard: () -> Boolean): Subscription = Subscription {}

    /**
     * Register a [callback] fired when a break BEGINS (just after logout). [name] keys the registration;
     * returns a [Subscription] that unregisters it.
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun onBreakStart(name: String, callback: () -> Unit): Subscription = Subscription {}

    /**
     * Register a [callback] fired when a break ENDS (just after logging back in). [name] keys the
     * registration; returns a [Subscription] that unregisters it.
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun onBreakEnd(name: String, callback: () -> Unit): Subscription = Subscription {}

    /**
     * Whether a break may start right now — true when every registered [registerGuard] guard allows. A
     * read-only view of the veto state (does not itself start a break).
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun canBreakNow(): Boolean = true
}
