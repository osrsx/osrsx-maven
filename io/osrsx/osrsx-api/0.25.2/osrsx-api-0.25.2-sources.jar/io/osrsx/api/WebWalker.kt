package io.osrsx.api


/**
 * Whole-map web walker: plan + follow a tile-level route using transports/teleports as needed.
 *
 * Drive it by calling [walkTo] each loop until [arrived]. The walk is fully observable: register a
 * [WalkListener] (or pass one to [walkTo]) to receive every [WalkEvent] — started, path planned,
 * transport taken, stuck, unreachable, bank detour, arrived, failed — and/or poll [state] at any time
 * from any thread. Behaviour is shaped by a [WalkConfig] (transport gating, run policy, stamina,
 * pathfinding timeout, bank runs, …) set via [configure] or per call. Fairy rings, charters, teleports
 * and other transports are handled internally by the walker — there is no separate fairy-ring API.
 */
interface WebWalker {
    /** Advance toward [dest] using the active [config]; call repeatedly from the plugin loop until [arrived]. */
    fun walkTo(dest: Tile): Boolean
    /** Advance toward [dest] under [config] (becomes the active config). */
    fun walkTo(dest: Tile, config: WalkConfig): Boolean
    /** True once standing exactly on [dest] (or beside it when the tile itself is unstandable). */
    fun arrived(dest: Tile): Boolean

    /**
     * Stop the current walk and fully reset the walker: clears the cached route plan, any in-progress bank/GE
     * detour, and returns [state] to [WalkPhase.IDLE]. Call this to cancel a walk outright (e.g. a "Stop"
     * button) — merely ceasing to call [walkTo] leaves the last plan/state around.
     */
    fun stop()

    /** Set the active walk configuration (clears any cached plan so the new rules take effect). */
    fun configure(config: WalkConfig)
    /** The active walk configuration. */
    fun config(): WalkConfig

    /** Register a listener notified of every [WalkEvent]; returns it so it can be [removeListener]'d. */
    fun addListener(listener: WalkListener): WalkListener
    fun removeListener(listener: WalkListener)

    /** An immutable snapshot of the walker's current state — safe to read from any thread. */
    fun state(): WalkState

    /**
     * A drawable, geometry-only view of the route currently being followed — the local tile path, an active
     * object shortcut, the off-scene legs ahead and the destination — for rendering an in-world overlay
     * (see [RouteView]). Reflects whatever the walker is heading to (regardless of which plugin is driving it),
     * or null when idle. Non-blocking (never pathfinds on the caller's thread) and safe to call every frame
     * from an overlay; intended to be called on the render thread where scene projection is valid.
     */
    fun routeView(): RouteView?

    /**
     * The FULL whole-map planned route the walker is currently following — every walked tile and transport
     * from the current position to the active destination (see [GlobalRoute]) — or null when idle. Unlike
     * [routeView] (the scene-local view of the current leg) this is the entire cross-region path, e.g. to
     * draw the plan on the world map. Non-blocking; safe to poll each frame.
     */
    fun globalRoute(): GlobalRoute?

    /**
     * The FULL whole-map planned route to an arbitrary [dest] — for previewing where a walk *would* go before
     * committing to it (e.g. after picking a location/NPC/object). Non-blocking: returns the last
     * background-computed plan and triggers a recompute when [dest] changes, so the first call for a new
     * destination may return null until the plan is ready. Never pathfinds on the caller's thread.
     */
    fun globalRoute(dest: Tile): GlobalRoute?

    /**
     * The nearest bank you can ACTUALLY reach (the tile to stand on to use it), or null if none is
     * routable. Reachability is judged by global pathfinding to the bank's customer side — a banker's
     * interior tile, or a booth's stand ring — so a wall-mounted booth you can only touch from the wrong
     * side (e.g. the Cooks' Guild from outside its gated door) is correctly skipped. Walk to this with
     * [walkTo], then open the bank. Prefer this over a raw nearest-"Bank booth" object lookup.
     */
    fun nearestBank(): Tile?
}
