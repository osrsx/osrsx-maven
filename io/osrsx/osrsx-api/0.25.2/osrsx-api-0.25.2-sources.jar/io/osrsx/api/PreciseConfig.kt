package io.osrsx.api

/**
 * Tunables for a **precise** (tracking-triggerbot) interaction — [Interactable.interactPrecise] /
 * [Interactable.hoverPrecise].
 *
 * The ordinary [Interactable.interact] path computes ONE on-screen point and then blindly moves the
 * cursor there. While that humanised move is in flight the point goes stale — the target steps, or the
 * camera drifts (most acutely while the avatar is *walking*) — so the click can land where the
 * tile/NPC/object *used to be*. A precise interaction instead HOMES the humanised cursor onto the target's
 * **live** on-screen clickbox, re-read every client tick (~20ms, far finer than the 600ms game tick), and
 * commits the click only once the cursor has rested inside that fresh clickbox for [dwellMs] — a geometric
 * triggerbot lock. This is the SDK generalisation of the boss-plugin NPC triggerbot, usable for any
 * clickable: NPC, object, ground item, or a walk tile's polygon. See [Mouse.moveTracking].
 *
 * @since 0.11.0
 */
data class PreciseConfig(
    /**
     * The cursor must rest inside the live clickbox continuously for this long before the click commits —
     * long enough that a one-frame graze of the hull edge as the target/camera drifts past never misfires.
     * Zero fires on first contact (snappiest, but riskier on a fast-moving target).
     */
    val dwellMs: Long = 60,
    /** ms of homing per pixel of cursor travel → the tracking window; clamped to [minMoveMs]..[maxMoveMs]. */
    val msPerPx: Double = 0.5,
    /** Lower clamp on the homing window (a nearby target still gets a human-plausible move, not a snap). */
    val minMoveMs: Long = 120,
    /** Upper clamp on the homing window (a far target doesn't crawl forever chasing a lock). */
    val maxMoveMs: Long = 500,
)
