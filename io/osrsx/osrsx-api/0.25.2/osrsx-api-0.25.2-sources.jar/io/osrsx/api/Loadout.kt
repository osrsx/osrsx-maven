package io.osrsx.api

/**
 * How to REPLENISH a depleted required item — the `onDeplete → GE-buy` hook. When the bank can't cover a
 * loadout item's shortfall, the engine buys [quantity] of [ref] off the Grand Exchange at [markupPercent]
 * over the live guide price (an "instant" buy that crosses the spread so the offer fills). [ref] is usually
 * the item itself, but can differ (buy a raw material you then process into the target).
 *
 * @since 0.4.0
 */
data class RestockSpec(
    val ref: ItemRef,
    val quantity: Int,
    val markupPercent: Int = 5,
) {
    init {
        require(quantity >= 1) { "restock quantity must be >= 1" }
        require(markupPercent >= 0) { "restock markupPercent must be >= 0" }
    }
}

/**
 * One declarative requirement in a [Loadout] — an [ItemRef] (id / name / [ItemRef.AnyOf] alternates in
 * preferred order — Infernal cape > Fire cape) plus how many to hold and how it must be held.
 *
 * - [quantity] is the target amount to end up with (what a withdraw fills toward).
 * - [minimum] is the threshold the item counts as SATISFIED / not-yet-depleted at (defaults to [quantity]);
 *   held below it makes the loadout unsatisfied and, once the bank is dry, fires a restock.
 * - [equip] demands the item be WORN (the equipment container), not merely carried — the [ItemSpec.equip]
 *   semantics [Container.satisfies] keys on.
 * - [noted] withdraws the item as bank NOTES (a stackable note pile) rather than unnoted stacks.
 * - [optional] items never fire a restock and don't, on their own, make the loadout unsatisfied.
 *
 * @since 0.4.0
 */
data class LoadoutItem(
    val ref: ItemRef,
    val quantity: Int = 1,
    val minimum: Int = quantity,
    val equip: Boolean = false,
    val noted: Boolean = false,
    val optional: Boolean = false,
    val restock: RestockSpec? = null,
) {
    init {
        require(quantity >= 1) { "loadout quantity must be >= 1" }
        require(minimum in 1..quantity) { "loadout minimum must be in 1..quantity" }
        require(!(equip && noted)) { "an equipped item cannot be noted" }
    }

    /** The equivalent [ItemSpec] (drops [minimum]/[noted]) — what [Container.satisfies] takes. */
    val spec: ItemSpec get() = ItemSpec(ref, minimum, equip)
}

/**
 * A declarative target inventory + equipment set — the "what I should be carrying/wearing" that the engine
 * reconciles the live containers toward via synthetic bank interaction (see [Loadouts]). Build one with
 * the [build] DSL:
 *
 * ```
 * val fishing = Loadout.build("Barb fishing") {
 *     equip("Graceful hood"); equip("Graceful top"); equip("Graceful legs")
 *     item("Feather", quantity = 8000, minimum = 500, noted = true) {
 *         restock(quantity = 8000)     // buy more feathers off the GE when the bank runs dry
 *     }
 * }
 * ```
 *
 * @since 0.4.0
 */
class Loadout(val name: String, val items: List<LoadoutItem>) : Iterable<LoadoutItem> {

    /** The must-be-worn requirements. */
    val equipment: List<LoadoutItem> get() = items.filter { it.equip }

    /** The carried (inventory) requirements. */
    val carried: List<LoadoutItem> get() = items.filter { !it.equip }

    override fun iterator(): Iterator<LoadoutItem> = items.iterator()

    companion object {
        /** Build a [Loadout] with the [LoadoutBuilder] DSL. Prefer the top-level [loadout] function. */
        fun build(name: String, block: LoadoutBuilder.() -> Unit): Loadout =
            LoadoutBuilder(name).apply(block).build()
    }
}

/**
 * Build a [Loadout] with the [LoadoutBuilder] DSL — the top-level, idiomatic counterpart to [Loadout.build]
 * (reads like `buildList`):
 *
 * ```
 * val fishing = loadout("Barb fishing") {
 *     equip("Graceful hood"); equip("Graceful top"); equip("Graceful legs")
 *     item("Feather", quantity = 8000, minimum = 500, noted = true) { restock(quantity = 8000) }
 * }
 * ```
 *
 * @since 0.4.0
 */
fun loadout(name: String = "loadout", block: LoadoutBuilder.() -> Unit): Loadout = Loadout.build(name, block)

/**
 * Fluent builder for a [Loadout] (see [loadout] / [Loadout.build]).
 *
 * @since 0.4.0
 */
@OsrsxDsl
class LoadoutBuilder(private val name: String) {
    private val items = mutableListOf<LoadoutItem>()

    /** A carried requirement by [ItemRef] (`ItemRef.AnyOf` for preferred-order alternates). */
    fun item(
        ref: ItemRef,
        quantity: Int = 1,
        minimum: Int = quantity,
        noted: Boolean = false,
        optional: Boolean = false,
        restock: RestockSpec? = null,
    ) {
        items += LoadoutItem(ref, quantity, minimum, equip = false, noted = noted, optional = optional, restock = restock)
    }

    /** A carried requirement by name, with an optional inline restock block. */
    fun item(
        name: String,
        quantity: Int = 1,
        minimum: Int = quantity,
        noted: Boolean = false,
        optional: Boolean = false,
        restock: RestockBuilder.() -> Unit = {},
    ) = item(ItemRef.ByName(name), quantity, minimum, noted, optional, restockOf(ItemRef.ByName(name), quantity, restock))

    /** A carried requirement by item id. */
    fun item(
        id: Int,
        quantity: Int = 1,
        minimum: Int = quantity,
        noted: Boolean = false,
        optional: Boolean = false,
        restock: RestockBuilder.() -> Unit = {},
    ) = item(ItemRef.ById(id), quantity, minimum, noted, optional, restockOf(ItemRef.ById(id), quantity, restock))

    /** A carried requirement satisfied by ANY of [ids], preferred (best-available) first. */
    fun anyOf(vararg ids: Int, quantity: Int = 1, minimum: Int = quantity, optional: Boolean = false) =
        item(ItemRef.AnyOf(ids.toList()), quantity, minimum, noted = false, optional = optional, restock = null)

    /** A must-be-worn requirement by [ItemRef]. */
    fun equip(ref: ItemRef, quantity: Int = 1, optional: Boolean = false, restock: RestockSpec? = null) {
        items += LoadoutItem(ref, quantity, quantity, equip = true, noted = false, optional = optional, restock = restock)
    }

    /** A must-be-worn requirement by name. */
    fun equip(name: String, quantity: Int = 1, optional: Boolean = false) =
        equip(ItemRef.ByName(name), quantity, optional)

    /** A must-be-worn requirement by id. */
    fun equip(id: Int, quantity: Int = 1, optional: Boolean = false) =
        equip(ItemRef.ById(id), quantity, optional)

    // ---- operator sugar ----
    // Scoped to the builder receiver, so these only apply inside a `loadout { … }` block.

    /** `"Feather" * 8000` — a carried requirement, returning an [ItemHandle] to refine it. */
    operator fun String.times(quantity: Int): ItemHandle {
        items += LoadoutItem(ItemRef.ByName(this), quantity)
        return ItemHandle(items.lastIndex)
    }

    /** `+"Tinderbox"` — a single carried requirement (quantity 1). */
    operator fun String.unaryPlus(): ItemHandle {
        items += LoadoutItem(ItemRef.ByName(this))
        return ItemHandle(items.lastIndex)
    }

    /** `"Graceful top".equip()` — a worn requirement, returning an [ItemHandle] to refine it. */
    fun String.equip(quantity: Int = 1): ItemHandle {
        items += LoadoutItem(ItemRef.ByName(this), quantity, quantity, equip = true)
        return ItemHandle(items.lastIndex)
    }

    /**
     * A mutable handle to the requirement just declared via `*` / `+` / [equip], for fluent refinement:
     * `("Feather" * 8000).noted().minimum(500).restock(8000)`. Each call copies the underlying [LoadoutItem]
     * in place (and re-validates it), so an out-of-range refinement throws exactly as the direct API would.
     */
    inner class ItemHandle internal constructor(private val index: Int) {
        private fun edit(f: (LoadoutItem) -> LoadoutItem): ItemHandle {
            items[index] = f(items[index]); return this
        }

        /** Withdraw as bank notes. */
        fun noted() = edit { it.copy(noted = true) }

        /** The count this item stays SATISFIED at (below it fires a restock once the bank is dry). */
        fun minimum(n: Int) = edit { it.copy(minimum = n) }

        /** Never fires a restock / never makes the loadout unsatisfied on its own. */
        fun optional() = edit { it.copy(optional = true) }

        /** Require it WORN rather than merely carried. */
        fun equip() = edit { it.copy(equip = true, noted = false) }

        /** Enable a GE restock for this item (defaults to buying back up to its own quantity). */
        fun restock(quantity: Int = items[index].quantity, markupPercent: Int = 5) =
            edit { it.copy(restock = RestockSpec(it.ref, quantity, markupPercent)) }
    }

    fun build(): Loadout = Loadout(name, items.toList())

    private fun restockOf(ref: ItemRef, quantity: Int, block: RestockBuilder.() -> Unit): RestockSpec? =
        RestockBuilder(ref, quantity).apply(block).buildOrNull()
}

/**
 * Inline builder for an item's [RestockSpec]; produces null unless [restock] is set.
 *
 * @since 0.4.0
 */
@OsrsxDsl
class RestockBuilder(private val defaultRef: ItemRef, private val defaultQuantity: Int) {
    private var enabled = false
    private var ref: ItemRef = defaultRef
    private var quantity: Int = defaultQuantity
    private var markupPercent: Int = 5

    /** Enable GE restock, optionally overriding what/how-many/how-much to buy. */
    fun restock(ref: ItemRef = defaultRef, quantity: Int = defaultQuantity, markupPercent: Int = 5) {
        this.enabled = true
        this.ref = ref
        this.quantity = quantity
        this.markupPercent = markupPercent
    }

    fun buildOrNull(): RestockSpec? = if (enabled) RestockSpec(ref, quantity, markupPercent) else null
}
