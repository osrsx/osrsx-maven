package io.osrsx.api

/**
 * Configurable **click-placement policy** — where inside a target's clickbox a synthetic click lands. osrsx
 * already samples the clickbox richly (centre-biased Gaussian, lower-model-biased, uniform); this is that
 * choice surfaced as a policy authors can pick, for the SYNTHETIC cursor.
 *
 * There is deliberately no "NONE" mode — a synthetic click always physically moves and clicks.
 *
 * @since 0.4.0
 */
enum class ClickPlacement {
    /** 2D Gaussian biased toward the clickbox centre with edge-avoidance — the sane default. */
    GAUSSIAN_CENTRE,

    /** Biased toward the lower portion of the model (its ground footprint) — good for tall world objects. */
    LOWER_BIASED,

    /** Flat over the whole shape — good for walking tile clicks where any spot is plausible. */
    UNIFORM,
}

/**
 * Tunable knobs for click placement. [sigmaFraction] is the Gaussian std as a fraction of each clickbox
 * dimension (used by [ClickPlacement.GAUSSIAN_CENTRE]); [edgeMarginFraction] is the outer band (as a
 * fraction of the bounds) the sampler avoids so a click never lands right on the clickable edge. Defaults
 * are sane; set a plugin's policy via [Humanizers.setClickConfig].
 *
 * @since 0.4.0
 */
data class ClickConfig(
    val placement: ClickPlacement = ClickPlacement.GAUSSIAN_CENTRE,
    val sigmaFraction: Double = 0.25,
    val edgeMarginFraction: Double = 0.06,
)
