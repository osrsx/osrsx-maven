package io.osrsx.api

/**
 * Dynamic menu-entry swapping — make a chosen right-click [action] the DEFAULT left-click for matching
 * entries (e.g. set "Drop" as the default for a log so a single left-click drops it, instead of a
 * right-click + "Drop" select).
 *
 * It only reorders the live menu's PRIORITY (on the fork's `PostMenuSort`); the action that actually
 * fires when clicked is the real one the client built — nothing is injected or fabricated. Rules stay
 * active until [remove]d or [reset]; a plugin should clear its rules when it stops.
 */
interface Menu {
    /**
     * Make [action] the default left-click for entries whose target contains [target] (case-insensitive;
     * null matches any target). [action] also matches dynamic ops like "Pay-toll(10gp)" via the prefix.
     * Returns a rule id for [remove].
     */
    fun setDefault(action: String, target: String? = null): Int

    /** Remove a single swap rule by its [id]. */
    fun remove(id: Int)

    /** Clear every swap rule (restores vanilla left-click defaults). */
    fun reset()

    /**
     * What the game would act on with a plain left-click RIGHT NOW — i.e. the top (default) live menu
     * entry: its world [HoverTarget.tile] (from the entry's scene coords, for object/ground targets),
     * numeric [HoverTarget.id] (object/NPC/item id) and [HoverTarget.name]. Null when there's no live
     * client or no entry. Use it to VERIFY the cursor is over the intended target before clicking — e.g.
     * two same-named objects can share a screen clickbox, so check the tile matches the one you meant.
     */
    fun hoveredTarget(): HoverTarget? = null
}

/** The target under the cursor (the top live menu entry): its world [tile] (null when the action has no
 *  scene location), numeric [id] (object/NPC/item id, or 0) and display [name] (tags stripped, or null). */
data class HoverTarget(val tile: Tile?, val id: Int, val name: String?)
