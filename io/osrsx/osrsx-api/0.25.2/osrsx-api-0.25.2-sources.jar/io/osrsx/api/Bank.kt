package io.osrsx.api


/**
 * The bank: container reads plus open/withdraw/deposit interaction.
 *
 * **Reads work anywhere.** The inherited [Container] reads ([items]/[getItem]/[contains]/[count]/…) serve
 * the LIVE open bank when it's open, and transparently fall back to the persisted per-account [BankCache]
 * snapshot when it's closed — so "what's in my bank?" is answerable across the map through this one surface,
 * with no separate [BankCache] call. The snapshot is auto-captured while the bank is open (and once more just
 * before it closes). Interaction ([withdraw]/[deposit]/…) still requires the bank open; the cached stacks
 * answer reads only. The engine keeps that snapshot trustworthy for you (an automatic once-per-login sync
 * when needed), so this is the single bank surface — there is no separate cache for plugins to consult.
 */
interface Bank : Container {
    fun isOpen(): Boolean
    fun open(): Boolean

    /**
     * Walk to the nearest bank you can ACTUALLY reach (via the web walker) and open it. Loop-driven: call
     * each loop until it returns true (bank open). Unlike [open] — which only opens a bank already in the
     * loaded scene — this navigates there first, using reachability-aware selection ([WebWalker.nearestBank])
     * so it won't get stuck routing to a wall-mounted booth it can't bank across (e.g. the Cooks' Guild from
     * outside its gate). Falls back to opening an in-scene bank if the walker isn't available.
     */
    fun openNearest(): Boolean
    fun close(): Boolean
    fun withdraw(name: String, amount: Int): Boolean
    fun withdraw(id: Int, amount: Int, target: String? = null): Boolean
    /** Withdraw [amount] (<=0 = All) of [name] as NOTES ([noted] true) or items — collapses an unstackable
     *  pile into one stack (e.g. so a whole leather lot sells in a single GE offer). Toggles mode only if needed. */
    fun withdraw(name: String, amount: Int, noted: Boolean): Boolean
    /** Deposit [amount] of [name] from the inventory into the open bank. [amount] `<= 0` means ALL —
     *  the same sentinel [withdraw] uses (0 = All) — which fires the "Deposit-All" menu action rather than
     *  typing a quantity. See [depositAll] for the explicit convenience. */
    fun deposit(name: String, amount: Int): Boolean

    /** Deposit ALL of [name] from the inventory (the "Deposit-All" action). Convenience for
     *  `deposit(name, 0)`, mirroring `withdraw(name, 0)`. */
    fun depositAll(name: String): Boolean = deposit(name, 0)

    // ---- withdraw quantity mode (@since 0.11.8) ----
    // The bank's own 1/5/10/X/All quantity selector decides what a plain LEFT-CLICK on an item withdraws.
    // Setting it once turns each subsequent withdraw into a single left-click (no right-click + select), and
    // [withdraw] left-clicks automatically when the active mode already yields the requested amount.

    /**
     * Set the bank's custom "X" amount to [amount] and select X as the active quantity mode (right-clicks the
     * X button → "Set custom quantity" and types it, only when it isn't already [amount]). After this a plain
     * item left-click — e.g. `withdraw(name, amount)` — withdraws exactly [amount].
     * @since 0.11.8 — transitional default; the engine overrides it in osrsx-core.
     */
    fun setWithdrawQuantityX(amount: Int): Boolean = false

    /**
     * Select the "All" quantity mode, so a plain item left-click (`withdraw(name, 0)`) takes the whole stack.
     * @since 0.11.8 — transitional default; the engine overrides it in osrsx-core.
     */
    fun setWithdrawQuantityAll(): Boolean = false

    /**
     * Select the "1" quantity mode — the vanilla default — clearing an earlier [setWithdrawQuantityX]/[All] so
     * plain left-clicks withdraw a single item again.
     * @since 0.11.8 — transitional default; the engine overrides it in osrsx-core.
     */
    fun setWithdrawQuantity1(): Boolean = false
    fun depositInventory(): Boolean
    fun depositEquipment(): Boolean

    /** True while the bank is in Insert rearrange mode (a drag shifts items rather than swapping). */
    fun isInsertMode(): Boolean
    /** Put the bank into Insert (true) or Swap (false) rearrange mode; toggles only if needed. */
    fun setInsertMode(insert: Boolean): Boolean
    /** The bank tab currently shown (0 = "View all items"). */
    fun viewedTab(): Int
    /** Switch to "View all items" — required before moving items by global slot (a tab view shows a subset). */
    fun viewAllItems(): Boolean
    /** Number of items in bank [tab] (1..9). In the all view, tabs occupy the leading slots in tab order,
     *  so these counts give each tab's slot range (and thus which tab any item is in). */
    fun tabSize(tab: Int): Int

    /** The on-screen widget currently holding item [id] (located by item id, never a slot index), or null
     *  if it isn't in the bank. Drag THIS — it's always the right item regardless of scroll position. */
    fun itemWidget(id: Int): Widget?
    /** True when item [id]'s widget centre lies inside the visible bank viewport (not scrolled out). */
    fun isItemVisible(id: Int): Boolean
    /** Deterministically scroll item [id] to the viewport centre by dragging the scrollbar thumb (content-
     *  space math — no wheel heuristics). Returns true only once the item is genuinely visible, so a caller
     *  can drag it without ever grabbing empty space or the wrong row. */
    fun bringItemIntoView(id: Int): Boolean

    // ---- valuation (@since 0.4.0) ----

    /**
     * Total live GE value (gp) of the whole bank — coins/platinum tokens at face value, everything else at
     * `unitPrice × quantity`. Reads the current bank snapshot; 0 when no contents/prices are known.
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun value(): Long = 0L

    /**
     * The [n] most-valuable stacks in the bank (highest first) by live GE value — the "what's worth the most
     * in here?" answer for a dashboard/overlay.
     *
     * @since 0.4.0 — transitional default; the engine overrides it in osrsx-core.
     */
    fun topValue(n: Int): List<ValuedStack> = emptyList()
}
