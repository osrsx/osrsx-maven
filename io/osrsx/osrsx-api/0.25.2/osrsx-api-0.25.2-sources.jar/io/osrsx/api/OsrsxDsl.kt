package io.osrsx.api

/**
 * [DslMarker] for every osrsx type-safe builder (the Script DSL's `ScriptScope`, the loadout
 * `LoadoutBuilder`/`RestockBuilder`, …). It makes nested builder lambdas *scope-safe*: inside an inner
 * builder block you can only call the innermost receiver's members, so an outer builder's methods can't be
 * invoked by accident (the compiler rejects it rather than silently retargeting). Purely a compile-time aid
 * — it changes no runtime behaviour.
 *
 * @since 0.4.0
 */
@DslMarker
@Target(AnnotationTarget.CLASS, AnnotationTarget.TYPE)
@Retention(AnnotationRetention.BINARY)
annotation class OsrsxDsl
