package io.osrsx.api

/**
 * The in-game world map — read its open state and the tile under the cursor, and contribute right-click
 * actions to it. A clean wrapper over what would otherwise need privileged client access (widget projection
 * + menu-entry injection), so a plugin can offer "walk here from the map" without reaching into the engine.
 */
interface WorldMap {
    /** Whether the world map is currently open (its view is shown). */
    fun isOpen(): Boolean

    /** The world [Tile] under the cursor on the map right now (plane = the player's), or null when the map is
     *  closed or the cursor isn't over it. */
    fun tileUnderCursor(): Tile?

    /**
     * Add a right-click menu [option] to the world map. Whenever the map's context menu opens over a tile,
     * the entry is added; clicking it invokes [handler] with that [Tile]. Returns a [Subscription] — call
     * [Subscription.unsubscribe] (e.g. in `onStop`) to remove it. Multiple plugins may add their own options.
     */
    fun addMenuOption(option: String, handler: (Tile) -> Unit): Subscription
}
