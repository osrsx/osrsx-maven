package io.osrsx.api

/**
 * A persisted, per-account snapshot of the player's bank — so "what's in my bank?" is answerable
 * anywhere on the map, not just while standing at an open bank. The snapshot is captured automatically
 * whenever the bank is open and its contents change (no caller effort), persisted via [DataStore] under
 * the account's `user.home`, and reloaded on the next session.
 *
 * **Engine-internal — plugins do not access this directly.** The engine pipes it through the [Bank] read
 * API (open bank → live, closed bank → this snapshot) and keeps it trustworthy via an automatic once-per-
 * login sync, so plugins just call [Bank] everywhere. This interface is the implementation contract between
 * the SDK and the engine, not a plugin-facing surface.
 *
 * Reads ([items]/[contains]/[count]/[coins]) reflect the most recent snapshot — possibly stale. Use
 * [capturedAt]/[ageMs]/[isStale] to judge freshness, and [ensureFresh] to walk to a bank and refresh.
 */
interface BankCache {
    /** The last-known bank contents; empty if nothing has ever been captured for this account. */
    fun items(): List<CachedItem>

    fun contains(id: Int): Boolean
    fun contains(name: String): Boolean
    /** Quantity of [id] in the snapshot (0 if absent). */
    fun count(id: Int): Int
    /** Total quantity matching [name] (case-insensitive) in the snapshot (0 if absent). */
    fun count(name: String): Int
    /** Coins (item 995) in the snapshot. */
    fun coins(): Int

    /** Epoch-millis the snapshot was captured, or 0 if there is none. */
    fun capturedAt(): Long
    /** Milliseconds since the snapshot was captured, or [Long.MAX_VALUE] if there is none. */
    fun ageMs(): Long
    /** True if there's no snapshot or it's older than [maxAgeMs]. */
    fun isStale(maxAgeMs: Long): Boolean
    /** True if no snapshot has been captured (or it captured an empty bank). */
    fun isEmpty(): Boolean

    /**
     * Whether the snapshot can be TRUSTED as accurate for the current login. True when the live bank has been
     * opened/captured this session, OR when the engine's total-playtime check proves the account wasn't played
     * outside this client since the snapshot was taken (so its contents can't have changed) — this lets a
     * cross-session snapshot be trusted at startup with no forced bank open. It stays false (until a real bank
     * open re-syncs) when the account WAS played elsewhere, when there's no snapshot yet, or before the
     * once-per-session check has resolved. Reset on logout/world-hop. Code driving real actions should confirm
     * first — [ensureFresh] re-opens the bank only when it isn't already trusted.
     */
    fun isConfirmed(): Boolean

    /** Capture the live bank into the cache right now. No-op returning false unless the bank is open. */
    fun snapshot(): Boolean

    /**
     * Bring the cache up to date by walking to the nearest reachable bank and opening it (the snapshot
     * then happens automatically). Loop-driven like the web walker: call every loop — it returns true
     * once the cache is trusted (bank reached + captured, or already [isConfirmed]), false while still
     * travelling/opening. If the bank is already open it just snapshots. Returns true immediately when the
     * snapshot is already trusted for this login — including a cross-session snapshot the playtime check has
     * validated — so it forces a real bank visit ONLY when the account was played elsewhere (or nothing is
     * cached yet), not on every startup.
     */
    fun ensureFresh(): Boolean
    /** As [ensureFresh]; [maxAgeMs] is retained for source compatibility but wall-clock age no longer forces a
     *  walk once the snapshot is [isConfirmed] (bank contents change only through play, which is tracked). */
    fun ensureFresh(maxAgeMs: Long): Boolean
}

/** One item in a [BankCache] snapshot. [name] is resolved from [id] via the item cache. */
data class CachedItem(val id: Int, val name: String, val quantity: Int)
