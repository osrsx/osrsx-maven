package io.osrsx.script

/**
 * Thrown by a script action/verb that definitively failed after its own internal blocking/retrying —
 * the failure currency of the verb layer ([io.osrsx.script.harvest], [io.osrsx.script.craftMake], and
 * the quest actions, whose `QuestActionFailed` extends this). A stage driver (the quest driver,
 * [io.osrsx.script.staged.StagedScript]) catches THIS to abort the stage pass and re-run/route it,
 * rather than letting the body fall through to actions that depended on the failed one's outcome.
 *
 * @since 0.25.0
 */
open class ScriptActionFailed(message: String) : RuntimeException(message)
