package io.osrsx.script.staged

import io.osrsx.api.OsrsxDsl
import io.osrsx.script.Script
import io.osrsx.script.ScriptActionFailed
import io.osrsx.script.ScriptScope
import io.osrsx.script.script

/**
 * A **staged script**: the quest driver's proven loop — read state, run the first stage that matches,
 * re-run it (idempotent) until the state moves on — generalized from "one progress varbit" to an
 * arbitrary state snapshot [S]. Where a quest's stage selector is `v in stage.varValues` over a single
 * var read, a staged script reads any state it likes (varbits + region + inventory + scene) and each
 * [Stage] matches it with a predicate. Cyclic content (a minigame loop, a boss farm) is expressed by an
 * [isComplete] that only fires on an external stop condition — the driver otherwise loops forever.
 *
 * The stage contract is UNCHANGED from quests: a stage body is an ordered list of **idempotent** actions
 * that observe their own completion; the driver re-runs the matching stage until the state selects a
 * different one. A body that throws [ScriptActionFailed] aborts the pass and is routed to
 * [onStageFailed] (default: log + a 2 s beat + re-run) — never allowed to fall through to later actions.
 *
 * ```
 * stagedScript<GauntletState>("gauntlet") {
 *     readState { readGauntletState() }
 *     isComplete { it.runsDone >= config.runs }
 *     stage("recover", { it.justDied })   { deathRecovery() }
 *     stage("travel",  { !it.inRaid })    { walkTo(LOBBY) }
 *     stage("prep",    { it.inRaid })     { prepPlanner.oneObjective() }
 * }.toScript()
 * ```
 *
 * Build with [stagedScript]; run via [io.osrsx.script.ScriptDslPlugin] like any [Script].
 *
 * @since 0.25.0
 */
class StagedScript<S> internal constructor(
    val name: String,
    private val readState: ScriptScope.() -> S,
    private val isComplete: ScriptScope.(S) -> Boolean,
    private val shouldProvision: (ScriptScope.(S) -> Boolean)?,
    private val provision: (suspend ScriptScope.() -> Unit)?,
    private val beforeEach: (suspend ScriptScope.() -> Unit)?,
    private val stages: List<Stage<S>>,
    private val onUnmatched: suspend ScriptScope.(S) -> Unit,
    private val dialoguePump: (S) -> Boolean,
    private val onStageFailed: suspend ScriptScope.(Stage<S>, ScriptActionFailed) -> Unit,
) {

    /** Compile to a runnable [Script] — one cooperative coroutine on the existing runner. */
    fun toScript(): Script = script(name) { drive() }

    private suspend fun ScriptScope.drive() {
        while (!isStopping) {
            var s = readState()
            // Clear stray continue-only chat (a greeting/objectbox that fired from an interaction) before
            // acting — but only where the script says it's safe: never inside a reaction-critical state.
            if (dialoguePump(s) && pumpIncidentalDialogue()) s = readState()
            if (isComplete(s)) { status("$name — complete ✓"); return }

            if (provision != null && shouldProvision?.invoke(this, s) == true) {
                status("$name — provisioning")
                provision.invoke(this)
                park(600)
                continue
            }

            // FIRST matching stage wins — order the list so guards (death recovery, relogin) come first.
            val stage = stages.firstOrNull { it.matches(s) }
            if (stage == null) { onUnmatched(s); continue }

            status("$name — ${stage.label}")
            try {
                beforeEach?.invoke(this)
                stage.body(this)
                yieldTick() // re-read the state; a different stage matches once this one's work shows
            } catch (e: ScriptActionFailed) {
                onStageFailed(stage, e)
            }
        }
    }

    /** See [io.osrsx.quest] — auto-advance ONLY continue-prompts; options are always a stage's decision. */
    private suspend fun ScriptScope.pumpIncidentalDialogue(): Boolean {
        var advanced = false
        var guard = 0
        while (dialogues.inDialogue() && dialogues.getOptions().isEmpty() && !isStopping && guard++ < 15) {
            if (!dialogues.continueAuto()) break
            advanced = true
            park(650)
        }
        return advanced
    }
}

/** One stage: run [body] while [matches] selects it. [label] is surfaced as the script status. */
class Stage<S> internal constructor(
    val label: String,
    val matches: (S) -> Boolean,
    val body: suspend ScriptScope.() -> Unit,
)

/**
 * Author a [StagedScript]. [readState] and [isComplete] are required; stages are matched in
 * declaration order (put guard stages — death recovery, session repair — first).
 *
 * @since 0.25.0
 */
fun <S> stagedScript(name: String, block: StagedScriptBuilder<S>.() -> Unit): StagedScript<S> =
    StagedScriptBuilder<S>(name).apply(block).build()

@OsrsxDsl
class StagedScriptBuilder<S> internal constructor(private val name: String) {
    private var readState: (ScriptScope.() -> S)? = null
    private var isComplete: (ScriptScope.(S) -> Boolean)? = null
    private var shouldProvision: (ScriptScope.(S) -> Boolean)? = null
    private var provision: (suspend ScriptScope.() -> Unit)? = null
    private var beforeEach: (suspend ScriptScope.() -> Unit)? = null
    private var onUnmatched: suspend ScriptScope.(S) -> Unit = { sleep(1_200) }
    private var dialoguePump: (S) -> Boolean = { true }
    private var onStageFailed: suspend ScriptScope.(Stage<S>, ScriptActionFailed) -> Unit = { stage, e ->
        log.w("'${this@StagedScriptBuilder.name}' [${stage.label}]: ${e.message} — re-running the stage")
        sleep(2_000)
    }
    private val stages = mutableListOf<Stage<S>>()

    /** How the script observes the world — build the full state snapshot the stages match on. */
    fun readState(fn: ScriptScope.() -> S) { readState = fn }

    /** When the script is DONE (the driver returns). For cyclic content, the external stop condition. */
    fun isComplete(fn: ScriptScope.(S) -> Boolean) { isComplete = fn }

    /** Run [body] (then re-read state) whenever [gate] is true — declarative provisioning. Cyclic scripts
     *  that re-provision every loop can also just model provisioning as an ordinary [stage]. */
    fun provision(gate: ScriptScope.(S) -> Boolean, body: suspend ScriptScope.() -> Unit) {
        shouldProvision = gate
        provision = body
    }

    /** Run before EVERY stage pass — cheap, idempotent cross-stage guards only. */
    fun beforeEach(body: suspend ScriptScope.() -> Unit) { beforeEach = body }

    /** Run when NO stage matches the state (default: a 1.2 s beat). */
    fun onUnmatched(body: suspend ScriptScope.(S) -> Unit) { onUnmatched = body }

    /** Whether the driver may auto-advance incidental continue-only dialogue in this state. Default: always.
     *  Return false for reaction-critical states (a boss room) where nothing should touch the game between
     *  stage passes. */
    fun dialoguePump(fn: (S) -> Boolean) { dialoguePump = fn }

    /** Route a stage body's [ScriptActionFailed] (default: log + 2 s + re-run). A boss stage's handler
     *  routes to death recovery instead of a blind retry. */
    fun onStageFailed(fn: suspend ScriptScope.(Stage<S>, ScriptActionFailed) -> Unit) { onStageFailed = fn }

    /** Declare a stage. FIRST match (in declaration order) wins each pass. */
    fun stage(label: String, matches: (S) -> Boolean, body: suspend ScriptScope.() -> Unit) {
        stages += Stage(label, matches, body)
    }

    internal fun build(): StagedScript<S> {
        val read = requireNotNull(readState) { "stagedScript('$name'): readState { } is required" }
        val complete = requireNotNull(isComplete) { "stagedScript('$name'): isComplete { } is required" }
        require(stages.isNotEmpty()) { "stagedScript('$name'): at least one stage { } is required" }
        return StagedScript(
            name, read, complete, shouldProvision, provision, beforeEach,
            stages.toList(), onUnmatched, dialoguePump, onStageFailed,
        )
    }
}
