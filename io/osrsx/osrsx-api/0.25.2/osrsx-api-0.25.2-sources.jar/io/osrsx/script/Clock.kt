package io.osrsx.script

/**
 * The time source a [ScriptRunner] measures cooperative waits against. Abstracted so the step machine's
 * waits ([ScriptScope.sleep] / [ScriptScope.waitUntil]) are deterministically testable with a fake clock
 * (advance time by hand, drive [ScriptRunner.tick], assert progression) — no `Thread.sleep`, no live client.
 *
 * @since 0.4.0
 */
fun interface Clock {
    fun nowMs(): Long
}

/** Wall-clock time — the production [Clock]. @since 0.4.0 */
object SystemClock : Clock {
    override fun nowMs(): Long = System.currentTimeMillis()
}
