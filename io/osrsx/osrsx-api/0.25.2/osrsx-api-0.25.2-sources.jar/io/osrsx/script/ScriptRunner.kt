package io.osrsx.script

import io.osrsx.api.PluginApi
import io.osrsx.api.PluginContext
import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.createCoroutine
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED
import kotlin.coroutines.intrinsics.suspendCoroutineUninterceptedOrReturn
import kotlin.coroutines.resume

/**
 * The cooperative step machine that runs a [Script] one burst at a time. Uses Kotlin's `suspend` mechanism
 * — from `kotlin-stdlib`'s `kotlin.coroutines` (NOT the `kotlinx.coroutines` library, which is not on the
 * classpath, so nothing is added to the build): the script body is a suspend lambda whose waits suspend at a
 * [ScriptScope.park] and resume later, giving true coroutine-style cooperative scheduling with no
 * hand-rolled step-index VM.
 *
 * Drive it with [tick]: each call resumes the script only if its pending wait is due, runs it synchronously
 * up to the next wait (a "step burst"), and returns the ms until it should be ticked again — or [DONE] when
 * the script has finished. This is a plain single-threaded object: [tick] and the resumed body run on the
 * same (loop) thread, so there is no locking. A [ScriptDslPlugin] pumps it from `onLoop`, honouring that
 * returned delay so the thread idles between waits instead of busy-blocking.
 *
 * @since 0.4.0
 */
class ScriptRunner(
    private val script: Script,
    private val host: PluginApi,
    private val clock: Clock = SystemClock,
    private val stopping: () -> Boolean = { false },
) : ScriptScope {

    /** [tick] return value meaning "the script has completed (or crashed) — stop pumping it". */
    companion object {
        const val DONE = -1L
    }

    /** [PluginApi]'s only abstract member; every unprefixed accessor (`bank`, …) delegates through it. */
    override val ctx: PluginContext get() = host.ctx

    private var started = false
    private var parked: Continuation<Unit>? = null
    private var resumeAt = 0L
    private var done = false
    private var failure: Throwable? = null

    /** True once the body has returned or thrown (a clean stop counts as done, with no [error]). */
    val isDone: Boolean get() = done

    /** The uncaught exception that ended the script, or null (a clean [ScriptStopped] never surfaces here). */
    val error: Throwable? get() = failure

    @Volatile private var _status: String = ""

    /** The script's last-reported activity (via [ScriptScope.status]); read from the render thread for panels. */
    override val status: String get() = _status
    override fun status(text: String) { _status = text }

    override val isStopping: Boolean get() = stopping()
    override fun nowMs(): Long = clock.nowMs()

    override suspend fun park(delayMs: Long): Unit =
        suspendCoroutineUninterceptedOrReturn { cont ->
            resumeAt = clock.nowMs() + delayMs.coerceAtLeast(0)
            parked = cont
            COROUTINE_SUSPENDED
        }

    /**
     * Advance the script: start it (first call) or resume its due wait, then run to the next wait. Returns
     * the ms until the next [tick] should happen, or [DONE] once the script has finished. A no-op returning
     * [DONE] after completion.
     */
    fun tick(): Long {
        if (done) return DONE
        val cont = parked
        if (cont == null) {
            if (!started) start()
            return sinceResume()
        }
        val remaining = resumeAt - clock.nowMs()
        if (remaining > 0) return remaining
        parked = null
        resume(cont)
        return sinceResume()
    }

    private fun start() {
        started = true
        val completion = Continuation<Unit>(EmptyCoroutineContext) { result ->
            done = true
            parked = null
            result.exceptionOrNull()?.let { if (it !is ScriptStopped) failure = it }
        }
        resume(script.body.createCoroutine(this, completion))
    }

    /** Run the coroutine until it parks again or completes; never lets a body throwable escape [tick]. */
    private fun resume(cont: Continuation<Unit>) {
        try {
            cont.resume(Unit)
        } catch (t: Throwable) {
            // The completion handler records a body exception; anything escaping resume itself is fatal state.
            done = true
            if (t !is ScriptStopped) failure = t
        }
    }

    private fun sinceResume(): Long {
        if (done) return DONE
        return (resumeAt - clock.nowMs()).coerceAtLeast(0)
    }
}
