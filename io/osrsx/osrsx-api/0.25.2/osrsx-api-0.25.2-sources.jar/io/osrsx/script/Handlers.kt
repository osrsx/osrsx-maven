package io.osrsx.script

import kotlin.time.Duration

/**
 * Reusable handler builders on top of the Script DSL: thin, composable suspend steps for the flows every
 * bot repeats — banking, dialogue, Grand Exchange. Each is a cooperative wait around the existing method
 * APIs (`bank`, `dialogues`, `grandExchange`, …), so they read the same "kick the action, wait for the
 * resulting state" pattern and never busy-block. Compose them freely, or drop down to the raw waits for
 * anything bespoke.
 *
 * The default poll/timeout bands suit typical latency; override per call where a flow is slower.
 *
 * @since 0.4.0
 */

// ---- banking ----

/**
 * Ensure the bank is open, walking to the nearest reachable bank if needed. Returns true once open.
 * `bank.openNearest()` is loop-driven (returns true when the bank is open), so a wait around it both walks
 * and opens.
 */
suspend fun ScriptScope.openBank(timeoutMs: Long = 20_000): Boolean =
    bank.isOpen() || waitUntil(timeoutMs, pollMs = 700) { bank.openNearest() }

/** Deposit the whole inventory into the open bank; returns true once it is empty. No-op (true) if already empty. */
suspend fun ScriptScope.depositInventory(timeoutMs: Long = 3_000): Boolean {
    if (!bank.isOpen()) return false
    if (inventory.isEmpty()) return true
    bank.depositInventory()
    return waitUntil(timeoutMs, pollMs = 100) { inventory.isEmpty() }
}

/** Deposit all of [name] from the inventory; returns true once none remain. */
suspend fun ScriptScope.depositAll(name: String, timeoutMs: Long = 3_000): Boolean {
    if (!bank.isOpen()) return false
    if (name !in inventory) return true
    bank.depositAll(name)
    return waitUntil(timeoutMs, pollMs = 100) { name !in inventory }
}

/**
 * Withdraw [amount] of [name] ([amount] `<= 0` = All) from the open bank; returns true once the inventory
 * count has risen (or, for All, once the bank no longer holds it).
 */
suspend fun ScriptScope.withdrawItem(name: String, amount: Int, timeoutMs: Long = 3_000): Boolean {
    if (!bank.isOpen()) return false
    val before = inventory.count(name)
    if (!bank.withdraw(name, amount)) return false
    return waitUntil(timeoutMs, pollMs = 100) { inventory.count(name) > before }
}

// ---- dialogue ----

/**
 * Drive an NPC/player dialogue to its end: advance each continue prompt / confirmation until no dialogue is
 * up. Returns true once out of dialogue, false on timeout.
 */
suspend fun ScriptScope.completeDialogue(timeoutMs: Long = 10_000): Boolean {
    val deadline = nowMs() + timeoutMs
    while (nowMs() < deadline) {
        checkStop()
        if (!dialogues.inDialogue()) return true
        dialogues.advance()
        park(600)
    }
    return !dialogues.inDialogue()
}

/** Pick the dialogue option whose text is [text]; returns true once chosen, false on timeout. */
suspend fun ScriptScope.selectOption(text: String, timeoutMs: Long = 5_000): Boolean =
    waitUntil(timeoutMs, pollMs = 200) { dialogues.chooseOption(text) }

/** Pick the dialogue option at [index]; returns true once chosen, false on timeout. */
suspend fun ScriptScope.selectOption(index: Int, timeoutMs: Long = 5_000): Boolean =
    waitUntil(timeoutMs, pollMs = 200) { dialogues.chooseOption(index) }

// ---- grand exchange ----

/** Ensure the Grand Exchange is open, walking to the nearest clerk if needed. Returns true once open. */
suspend fun ScriptScope.openGrandExchange(timeoutMs: Long = 20_000): Boolean =
    grandExchange.isOpen() || waitUntil(timeoutMs, pollMs = 700) { grandExchange.openNearest() }

/** Place a buy offer for [quantity] of [name] at the live market price. Returns false if the GE isn't open. */
suspend fun ScriptScope.buyAtMarket(name: String, quantity: Int): Boolean {
    if (!grandExchange.isOpen()) return false
    return grandExchange.buyAtMarket(name, quantity)
}

/** Place a sell offer for [quantity] of [name] at the live market price. Returns false if the GE isn't open. */
suspend fun ScriptScope.sellAtMarket(name: String, quantity: Int): Boolean {
    if (!grandExchange.isOpen()) return false
    return grandExchange.sellAtMarket(name, quantity)
}

/** Wait until every in-progress GE offer has completed, then collect the proceeds. Returns the collect result. */
suspend fun ScriptScope.collectWhenDone(toBank: Boolean = false, timeoutMs: Long = 120_000): Boolean {
    if (!grandExchange.isOpen()) return false
    waitUntil(timeoutMs, pollMs = 1_000) { grandExchange.offers().none { it.inProgress() } }
    if (!grandExchange.isReadyToCollect()) return true
    return if (toBank) grandExchange.collectToBank() else grandExchange.collectToInventory()
}

// ---- kotlin.time.Duration overloads ----
// Idiomatic-time counterparts: openBank(20.seconds) instead of openBank(20_000). Each delegates to the ms form.

suspend fun ScriptScope.openBank(timeout: Duration): Boolean = openBank(timeout.inWholeMilliseconds)

suspend fun ScriptScope.depositInventory(timeout: Duration): Boolean = depositInventory(timeout.inWholeMilliseconds)

suspend fun ScriptScope.depositAll(name: String, timeout: Duration): Boolean =
    depositAll(name, timeout.inWholeMilliseconds)

suspend fun ScriptScope.withdrawItem(name: String, amount: Int, timeout: Duration): Boolean =
    withdrawItem(name, amount, timeout.inWholeMilliseconds)

suspend fun ScriptScope.completeDialogue(timeout: Duration): Boolean = completeDialogue(timeout.inWholeMilliseconds)

suspend fun ScriptScope.selectOption(text: String, timeout: Duration): Boolean =
    selectOption(text, timeout.inWholeMilliseconds)

suspend fun ScriptScope.selectOption(index: Int, timeout: Duration): Boolean =
    selectOption(index, timeout.inWholeMilliseconds)

suspend fun ScriptScope.openGrandExchange(timeout: Duration): Boolean = openGrandExchange(timeout.inWholeMilliseconds)

suspend fun ScriptScope.collectWhenDone(toBank: Boolean = false, timeout: Duration): Boolean =
    collectWhenDone(toBank, timeout.inWholeMilliseconds)
