package io.osrsx.script

import io.osrsx.plugin.Gfx2D
import io.osrsx.plugin.HasPanel
import io.osrsx.plugin.Plugin

/**
 * A [Plugin] authored with the Script DSL: override [script] and write the bot as a linear suspend body.
 * The base pumps a [ScriptRunner] from [onLoop] — each loop advances the script to its next cooperative
 * wait and returns that wait as the loop delay, so the per-plugin loop thread idles between waits instead
 * of busy-blocking. This is the coroutine counterpart of the SDK's thread-per-script
 * [io.osrsx.plugin.ScriptPlugin]; it needs no extra thread — the script runs on the existing loop thread.
 *
 * ```
 * @PluginDescriptor(name = "Banker", …)
 * class Banker : ScriptDslPlugin() {
 *     override fun script() = script("banker") {
 *         openBank()
 *         depositInventory()
 *         withdrawItem("Lobster", 20)
 *     }
 * }
 * ```
 *
 * @since 0.4.0
 */
abstract class ScriptDslPlugin : Plugin(), HasPanel {

    /** The runner's clock; override for tests. Defaults to wall-clock time. */
    protected open val clock: Clock get() = SystemClock

    @Volatile private var runner: ScriptRunner? = null
    @Volatile private var active: Script? = null
    @Volatile private var stopping = false

    /** Build this plugin's script. Called once per [onStart]. */
    abstract fun script(): Script

    /** True once the plugin is stopping — mirrored into the running script so its waits unwind. */
    protected val isStopping: Boolean get() = stopping

    /** Optional setup/teardown around the script. */
    open fun onScriptStart() {}
    open fun onScriptStop() {}

    final override fun onStart() {
        stopping = false
        onScriptStart()
        val built = script()
        active = built
        runner = ScriptRunner(built, this, clock) { stopping }
    }

    final override fun onStop() {
        stopping = true
        runner = null
        active = null
        onScriptStop()
    }

    final override fun onLoop(): Long {
        if (stopping) return NO_LOOP
        val current = runner ?: return NO_LOOP
        val delay = current.tick()
        current.error?.let { log.e("script '${active?.name}' crashed", it) }
        return if (delay == ScriptRunner.DONE) NO_LOOP else delay
    }

    /** The script's last-reported [ScriptScope.status], or `""`. */
    protected val status: String get() = runner?.status ?: ""

    /**
     * Default overlay: a one-line status readout, shown only once the script reports a [ScriptScope.status].
     * Override to customise (or draw nothing) — with no draw calls the implicit overlay window stays hidden
     * for that frame.
     */
    override fun onPanel(gfx: Gfx2D) {
        val s = status
        if (s.isEmpty()) return
        gfx.text(active?.name ?: "script")
        gfx.text("Status: $s")
    }
}
