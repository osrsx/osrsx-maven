package io.osrsx.script

/**
 * Generic script verbs shared by skilling/minigame scripts — the quest layer's proven interaction
 * idioms exported for any [ScriptScope] body. Like the quest actions these are **idempotent**,
 * **outcome-confirming** (they block until their result is observed) and throw [ScriptActionFailed]
 * when they definitively can't get there.
 *
 * @since 0.25.0
 */

/**
 * The re-click gate behind every poll-driven interaction loop (the quest layer's `shouldClick`,
 * public): [ready] is true when a fresh click should be issued NOW — the first call always, then only
 * once [cooldownMs] has passed AND the player looks idle (not walking, not animating) — the game still
 * acting on the previous click is not a reason to click again. Callers [stamp] each issued click:
 *
 * ```
 * val gate = clickGate()
 * waitUntil(60_000, pollMs = 600) {
 *     if (done()) return@waitUntil true
 *     if (gate.ready()) { node.interact("Mine"); gate.stamp() }
 *     false
 * }
 * ```
 *
 * @since 0.25.0
 */
class ClickGate internal constructor(
    private val scope: ScriptScope,
    private val cooldownMs: Long,
) {
    private var lastIssueMs = 0L

    /** True when a fresh click may be issued now (first call, or cooled down + player idle). */
    fun ready(): Boolean {
        if (lastIssueMs == 0L) return true
        if (scope.nowMs() - lastIssueMs < cooldownMs) return false
        val myself = scope.me
        return myself?.isMoving != true && (myself?.animation ?: -1) == -1
    }

    /** Record that a click was just issued (starts the cooldown). */
    fun stamp() { lastIssueMs = scope.nowMs() }

    /** [ready] + [stamp] in one: true exactly when the caller should click, already stamped. Use when
     *  the click can't fail to issue; prefer ready/stamp when the interact itself may return false. */
    fun tryAcquire(): Boolean {
        if (!ready()) return false
        stamp()
        return true
    }
}

/** A [ClickGate] bound to this scope. [cooldownMs] is the re-click cooldown (default 4 s). */
fun ScriptScope.clickGate(cooldownMs: Long = 4_000): ClickGate = ClickGate(this, cooldownMs)

/**
 * Gather from scene objects until [until] is satisfied: engage the nearest object whose id is in
 * [objectIds] (with [action], or its default), re-engaging — [clickGate]-paced, so never spamming —
 * whenever the player goes idle (interrupted, node hopped, inventory event). Node depletion is handled
 * by the id set itself: a depleted node's replacement object no longer matches [objectIds], so the next
 * pass engages the nearest still-active node.
 *
 * Returns true when [until] is satisfied. Throws [ScriptActionFailed] when no matching object has been
 * in the scene for [absentGraceMs] (the caller decides where to walk next — this verb never travels), or
 * when [until] isn't reached within [timeoutMs].
 *
 * @since 0.25.0
 */
suspend fun ScriptScope.harvest(
    objectIds: Set<Int>,
    action: String? = null,
    timeoutMs: Long = 120_000,
    absentGraceMs: Long = 5_000,
    until: ScriptScope.() -> Boolean,
): Boolean {
    if (until()) return true
    val gate = clickGate()
    var absentSince = 0L
    val done = waitUntil(timeoutMs, pollMs = 600) {
        if (until()) return@waitUntil true
        val node = objects.query().keepIf { it.id in objectIds }.nearest()
        if (node == null) {
            if (absentSince == 0L) absentSince = nowMs()
            if (nowMs() - absentSince >= absentGraceMs)
                throw ScriptActionFailed("harvest — no object of ${objectIds.take(4)}… in scene for ${absentGraceMs}ms")
            return@waitUntil false
        }
        absentSince = 0L
        if (gate.ready()) {
            if (node.interact(action)) gate.stamp()
        }
        false
    }
    if (!done) throw ScriptActionFailed("harvest — target not reached within ${timeoutMs}ms")
    return true
}

/**
 * Produce [amount] of item [resultId] at a production station: engage the nearest object in
 * [stationIds], wait for the "make" interface, pick the quantity ([Dialogues.makeQuantity] — the exact
 * [amount], or the All preset when [all]), and block until the inventory gained [amount] of [resultId]
 * (or, with [all], until production stops). Already-holding-enough is a no-op, so the verb is idempotent.
 *
 * Stations whose production UI needs a recipe SELECTED first (a multi-recipe crafting interface) are out
 * of this verb's scope — select the recipe in the caller, then use this for the quantity + confirm leg,
 * or drive the widget flow directly.
 *
 * Throws [ScriptActionFailed] when the interface never opens or the count never lands.
 *
 * @since 0.25.0
 */
suspend fun ScriptScope.craftMake(
    stationIds: Set<Int>,
    amount: Int,
    resultId: Int,
    action: String? = null,
    all: Boolean = false,
    timeoutMs: Long = 60_000,
): Boolean {
    val start = inventory.count(resultId)
    if (!all && start >= amount) return true

    if (!dialogues.makeOpen()) {
        val gate = clickGate()
        val opened = waitUntil(20_000, pollMs = 600) {
            if (dialogues.makeOpen()) return@waitUntil true
            val station = objects.query().keepIf { it.id in stationIds }.nearest()
                ?: throw ScriptActionFailed("craftMake — no station of $stationIds in scene")
            if (gate.ready()) {
                if (station.interact(action)) gate.stamp()
            }
            false
        }
        if (!opened) throw ScriptActionFailed("craftMake — make interface never opened")
    }

    if (!dialogues.makeQuantity(all = all, amount = amount))
        throw ScriptActionFailed("craftMake — quantity pick failed (interface closed?)")

    // Production confirmed by the inventory count. With [all] we instead finish when production stops
    // (count stable + idle) — the exact total depends on materials, which the caller knows better.
    if (!all) {
        val landed = waitUntil(timeoutMs, pollMs = 600) { inventory.count(resultId) >= start + amount }
        if (!landed) throw ScriptActionFailed("craftMake — expected ${start + amount}× $resultId, have ${inventory.count(resultId)}")
    } else {
        var lastCount = inventory.count(resultId)
        var stableSince = nowMs()
        waitUntil(timeoutMs, pollMs = 600) {
            val c = inventory.count(resultId)
            if (c != lastCount) { lastCount = c; stableSince = nowMs() }
            c > start && nowMs() - stableSince > 3_000 && me?.animation == -1
        }
    }
    return true
}
