package io.osrsx.script

import io.osrsx.api.OsrsxDsl
import io.osrsx.api.PluginApi
import io.osrsx.util.Rng
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

/**
 * Thrown to unwind a running script when its plugin stops. Authors don't catch it — the [ScriptRunner]
 * swallows it as a clean stop (the coroutine counterpart of [io.osrsx.plugin.ScriptStopped]).
 *
 * @since 0.4.0
 */
class ScriptStopped : RuntimeException()

/**
 * A bot authored as a **linear suspend script** — the compiled Script DSL, a third authoring style
 * alongside raw `onLoop` and [io.osrsx.plugin.ScriptPlugin]. Write the automation top-to-bottom; its
 * cooperative waits ([ScriptScope.sleep] / [ScriptScope.waitUntil] / [ScriptScope.waitWhile]) **yield** the
 * loop thread instead of hard-blocking it, so the plugin's loop stays free between waits. Native Kotlin
 * `while` / `if` / functions serve as the DSL's loops / branches / subroutines.
 *
 * ```
 * val chop = script("chopper") {
 *     while (!isStopping) {
 *         if (inventory.isFull) { openBank(); depositInventory(); continue }
 *         val tree = objects.query().named("Tree").withAction("Chop down").nearest()
 *             ?: run { sleep(300..600); continue }          // humanised random pause
 *         tree.interact("Chop down")
 *         waitUntil(30.seconds) { me?.animation == -1 || inventory.isFull }
 *     }
 * }
 * ```
 *
 * Waits take [kotlin.time.Duration] (`sleep(2.seconds)`, `waitUntil(30.seconds) { … }`) or a range for a
 * humanised delay (`sleep(400..600)`), and the query DSL is a plain [Iterable] so stdlib ops chain straight
 * off it (`npcs.query().alive().minByOrNull { it.distance() }`).
 *
 * Build one with [script]; run it from a [ScriptDslPlugin] (which wires it into the per-plugin loop) or
 * drive a [ScriptRunner] directly.
 *
 * @since 0.4.0
 */
class Script internal constructor(
    val name: String,
    internal val body: suspend ScriptScope.() -> Unit,
)

/**
 * Author a [Script]. The [body] runs on the plugin loop thread and blocks only via the cooperative waits.
 *
 * @since 0.4.0
 */
fun script(name: String = "script", body: suspend ScriptScope.() -> Unit): Script = Script(name, body)

/**
 * The receiver a [Script] body runs against: the cooperative-wait primitives plus the game [ctx] (so its
 * unprefixed accessors — `inventory`, `bank`, `dialogues`, … — and the handler builders are in scope).
 *
 * Every wait is built on the single engine primitive [park], which suspends the coroutine and hands the
 * loop thread back to the caller until the requested time elapses — the waits therefore never busy-spin and
 * never hold the engine lease. Interactions inside actions take the engine lease themselves (via the method
 * APIs), exactly as they do from `onLoop`.
 *
 * @since 0.4.0
 */
@OsrsxDsl
interface ScriptScope : PluginApi {

    /** True once the owning plugin is stopping — checked by the waits to unwind the script cleanly. */
    val isStopping: Boolean

    /** The runner's current time (from its [Clock]); waits measure their deadlines against it. */
    fun nowMs(): Long

    /**
     * The one engine primitive: suspend the script for ~[delayMs] ms, yielding the loop thread. The runner
     * resumes it no earlier than that; every other wait composes this. `park(0)` yields exactly one tick.
     */
    suspend fun park(delayMs: Long)

    /** Yield the loop for a single tick (re-checked on the next [ScriptRunner.tick]). */
    suspend fun yieldTick() = park(0)

    /** Throw [ScriptStopped] if the plugin is stopping — call at loop boundaries in long custom waits. */
    fun checkStop() {
        if (isStopping) throw ScriptStopped()
    }

    /** Suspend for [ms] ms (cooperatively — the loop thread is free meanwhile). Unwinds if the plugin stops. */
    suspend fun sleep(ms: Long) {
        checkStop()
        if (ms <= 0) return
        val deadline = nowMs() + ms
        var remaining = ms
        while (remaining > 0) {
            park(remaining)
            checkStop()
            remaining = deadline - nowMs()
        }
    }

    /** Suspend for [duration] — `sleep(2.seconds)` / `sleep(600.milliseconds)`. */
    suspend fun sleep(duration: Duration) = sleep(duration.inWholeMilliseconds)

    /** Suspend for a uniformly-random time in `[minMs, maxMs]` — a humanised delay. */
    suspend fun sleep(minMs: Long, maxMs: Long) = sleep(Rng.uniform(minMs, maxMs))

    /** Suspend for a uniformly-random time in [range] ms — `sleep(400..600)`, the idiomatic humanised delay. */
    suspend fun sleep(range: LongRange) = sleep(Rng.uniform(range.first, range.last))

    /** Suspend for a uniformly-random [Duration] in [range] — `sleep(1.seconds..3.seconds)`. */
    suspend fun sleep(range: ClosedRange<Duration>) =
        sleep(Rng.uniform(range.start.inWholeMilliseconds, range.endInclusive.inWholeMilliseconds))

    /**
     * Suspend until [condition] is true (→ true) or [timeoutMs] elapses (→ false), re-checking every
     * [pollMs]. Cooperative: each poll parks the loop thread rather than spinning. Because a poll re-invokes
     * [condition], loop-driven method calls that return true "when done" (e.g. `bank.openNearest()`) can be
     * passed directly.
     */
    suspend fun waitUntil(timeoutMs: Long = 10_000, pollMs: Long = 100, condition: () -> Boolean): Boolean {
        val deadline = nowMs() + timeoutMs
        while (true) {
            checkStop()
            if (condition()) return true
            val remaining = deadline - nowMs()
            if (remaining <= 0) return condition() // one final check at the deadline
            park(minOf(pollMs, remaining))
        }
    }

    /** Suspend while [condition] stays true; returns true once it flips false, false on [timeoutMs]. */
    suspend fun waitWhile(timeoutMs: Long = 10_000, pollMs: Long = 100, condition: () -> Boolean): Boolean =
        waitUntil(timeoutMs, pollMs) { !condition() }

    /** [waitUntil] with [Duration] deadlines — `waitUntil(30.seconds) { inventory.isFull }`. */
    suspend fun waitUntil(timeout: Duration, poll: Duration = 100.milliseconds, condition: () -> Boolean): Boolean =
        waitUntil(timeout.inWholeMilliseconds, poll.inWholeMilliseconds, condition)

    /** [waitWhile] with [Duration] deadlines. */
    suspend fun waitWhile(timeout: Duration, poll: Duration = 100.milliseconds, condition: () -> Boolean): Boolean =
        waitWhile(timeout.inWholeMilliseconds, poll.inWholeMilliseconds, condition)

    /** Run [body] repeatedly until [condition] is true (a light loop combinator; native `while` also works). */
    suspend fun repeatUntil(condition: () -> Boolean, body: suspend ScriptScope.() -> Unit) {
        while (!condition()) {
            checkStop()
            body()
        }
    }

    /** Suspend counterpart of stdlib `repeat` — run [body] [times] times, passing the 0-based index, honouring stop. */
    suspend fun repeat(times: Int, body: suspend ScriptScope.(Int) -> Unit) {
        var i = 0
        while (i < times) {
            checkStop()
            body(i)
            i++
        }
    }

    /**
     * Run [body] on a fixed cadence of [interval] (measured from each run's START) until [isStopping] or
     * [times] iterations elapse — a periodic monitor loop that self-rate-limits. `every(2.seconds) { eatIfLow() }`.
     */
    suspend fun every(interval: Duration, times: Int = Int.MAX_VALUE, body: suspend ScriptScope.(Int) -> Unit) {
        var i = 0
        while (i < times) {
            checkStop()
            val startedAt = nowMs()
            body(i)
            i++
            if (i >= times) break
            val wait = interval.inWholeMilliseconds - (nowMs() - startedAt)
            if (wait > 0) sleep(wait)
        }
    }

    /**
     * Report the script's current activity — `status("Chopping")`. Surfaced automatically on a
     * [ScriptDslPlugin]'s data box and readable via [ScriptRunner.status]. A no-op if the scope has no
     * status sink (e.g. a bare custom [ScriptScope]).
     */
    fun status(text: String) {}

    /** The most recent [status] reported, or `""` if none. */
    val status: String get() = ""
}
