package io.osrsx.plugin

import io.osrsx.api.packArgb
import java.awt.Color

/**
 * The 2D immediate-mode drawing surface a plugin draws through — a thin, engine-agnostic facade over the
 * current UI frame so panels/overlays are authored in osrsx terms (`gfx.text(...)`, `gfx.button(...)`)
 * rather than against a concrete UI toolkit. The engine supplies the backing implementation.
 *
 * Handed to two capabilities:
 *  - [HasPanel.onPanel] — floating in-game overlays. Root-scope draw calls go into an implicit window
 *    titled the plugin name, shown only on frames it actually drew; [overlay] opens extra named windows.
 *  - [HasMenu.onMenu] — the plugin's docked sidebar panel body (a single engine-managed window).
 *
 * Stateful widgets take the current value and return the new one (immediate-mode style): read the
 * returned value and store it back yourself.
 *
 * Every colour is a packed **`0xAARRGGBB` int**; each colour-taking method also offers float-component and
 * [java.awt.Color] overloads (see [io.osrsx.api.packArgb]) that funnel through the single `Int`-ARGB method.
 */
interface Gfx2D {
    fun text(s: String)

    /** Word-wrapped text: wraps at the current container's right edge (a long line flows onto multiple rows)
     *  instead of overflowing/clipping. The default falls back to [text] (no wrap) for older engines. */
    fun textWrapped(s: String): Unit = text(s)

    /** Word-wrapped [textColored] — [argb] is a packed `0xAARRGGBB` int. Default falls back to [textColored]. */
    fun textWrappedColored(argb: Int, s: String): Unit = textColored(argb, s)

    /** Coloured text; [argb] is a packed `0xAARRGGBB` int — the one real implementation path. */
    fun textColored(argb: Int, s: String)

    /** Coloured text from float components (each `0f..1f`). Converts to ARGB and delegates. */
    fun textColored(r: Float, g: Float, b: Float, a: Float, s: String): Unit = textColored(packArgb(r, g, b, a), s)

    /** Coloured text from a [java.awt.Color] (alpha honoured). Converts to ARGB and delegates. */
    fun textColored(color: Color, s: String): Unit = textColored(color.rgb, s)

    fun separator()
    fun sameLine()
    fun spacing()

    /** @return true on the frame the button is clicked. */
    fun button(label: String): Boolean

    /** A button that, when [fillWidth] is true, stretches to the full width of the current container (for a
     *  primary action that should span the panel). @return true on the click frame. Default ignores
     *  [fillWidth] and falls back to [button] for older engines. */
    fun button(label: String, fillWidth: Boolean): Boolean = button(label)

    /** A compact square **icon button** — [icon] is drawn from the FontAwesome glyph set (use [MenuIcon.custom]
     *  for an arbitrary codepoint). [id] is a stable widget key. @return true on the click frame. Default falls
     *  back to a text button for older engines. */
    fun iconButton(id: String, icon: MenuIcon): Boolean = button(id)

    /**
     * A small icon button drawn in the **title bar** of the current floating window ([HasPanel]), right of the
     * title — e.g. a dock/pin control. [icon] is a FontAwesome glyph ([MenuIcon.custom] for any codepoint).
     * Call it once per frame from [HasPanel.onPanel]. @return true on the frame it's clicked (a frame late, as
     * the header is finalised after the body). Default falls back to an inline [iconButton].
     */
    fun headerButton(icon: MenuIcon): Boolean = iconButton("##header", icon)

    /** @return the new checkbox state (pass the current value in). */
    fun checkbox(label: String, value: Boolean): Boolean

    /** @return the new slider value (pass the current value in). */
    fun sliderInt(label: String, value: Int, min: Int, max: Int): Int

    /** @return the new integer (pass the current value in). */
    fun inputInt(label: String, value: Int): Int

    /**
     * Three integers on a **single row** — a game-engine style vector field (X / Y / Z), ideal for a
     * tile/coordinate entry. [label] is shown once after the trio (pass `""` for none). Pass the current
     * components in; @return the new `[x, y, z]`. The default composes three [inputInt]s (functional but not
     * inline) so headless/older engines still work; the real engine renders them compactly on one line.
     */
    fun inputInt3(label: String, x: Int, y: Int, z: Int): IntArray =
        intArrayOf(inputInt("$label X", x), inputInt("$label Y", y), inputInt("$label Z", z))

    /** @return the new text (pass the current value in). */
    fun inputText(label: String, value: String, maxLen: Int = 256): String

    /**
     * A searchable item picker (GE-search-style fuzzy match, item sprite + name + category rows). [id] is a
     * stable widget key. @return the selected item id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]) for engine impls without a graphical surface.
     */
    fun itemPicker(id: String, selected: Int): Int = selected

    /**
     * A searchable NPC picker (fuzzy match, NPC model thumbnail + name + combat/actions rows). [id] is a
     * stable widget key. @return the selected NPC id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]).
     */
    fun npcPicker(id: String, selected: Int): Int = selected

    /**
     * A searchable object picker (fuzzy match, object model thumbnail + name + coordinates rows). [id] is a
     * stable widget key. @return the selected object id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]).
     */
    fun objectPicker(id: String, selected: Int): Int = selected

    /**
     * A searchable dropdown that autocompletes over an arbitrary list of [options] — a general-purpose text
     * picker (fuzzy match, one option per row) for choices with no game-entity id, e.g. named locations. [id]
     * is a stable widget key; [hint] is the placeholder shown when nothing is selected. Pass the current
     * selection in; @return the chosen option, or [selected] unchanged if nothing was picked. The default is a
     * no-op (returns [selected]) for engine impls without a graphical surface.
     */
    fun searchPicker(id: String, options: List<String>, selected: String, hint: String = "Search…"): String = selected

    /**
     * A titled, bordered **section** — a rounded group box with [label] notched into its top-left border and a
     * subtle fill, matching the client's config-panel sections. Draw the section's contents in [block]; they
     * are laid out inside the box. Use it to group a panel into labelled cards. The default just runs [block]
     * inline (no framing) so headless/older engines still render the contents.
     */
    fun section(label: String, block: (Gfx2D) -> Unit): Unit = block(this)

    /**
     * A [section] whose content area **scrolls past [maxHeight]**: the box grows with its content
     * like a plain section while shorter, then caps at [maxHeight] px and scrolls vertically — for
     * long lists that shouldn't swallow the whole panel. The default ignores [maxHeight] (plain
     * unbounded section) for older engines.
     */
    fun section(label: String, maxHeight: Float, block: (Gfx2D) -> Unit): Unit = section(label, block)

    /**
     * A [section] with a clickable icon button notched into the **top-right border** (mirroring how [label]
     * notches the top-left) — e.g. a pop-out control. [headerIcon] is a FontAwesome glyph ([MenuIcon.custom]
     * for any codepoint). @return true on the frame the icon is clicked. The default falls back to a plain
     * [section] (no header icon, never clicked) for older engines.
     */
    fun section(label: String, headerIcon: MenuIcon, block: (Gfx2D) -> Unit): Boolean { section(label, block); return false }

    /**
     * A single labelled **field** — one control wrapped in a bordered box with [label] notched into the top of
     * the border (the config panel's per-setting look). Put exactly one widget in [block]; it fills the box
     * width and the box **auto-sizes to the widget's height** with consistent padding (no height to pass). The
     * default draws [label] as text above [block] (no framing) so older engines still render.
     */
    fun field(label: String, block: (Gfx2D) -> Unit) { text(label); block(this) }

    /**
     * A raw-drawing **canvas** with an exact [width]×[height] (each `<= 0` = fill, see the full
     * overload). Equivalent to the full [canvas] with no max constraints and no centring.
     */
    fun canvas(id: String, width: Float, height: Float, block: (GfxCanvas) -> Unit): Unit =
        canvas(id, width, height, 0f, 0f, false, block)

    /**
     * A raw-drawing **canvas**: reserves a region in the current layout and hands [block] a
     * [GfxCanvas] for free-form shapes (lines, boxes, circles), positioned text, and rectangular
     * hover/click hit-testing — for custom widgets the structured vocabulary can't express
     * (a grid of cells, a minimap, a progress mosaic). [id] is a stable widget key. Coordinates
     * inside the block are canvas-local; drawing is clipped to the canvas.
     *
     * **Sizing** — fill by default, cap with the max constraints, or pin exactly:
     *  - [width] / [height] `> 0` = that exact size (the max constraints are ignored on that axis).
     *  - [width] `<= 0` fills the container's available width (a section's inner width inside a
     *    [section]), clamped to [maxWidth] when `> 0`.
     *  - [height] `<= 0` fills the container's remaining height, clamped to [maxHeight] when `> 0`.
     *    In a container that grows with its content (a plain section, an auto-sized floating panel)
     *    there is no "remaining height" to fill — the canvas falls back to [maxHeight], so give a
     *    fill-height canvas a [maxHeight] there (or an exact [height]).
     *  - [centered] horizontally centres a canvas narrower than the container.
     *
     * Read the resolved size inside the block via [GfxCanvas.width]/[GfxCanvas.height]. The default
     * is a no-op (the region isn't reserved, nothing draws) for headless/older engines.
     */
    fun canvas(
        id: String,
        width: Float = 0f,
        height: Float = 0f,
        maxWidth: Float = 0f,
        maxHeight: Float = 0f,
        centered: Boolean = false,
        block: (GfxCanvas) -> Unit,
    ): Unit = Unit

    /**
     * Open an **additional** overlay window titled [title] and draw its body via [block]. Meant for
     * [HasPanel.onPanel]: each call is its own engine-managed, alt-draggable floating window, independent of
     * the implicit plugin-named window that the root scope's draw calls fill. Draw only [overlay] windows
     * (and nothing at the root) to suppress that default window entirely.
     *
     * In a docked [HasMenu.onMenu] body there is no separate overlay chrome, so this simply renders [block]
     * inline in the panel.
     */
    fun overlay(title: String, block: (Gfx2D) -> Unit)

    /** Initial-only window position for the current window (the user can move it after). */
    fun setNextWindowPos(x: Float, y: Float)

    /** Initial-only window size for the current window (the user can resize after). */
    fun setNextWindowSize(w: Float, h: Float)
}
