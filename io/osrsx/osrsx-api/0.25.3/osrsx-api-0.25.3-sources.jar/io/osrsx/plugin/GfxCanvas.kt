package io.osrsx.plugin

/**
 * One frame's interaction state of a rectangular hit-region on a [GfxCanvas] (see [GfxCanvas.hit]).
 * Immediate-mode: [clicked]/[rightClicked] are true only on the frame the press happens.
 */
class GfxHit(
    /** The mouse is over the region this frame (and the canvas itself is hovered — an overlapping
     *  window on top of the canvas suppresses this, so hits never leak through other UI). */
    val hovered: Boolean,
    /** Left mouse button was pressed this frame while [hovered]. */
    val clicked: Boolean,
    /** Right mouse button was pressed this frame while [hovered]. */
    val rightClicked: Boolean,
) {
    companion object {
        /** The no-interaction result (headless engines, mouse elsewhere). */
        val NONE = GfxHit(hovered = false, clicked = false, rightClicked = false)
    }
}

/**
 * A raw immediate-mode drawing surface handed to a [Gfx2D.canvas] block — free-form shapes
 * (lines, boxes, circles) and positioned text, plus rectangular hit-testing so regions can react
 * to hover and clicks. Built for custom widgets the structured [Gfx2D] vocabulary can't express,
 * e.g. a grid of cells, a minimap, a progress mosaic.
 *
 * All coordinates are **canvas-local pixels**: `(0, 0)` is the canvas's top-left, x grows right,
 * y grows down, and drawing is clipped to the canvas bounds. Every colour is a packed
 * **`0xAARRGGBB` int** (see [io.osrsx.api.packArgb]) — same convention as [Gfx2D].
 *
 * Redraw everything every frame (nothing is retained); read [hit] *before* drawing a region to
 * pick its hover/pressed styling in the same frame:
 *
 * ```
 * gfx.canvas("grid", width = 0f, height = 96f) { c ->
 *     for (i in 0 until 5) {
 *         val x = i * 20f
 *         val h = c.hit(x, 0f, 18f, 18f, onClick = { toggle(i) })
 *         c.rectFilled(x, 0f, 18f, 18f, if (h.hovered) 0xFF5B8CFF.toInt() else 0xFF222532.toInt(), rounding = 3f)
 *     }
 * }
 * ```
 */
interface GfxCanvas {
    /** Canvas width in pixels (resolved: a fill-width canvas reports its actual width). */
    val width: Float

    /** Canvas height in pixels. */
    val height: Float

    /** Mouse x in canvas-local coords. Only meaningful while [mouseOver]; may be outside `0..width`. */
    val mouseX: Float

    /** Mouse y in canvas-local coords. Only meaningful while [mouseOver]; may be outside `0..height`. */
    val mouseY: Float

    /** True while the mouse is over the canvas and no other UI window is on top of it. */
    val mouseOver: Boolean

    /** Screen pixels per local unit — `1` at the root, the fitted factor inside a scaled [sub].
     *  Text never auto-scales (see [sub]); multiply an explicit text size by this if you *do* want
     *  a label proportional to the cell. */
    val scale: Float get() = 1f

    /** A straight line from `(x1, y1)` to `(x2, y2)`, [thickness] px wide. */
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, argb: Int, thickness: Float = 1f)

    /** A box **outline** at `(x, y)` sized `w`×`h`; [rounding] > 0 rounds the corners by that radius. */
    fun rect(x: Float, y: Float, w: Float, h: Float, argb: Int, thickness: Float = 1f, rounding: Float = 0f)

    /** A **filled** box at `(x, y)` sized `w`×`h`; [rounding] > 0 rounds the corners by that radius. */
    fun rectFilled(x: Float, y: Float, w: Float, h: Float, argb: Int, rounding: Float = 0f)

    /** A circle **outline** centred on `(cx, cy)` with [radius] px. */
    fun circle(cx: Float, cy: Float, radius: Float, argb: Int, thickness: Float = 1f)

    /** A **filled** circle centred on `(cx, cy)` with [radius] px. */
    fun circleFilled(cx: Float, cy: Float, radius: Float, argb: Int)

    /** Raw text with its top-left at `(x, y)` in the current UI font (no wrapping; clipped at the bounds). */
    fun text(x: Float, y: Float, argb: Int, s: String)

    /**
     * Raw text drawn at an explicit **screen-pixel** [size] (the current UI font rasterised at that
     * size). [size] is absolute — it is NOT multiplied by a [sub] transform's [scale], so a label
     * stays the size you asked for in any cell (pass `size * scale` for a deliberately proportional
     * one). The line height is ≈ [size]; measure the width with `textWidth(s, size)`. The default
     * falls back to the unsized [text] for older engines.
     */
    fun text(x: Float, y: Float, argb: Int, s: String, size: Float): Unit = text(x, y, argb, s)

    /** Width of [s] as [text] draws it, in **local units** (so centring math works inside a scaled
     *  [sub] even though the glyphs themselves don't scale). */
    fun textWidth(s: String): Float

    /** Width of [s] as the sized [text] overload draws it, in local units. */
    fun textWidth(s: String, size: Float): Float = textWidth(s) * (size / textHeight())

    /** Line height of [text] in **local units**, for vertically centring it. */
    fun textHeight(): Float

    /**
     * A nested **sub-canvas** over the rectangle at `(x, y)` sized `w`×`h`: [block] draws through a
     * [GfxCanvas] whose origin is the rect's top-left, clipped to the rect — cell-local coordinates
     * for one cell of a grid, so the cell body never does its own offset math.
     *
     * With [logicalWidth]/[logicalHeight] `> 0` the block instead draws in that **logical coordinate
     * space**, uniformly scaled to fit the rect (aspect preserved, centred): design a cell's content
     * once in logical units and render it at any cell size. Shapes, positions and line thickness
     * scale; **text does not** — glyphs render at the UI font size (or a sized [text]'s explicit
     * pixels) so labels stay crisp and consistent across cell sizes, while their *positions* scale
     * and [textWidth]/[textHeight] report local units so centring math still works. Mouse coords and
     * [hit] regions inside the block are in the same local/logical space. The default is a no-op
     * (nothing draws) for older engines.
     */
    fun sub(
        x: Float, y: Float, w: Float, h: Float,
        logicalWidth: Float = 0f, logicalHeight: Float = 0f,
        block: (GfxCanvas) -> Unit,
    ): Unit = Unit

    /**
     * Hit-test the rectangle at `(x, y)` sized `w`×`h` against the mouse. Immediate-mode: call it
     * every frame for every interactive region, *before* drawing the region, and style off the
     * result. Clicks on the canvas are consumed by the UI (they don't fall through to the game).
     */
    fun hit(x: Float, y: Float, w: Float, h: Float): GfxHit

    /**
     * [hit] with callback sugar: [onHover] runs every frame the region is hovered, [onClick] /
     * [onRightClick] on the frame it's clicked. Also returns the [GfxHit] so styling can reuse it.
     */
    fun hit(
        x: Float, y: Float, w: Float, h: Float,
        onHover: (() -> Unit)? = null,
        onClick: (() -> Unit)? = null,
        onRightClick: (() -> Unit)? = null,
    ): GfxHit {
        val h2 = hit(x, y, w, h)
        if (h2.hovered) onHover?.invoke()
        if (h2.clicked) onClick?.invoke()
        if (h2.rightClicked) onRightClick?.invoke()
        return h2
    }
}
