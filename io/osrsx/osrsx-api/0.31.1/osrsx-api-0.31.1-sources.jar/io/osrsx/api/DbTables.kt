package io.osrsx.api

/**
 * Read the client's cache **DB tables** — the game's own structured data rows that back many systems and are
 * frequently the only complete, unlock-independent source of a fact. Examples: the sailing DOCK table (dock-id
 * → port name / level / quest requirement), courier/port TASK definitions, and facility tier tables. The wiki
 * or a live survey can only see what the account has unlocked; the cache holds every row.
 *
 * A **table** is addressed by its DB-table id; each row it holds by a row id; each field within a row by a
 * column index (plus a [tupleIndex] for the rare column that stores a tuple). Table/column/row ids come from
 * the cache — reference them by name from the gameval catalog (e.g. `DBTableID.SailingDock.ID`,
 * `DBTableID.SailingDock.COL_NICE_NAME`).
 *
 * Reads are marshalled onto the client thread internally, so a plugin may call them from its loop thread like
 * any other accessor. Values come back as the cache's own boxed types — [Int] or [String].
 *
 * Example — build the full sailing dock-id → name map (all docks, including locked ones):
 * ```
 * val docks = ctx.dbTables().rows(DBTableID.SailingDock.ID).associate { row ->
 *     ctx.dbTables().int(row, DBTableID.SailingDock.COL_DOCK_ID) to
 *         ctx.dbTables().str(row, DBTableID.SailingDock.COL_NICE_NAME)
 * }
 * ```
 */
interface DbTables {
    /** All row ids in DB [table], or empty when the table is absent. */
    fun rows(table: Int): List<Int>

    /** The value(s) held in [column] of [rowId]; a column may store a tuple, so [tupleIndex] picks which slot.
     *  Empty when the row/column is absent. Elements are boxed [Int] / [String] (the cache's own types). */
    fun field(rowId: Int, column: Int, tupleIndex: Int = 0): List<Any>

    /** The single [Int] in [column] of [rowId], or null when it isn't an int / isn't present. */
    fun int(rowId: Int, column: Int, tupleIndex: Int = 0): Int? = field(rowId, column, tupleIndex).firstOrNull() as? Int

    /** The single [String] in [column] of [rowId], or null when it isn't a string / isn't present. */
    fun str(rowId: Int, column: Int, tupleIndex: Int = 0): String? = field(rowId, column, tupleIndex).firstOrNull() as? String

    /** Row ids in [table] whose [column] (tuple [tupleIndex]) holds [value]. Defaults to a scan over [rows] +
     *  [field]; an implementation may override it with the engine's own indexed lookup. */
    fun rowsByValue(table: Int, column: Int, value: Any, tupleIndex: Int = 0): List<Int> =
        rows(table).filter { field(it, column, tupleIndex).any { v -> v == value } }
}
