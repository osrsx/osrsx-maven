package io.osrsx.quest

import io.osrsx.api.Interactable
import io.osrsx.api.OsrsxDsl
import io.osrsx.api.SceneEntity
import io.osrsx.api.SceneObject
import io.osrsx.api.Tile
import io.osrsx.ids.Varbits
import io.osrsx.plugin.PluginLog
import io.osrsx.script.ScriptScope

/**
 * The quest action library: `suspend fun ScriptScope.<verb>()` steps a [QuestStage] body composes. Each is
 * **idempotent** (a no-op when already satisfied) and **self-completing** (it observes its own result), so a
 * stage re-runs cleanly on resume. Every action STATES the fact — the verb, the item, the target, the
 * dialogue option — instead of inferring it from prose. Reach/approach/door handling is centralised here
 * ([approach]) so it's solved once for every quest.
 *
 * Every action also **blocks until its outcome is confirmed** (the item is in the inventory, the dialogue
 * opened, the door crossed) and throws [QuestActionFailed] when it definitively can't get there — an action
 * never returns false into the void, so a stage body can never fall through a failed step into the next one
 * (that once skipped a quest item pickup and stranded the quest). The driver catches the failure, logs it,
 * and re-runs the (idempotent) stage.
 *
 * @since 0.20.0
 */

/**
 * A quest action definitively failed: its target never appeared/was unreachable, or its confirmed outcome
 * (item held, dialogue opened, door crossed, …) didn't materialise before the timeout. Thrown instead of
 * returning false so the stage body ABORTS at the failed step; the quest driver ([toScript]) catches it,
 * logs the stage + reason, and re-runs the stage from the top.
 *
 * @since 0.20.0
 */
class QuestActionFailed(message: String) : RuntimeException(message)

private fun fail(action: String, detail: String): Nothing = throw QuestActionFailed("$action — $detail")

// ---- movement -----------------------------------------------------------------------------------------

/** Web-walk to [dest], arriving within [within] tiles. No-op if already there; throws if never arrived. */
suspend fun ScriptScope.walkTo(dest: Tile, within: Int = 1, timeoutMs: Long = 120_000): Boolean {
    if (arrivedNear(dest, within)) return true
    val arrived = waitUntil(timeoutMs, pollMs = 700) {
        if (arrivedNear(dest, within)) true else {
            webWalking.walkTo(dest); false
        }
    }
    if (!arrived) fail("walkTo $dest", "not arrived within ${timeoutMs}ms")
    return true
}

private fun ScriptScope.arrivedNear(dest: Tile, within: Int): Boolean {
    val t = me?.tile() ?: return false
    return webWalking.arrived(dest) || t.distanceTo(dest) <= within
}

// ---- NPCs & dialogue ----------------------------------------------------------------------------------

/**
 * Talk to NPC [name] (optionally web-walking to [at] first) and drive the dialogue: auto-continue pages and
 * pick the STATED options ([dialogue]). Options are chosen by the first pending directive that matches an
 * available option, in any order (so `after`-style gating isn't needed for the common case).
 */
suspend fun ScriptScope.talkTo(name: String, at: Tile? = null, dialogue: (Dialogue.() -> Unit)? = null): Boolean {
    if (!dialogues.inDialogue()) {
        val npc = approach(name, at)
        var lastClick = 0L
        var issued = false
        val opened = waitUntil(15_000, pollMs = 800) {
            if (dialogues.inDialogue()) return@waitUntil true
            // Click "Talk-to" only until interactPrecise CONFIRMS it landed, then wait for the dialogue — never
            // re-click an NPC we've already engaged (a re-click just restarts/cancels the interaction).
            if (!issued && shouldClick(lastClick)) {
                if (npc.interactPrecise("Talk-to")) issued = true
                lastClick = nowMs()
            }
            false
        }
        if (!opened) fail("talkTo $name", "dialogue never opened")
    }
    return runDialogue(name, dialogue)
}

/** An ordered set of dialogue options to select — `choose("Yes.")`, `choose(byId = 2)`. */
@OsrsxDsl
class Dialogue internal constructor() {
    internal val choices = mutableListOf<Choice>()
    fun choose(text: String) {
        choices += Choice(text = text)
    }

    fun choose(byId: Int) {
        choices += Choice(id = byId)
    }
}

internal class Choice(val text: String? = null, val id: Int? = null)
private val logger = PluginLog("QuestActions")

private suspend fun ScriptScope.runDialogue(target: String, build: (Dialogue.() -> Unit)?): Boolean {
    val pending = build?.let { Dialogue().apply(it).choices.toMutableList() } ?: mutableListOf()
    val deadline = nowMs() + 40_000
    while (nowMs() < deadline && !isStopping) {
        if (!dialogues.inDialogue()) {
            // Keep going until there are genuinely NO more continues. A page transition (or an auto-talk that
            // reopens a beat later) briefly drops the dialogue widget, so only FINISH once it has STAYED closed
            // through a short re-confirm — otherwise we'd skip a final continue that's a tick late.
            if (!waitUntil(1_000, pollMs = 150) { dialogues.inDialogue() }) return true
        }
        val opts = dialogues.getOptions()
        if (opts.isNotEmpty()) {
            val match = pending.firstOrNull { c ->
                (c.text != null && opts.any {
                    it.contains(
                        c.text,
                        ignoreCase = true
                    )
                }) || (c.id != null && c.id in 1..opts.size)
            }
            when {
                match?.text != null -> if (dialogues.chooseOption(match.text)) pending.remove(match)
                match?.id != null -> if (dialogues.chooseOption(match.id)) pending.remove(match)
                else -> dialogues.chooseOption(opts.size) // unlisted screen → safe close (conventionally the last row)
            }
            logger.d("Selected dialogue option: $match")
        } else {
            dialogues.continueAuto()
            logger.d("Continuing automatically")
        }
        park(650)
    }
    if (dialogues.inDialogue() && !isStopping) fail(target, "dialogue did not complete within 40s")
    return true
}

/**
 * Drive whatever dialogue is CURRENTLY open (or opens within [timeoutMs]) — auto-continuing pages and
 * selecting the STATED options ([build]) AS THEY BECOME AVAILABLE — **without** talking to an NPC. For a
 * dialogue an OBJECT interaction triggers: a door that pops a refusal choice, a lever/panel prompt, a searched
 * container that asks a question. Complements [talkTo] (which approaches + talks first) and the driver's
 * continue-only incidental-dialogue pump (which never touches options). Options match in any order,
 * first-pending-that's-available wins; an unlisted option screen safe-closes on the last row.
 *
 * LENIENT: if no dialogue opens within [timeoutMs] it just returns (does NOT fail) — so an empty
 * `dialogue()` is a safe "continue through any follow-up chat that this step's interaction might pop"
 * (a door that, once you're allowed in, plays a continue-only remark). With no [build] and no options it
 * simply auto-continues every page until the dialogue closes.
 *
 * Typical uses:
 * ```
 * interact("Door", "Open", at = doorTile)   // pops a refusal CHOICE
 * dialogue { choose("I fear not a mere plague."); choose("I want to check anyway.") }
 *
 * open("Door", at = doorTile)               // once admitted, a continue-only remark plays
 * dialogue()                                // just click through it (no-op if none appears)
 * ```
 */
suspend fun ScriptScope.dialogue(timeoutMs: Long = 8_000, build: (Dialogue.() -> Unit)? = null): Boolean {
    if (!waitUntil(timeoutMs, pollMs = 300) { dialogues.inDialogue() }) return false // nothing popped — not a failure
    return runDialogue("dialogue", build)
}

/** True if the inventory holds [item] — a readable guard for conditional stage steps. */
fun ScriptScope.hasItem(item: Int): Boolean = item in inventory

// ---- location probes (conditional stage steps) ---------------------------------------------------------
//
// Several quests have one var value covering actions on BOTH sides of a transition the game performs
// automatically (dig → dropped into the sewer, cutscene → moved rooms). Quest Helper models those as
// zone-keyed ConditionalSteps; our stages express them as plain `if` guards on these probes.

/**
 * True when anything named [name] is currently in the loaded scene — a scene object, an NPC, or a ground
 * item (object lookup is nearest-to-[at] if given). The presence probe for state-dependent steps where the
 * same var value shows different world state: climb down the dug "Hole" only when it exists, re-dig the
 * patch otherwise.
 */
fun ScriptScope.isObjectPresent(name: String, at: Tile? = null): Boolean =
    findObject(name, at) != null || npcs.closest(name) != null || groundItems.closest(name) != null

/** True when ground item [item] (by id) is currently in the loaded scene — the id-based presence probe for
 *  item spawns (pairs with `beforeEach { if (!hasItem(X) && isObjectPresent(X)) take(X) }`). */
fun ScriptScope.isObjectPresent(item: Int): Boolean = groundItems.closest(item) != null

/**
 * An axis-aligned rectangle of tiles between two inclusive corners on one plane — the quest-DSL counterpart
 * of Quest Helper's `Zone`, so QH zone corners can be copied verbatim:
 * `Area(Tile(2506, 9737, 0), Tile(2532, 9781, 0))` ← QH `new Zone(new WorldPoint(2506, 9737, 0), …)`.
 */
class Area(corner1: Tile, corner2: Tile) {
    private val minX = minOf(corner1.x, corner2.x)
    private val maxX = maxOf(corner1.x, corner2.x)
    private val minY = minOf(corner1.y, corner2.y)
    private val maxY = maxOf(corner1.y, corner2.y)
    private val plane = corner1.plane

    /** True if [tile] lies inside this area (`tile in area`; null ⇒ false). */
    operator fun contains(tile: Tile?): Boolean =
        tile != null && tile.plane == plane && tile.x in minX..maxX && tile.y in minY..maxY
}

/** Create an [Area] from two inclusive corners on the same plane (default 0). **/
fun ScriptScope.area(corner1: Tile, corner2: Tile): Area = Area(corner1, corner2)

fun ScriptScope.area(x1: Int, y1: Int, x2: Int, y2: Int, plane: Int = 0): Area =
    area(Tile(x1, y1, plane), Tile(x2, y2, plane))

/** True when the player stands inside [area] — the zone guard for conditional stage steps. */
fun ScriptScope.inArea(area: Area): Boolean = me?.tile() in area


/**
 * Web-walk to object/NPC [name], then ISSUE an interaction on it, RETRYING until the click actually lands.
 * [click] performs one attempt on the resolved target (interactPrecise / interactAny — returns whether it was
 * issued); [tries] is the 1-based attempt count so the caller can escalate (e.g. precise → plain menu).
 *
 * Clicks fired MID-RUN miss: a right-click reads the context menu for where the target *was*, and a tracked
 * clickbox slides out from under the cursor as we stride — which is why a workman's real "Steal-from" looked
 * "absent". So after a few misses we WAIT until the avatar has COMPLETELY stopped moving before the next
 * attempt ([shouldClick] already holds ordinary re-clicks until we're still; this is the firmer backstop for a
 * target we keep chasing). Fails on timeout.
 */
private suspend fun ScriptScope.interactUntilIssued(
    name: String,
    at: Tile?,
    requirePath: Boolean,
    what: String,
    click: (target: Interactable, tries: Int) -> Boolean,
) {
    approach(name, at, requirePath)
    var lastClick = 0L
    var misses = 0
    val ok = waitUntil(25_000, pollMs = 400) {
        if (misses >= 3 && me?.isMoving == true) return@waitUntil false // still running in → settle first
        if (!shouldClick(lastClick)) return@waitUntil false
        val target = findObject(name, at) ?: findNpc(name, at) ?: return@waitUntil false
        lastClick = nowMs()
        if (click(target, misses + 1)) true else { misses++; false }
    }
    if (!ok) fail(what, "interaction never landed (unreachable, or the action wasn't on the live menu)")
}

/** Pickpocket NPC [name] (optionally walking to [at] first). */
suspend fun ScriptScope.pickpocket(name: String, at: Tile? = null): Boolean {
    // NPCs vary: most expose "Pickpocket", some (dig-site workmen, a few guards) "Steal-from" — take whichever
    // the live menu offers. Retrying (and standing still after misses) so a mid-run miss isn't mistaken for
    // "no such action".
    val actions = listOf("Pickpocket", "Steal-from")
    interactUntilIssued(name, at, requirePath = true, what = "pickpocket $name") { target, _ ->
        (target as? SceneEntity)?.interactAny(actions) ?: target.interactPrecise(actions.first())
    }
    park(600)
    return true
}

// ---- objects ------------------------------------------------------------------------------------------

/**
 * Interact with object [name] using the STATED menu [action] (walking to [at] first, which also
 * disambiguates non-unique ids by nearest-to-[at]). Returns once the interaction was issued.
 *
 * Set [direct] when [name] is a BARRIER you operate in place — a wall to "Kick", a fence to "Squeeze-through"
 * — so it commits when adjacent (the barrier's own wall edge would otherwise make it unreachable). Leave it
 * false for ordinary objects (levers, staircases, trapdoors): those must be genuinely path-reachable, so they
 * are never clicked through a closed door.
 */
suspend fun ScriptScope.interact(name: String, action: String, at: Tile? = null, direct: Boolean = false): Boolean {
    // Retry until the click lands, standing still after misses (see [interactUntilIssued]); after 3 precise
    // misses fall back to the plain right-click menu — more forgiving for a fiddly clickbox (a panning point).
    interactUntilIssued(name, at, requirePath = !direct, what = "interact $name → '$action'") { target, tries ->
        if (tries <= 3) target.interactPrecise(action) else target.interact(action)
    }
    park(1200)
    return true
}

/**
 * Climb object [name] up/down. Idempotent when [toPlane] is given: a no-op if already on that plane. Accepts
 * BOTH the "Climb-up"/"Climb-down" and "Walk-up"/"Walk-down" action variants (different staircases/ladders use
 * one or the other) — whichever the object's live menu offers is used.
 */
suspend fun ScriptScope.climb(name: String, up: Boolean, at: Tile? = null, toPlane: Int? = null): Boolean {
    if (toPlane != null && me?.tile()?.plane == toPlane) return true
    // Directional variants first, then the generic single "Climb" (mud piles, some ladders/holes expose only
    // that — its direction is fixed by the object) so interactAny picks whichever the live menu actually offers.
    val actions = if (up) listOf("Climb-up", "Walk-up", "Climb") else listOf("Climb-down", "Walk-down", "Climb")
    interactUntilIssued(name, at, requirePath = true, what = "climb $name") { target, _ ->
        (target as? SceneEntity)?.interactAny(actions) ?: target.interactPrecise(actions.first())
    }
    park(1200)
    return true
}

/**
 * Open door/gate [name] and WAIT until the crossing is confirmed: the closed door is gone (it flips to an open
 * door that offers "Close", not "Open"). Without this the click is fire-and-forget, so a following action runs
 * while the door is still shut — and because reach is geometric, it happily clicks a target on the far side
 * *through* the closed door, stranding us outside. (Re)issues the "Open" until it takes. Idempotent: a no-op
 * once the door is already open.
 *
 * **Returns whether the door opened** (does NOT throw), so a caller can gate on the failure — some doors
 * ADMIT you via a dialogue instead of opening (their object stays shut), and there [open] returns false the
 * instant that dialogue pops (no 10s wait), letting the stage drive it:
 * ```
 * if (!open("Door", at = doorTile)) dialogue()   // opened? done. else it popped an admit/refusal chat → handle it
 * ```
 * Returns false, too, if the door simply never opened within the window.
 */
suspend fun ScriptScope.open(name: String, at: Tile? = null): Boolean {
    approach(name, at, requirePath = false)
    var lastClick = 0L
    var issued = false
    var opened = false
    waitUntil(10_000, pollMs = 600) {
        val door = findObject(name, at)
        if (door == null || door.actions().none { it.equals("Open", ignoreCase = true) }) { opened = true; return@waitUntil true }
        // The click ADMITTED us via a dialogue rather than opening the door — stop now (opened stays false) so
        // the caller can drive that dialogue; re-clicking through it would just re-pop it.
        if (dialogues.inDialogue()) return@waitUntil true
        // (Re)issue "Open" only until interactPrecise CONFIRMS the click landed; then wait for the door to swing
        // (it loses "Open") instead of re-clicking a door we've already actioned (which could toggle it shut).
        if (!issued && shouldClick(lastClick)) {
            if (door.interactPrecise("Open")) issued = true
            lastClick = nowMs()
        }
        false
    }
    return opened
}

/**
 * Push wall/passage [name] and WAIT until we've actually moved through (our tile changes) before returning,
 * so the next action doesn't fire while we're still on the near side of the crossing. Best-effort position
 * confirmation — (re)issues the "Push" each poll until we've crossed.
 */
suspend fun ScriptScope.push(name: String, at: Tile? = null): Boolean {
    approach(name, at, requirePath = false)
    val before = me?.tile()
    var lastClick = 0L
    var issued = false
    val crossed = waitUntil(10_000, pollMs = 600) {
        val now = me?.tile()
        if (before == null || (now != null && now.distanceTo(before) >= 1)) return@waitUntil true
        if (!issued && shouldClick(lastClick)) {
            if (findObject(name, at)?.interactPrecise("Push") == true) issued = true
            lastClick = nowMs()
        }
        false
    }
    if (!crossed) fail("push $name", "crossing unconfirmed (tile never changed)")
    return true
}

/** Search object [name]. */
suspend fun ScriptScope.search(name: String, at: Tile? = null): Boolean = interact(name, "Search", at)

/** Dig at [at] with a spade in the inventory. */
suspend fun ScriptScope.dig(at: Tile): Boolean {
    walkTo(at)
    if (!inventory.interact("Spade", "Dig")) fail("dig $at", "no spade held (or 'Dig' unavailable)")
    park(1500)
    return true
}

// ---- items --------------------------------------------------------------------------------------------

/**
 * Use held item [item] on object/NPC [targetName] (walking to [at] first). No-op if the item isn't held
 * (idempotent — the quest already consumed it). [targetName] resolves to a scene object, else an NPC.
 */
suspend fun ScriptScope.useOn(item: Int, targetName: String, at: Tile? = null): Boolean {
    if (item !in inventory) return true
    val target = approach(targetName, at)
    val held = inventory.getItem(item) ?: return true
    if (!inventory.useOn(held, target)) fail("useOn $item → $targetName", "could not issue the use")
    park(1200)
    return true
}

/**
 * Checks to see if the given object/npc has the provided action. Does not route to the object/npc.
 */
fun ScriptScope.hasAction(name: String, action: String, at: Tile? = null): Boolean {
    val obj = findObject(name, at)
    if (obj != null) return action in obj.actions()
    val npc = findNpc(name, at)
    if (npc != null) return action in npc.actions()
    return false
}

/** Perform a menu [action] on a held inventory item ("Read", "Empty", "Operate", "Rub", …). No-op if not held. */
suspend fun ScriptScope.useItem(item: Int, action: String): Boolean {
    val held = inventory.getItem(item) ?: return true
    if (!inventory.interact(held, action)) fail("useItem $item", "could not issue '$action'")
    park(1000)
    return true
}

/** Read a held item (a quest book / diary / letter). No-op if not held. */
suspend fun ScriptScope.read(item: Int): Boolean = useItem(item, "Read")

/** Combine two inventory items (use A on B). No-op if either isn't held. */
suspend fun ScriptScope.combine(itemA: Int, itemB: Int): Boolean {
    val a = inventory.getItem(itemA) ?: return true
    val b = inventory.getItem(itemB) ?: return true
    if (!inventory.combine(a, b)) fail("combine $itemA + $itemB", "could not issue the use")
    park(1200)
    return true
}

/** Give NPC [npcName] each of [items] you're still holding (use item → NPC). Idempotent. */
suspend fun ScriptScope.give(npcName: String, vararg items: Int): Boolean {
    for (id in items) if (id in inventory) {
        useOn(id, npcName); park(600)
    }
    return true
}

/**
 * Obtain [item] and BLOCK until it's in the inventory: search container [from], or — with no [from] — pick it
 * up as a ground/table item spawn (web-walking to [at] first in either case). No-op if already held; the item
 * landing in the inventory is the ONLY success condition, so a following action can rely on holding it —
 * throws [QuestActionFailed] on timeout instead of falling through.
 */
suspend fun ScriptScope.take(item: Int, from: String? = null, at: Tile? = null, timeoutMs: Long = 60_000): Boolean {
    if (item in inventory) return true
    var lastClick = 0L
    var issued = false   // once the Search/Take actually lands, stop re-clicking and just wait for the item
    val got = waitUntil(timeoutMs, pollMs = 800) {
        if (item in inventory) return@waitUntil true
        if (from != null) {
            val obj = findObject(from, at)
            val loc = obj?.tile()
            when {
                // Only search the container once genuinely path-reachable; else web-walk in (opening doors).
                obj != null && loc != null -> if (!issued && reachableElseStep(loc) && shouldClick(lastClick)) {
                    if (obj.interactPrecise(obj.actions().firstOrNull { it in TAKE_ACTIONS } ?: "Search")) issued = true
                    lastClick = nowMs()
                }

                at != null -> webWalking.walkTo(at) // not in scene yet → get closer
            }
        } else {
            // No container: the item is a ground/table spawn — "Take" it once genuinely path-reachable.
            val gi = groundItems.closest(item)
            val loc = gi?.tile()
            when {
                gi != null && loc != null -> if (!issued && reachableElseStep(loc) && shouldClick(lastClick)) {
                    if (gi.interactPrecise("Take")) issued = true
                    lastClick = nowMs()
                }

                at != null -> webWalking.walkTo(at) // spawn not in scene yet → get closer
            }
        }
        false
    }
    if (!got) fail("take $item" + (from?.let { " from '$it'" } ?: ""), "not in inventory after ${timeoutMs}ms")
    return true
}

private val TAKE_ACTIONS = setOf("Search", "Take", "Open", "Loot", "Take-from")

/** Wear each of [items] and CONFIRM it's equipped. Throws if an item is neither worn nor held, or the
 *  equip never lands — a stage must not proceed assuming gear that isn't on (gas mask, anti-dragon shield). */
suspend fun ScriptScope.equipGear(vararg items: Int): Boolean {
    for (id in items) {
        if (id in equipment) continue
        if (id !in inventory) fail("equipGear $id", "neither worn nor held")
        equipment.equip(id)
        if (!waitUntil(5_000, pollMs = 400) { id in equipment }) fail("equipGear $id", "did not equip")
    }
    return true
}

/** Take off each of [items] we're wearing, confirming each removal. */
suspend fun ScriptScope.unequipGear(vararg items: Int): Boolean {
    for (id in items) {
        if (id !in equipment) continue
        equipment.unequip(id)
        if (!waitUntil(5_000, pollMs = 400) { id !in equipment }) fail("unequipGear $id", "still worn")
    }
    return true
}

/** Pick up ground item [item] (web-walking to [at] first). No-op if already held. Same contract as [take]
 *  without a container: blocks until the item is in the inventory or throws. */
suspend fun ScriptScope.loot(item: Int, at: Tile? = null, timeoutMs: Long = 60_000): Boolean =
    take(item, from = null, at = at, timeoutMs = timeoutMs)

/** Select "make all" on an open production/make interface (spinning wheel, crafting, smithing, …) and wait for
 *  it to finish (the make animation ends). Throws if no make interface opens or the making never finishes. */
suspend fun ScriptScope.makeAll(timeoutMs: Long = 90_000): Boolean {
    if (!waitUntil(6_000, pollMs = 300) { dialogues.makeOpen() }) fail("makeAll", "make interface never opened")
    dialogues.makeQuantity(all = true)
    park(1500) // let the make animation start before we watch for it to stop
    if (!waitUntil(timeoutMs, pollMs = 700) { (me?.animation ?: -1) == -1 }) fail(
        "makeAll",
        "still animating after ${timeoutMs}ms"
    )
    return true
}

/** Use [material] on [tool] (a spinning wheel, loom, …) to open its make interface, then "make all". */
suspend fun ScriptScope.craftAll(material: Int, tool: String, at: Tile? = null): Boolean {
    if (material !in inventory) return true
    useOn(material, tool, at)
    return makeAll()
}

/** Perform an emote from the Emotes tab by name (some quests need one at a location). */
suspend fun ScriptScope.emote(name: String): Boolean {
    if (!emotes.perform(name)) fail("emote $name", "could not perform")
    park(1800)
    return true
}

// ---- combat & waiting ---------------------------------------------------------------------------------

/** Tuning for [kill]: which food to eat and the HP% to eat at, and an optional safespot. */
@OsrsxDsl
class KillOptions internal constructor() {
    /** Eat when hitpoints drop to/below this percent (0 = never). */
    var eatBelowHp: Int = 50

    /** Food id to eat, or -1 to auto-pick the highest-heal food held. */
    var food: Int = -1

    /** Retreat here between hits (a safespot), or null to melee. */
    var safeSpot: Tile? = null
}

/**
 * Attack NPC [name] until it's dead, eating when low. Best-effort: walks to [at], attacks, and tanks/eats
 * through the fight. Returns when the target is gone.
 */
suspend fun ScriptScope.kill(name: String, at: Tile? = null, block: KillOptions.() -> Unit = {}): Boolean {
    val opts = KillOptions().apply(block)
    opts.safeSpot?.let { walkTo(it) } ?: at?.let { if (npcs.closest(name) == null) walkTo(it) }
    val deadline = nowMs() + 180_000
    while (nowMs() < deadline && !isStopping) {
        eatIfLow(opts.eatBelowHp, opts.food)
        val target = npcs.closest { it.name().equals(name, ignoreCase = true) && !it.isDead }
        if (target == null) {
            if (!isFighting()) return true else {
                park(600); continue
            }
        }
        if (!isFighting()) combat.attack(target)
        park(1000)
    }
    if (!isStopping && npcs.closest(name) != null) fail("kill $name", "still alive at the 180s deadline")
    return true
}

private fun ScriptScope.isFighting(): Boolean = combat.isInCombat() || (me?.animation ?: -1) != -1

/** Eat the highest-heal held food (or [food]) when hitpoints are at/below [thresholdPct]. Skips quest-only foods only if [food] is set. */
suspend fun ScriptScope.eatIfLow(thresholdPct: Int, food: Int = -1): Boolean {
    if (thresholdPct <= 0) return false
    if (skills.hitpointsPercent() !in 1..thresholdPct) return false
    val item = if (food > 0) inventory.getItem(food)
    else inventory.items().firstOrNull { it.actions.any { a -> a.equals("Eat", ignoreCase = true) } }
    item ?: return false
    inventory.interact(item, "Eat"); park(600)
    return true
}

/** Suspend until the active cutscene ends (throws if it never does). */
suspend fun ScriptScope.waitForCutscene(timeoutMs: Long = 120_000): Boolean {
    waitUntil(10_000, pollMs = 300) { varps.varbit(Varbits.CUTSCENE_STATUS) == 1 }   // give it a moment to start
    if (!waitWhile(timeoutMs, pollMs = 600) { varps.varbit(Varbits.CUTSCENE_STATUS) == 1 })
        fail("waitForCutscene", "cutscene still active after ${timeoutMs}ms")
    return true
}

// ---- internal: centralized approach -------------------------------------------------------------------

/**
 * Gate for the poll-driven actions' (re)clicks: true when a fresh click should be issued NOW. The first call
 * (lastIssueMs == 0) always fires; after that the click is re-issued only once [cooldownMs] has passed AND we
 * look idle (not walking, not animating) — the game still acting on the previous click (running to the door,
 * playing the pickup animation) is not a reason to click it again. Callers stamp `nowMs()` back into their
 * lastIssue var on each fire.
 */
private fun ScriptScope.shouldClick(lastIssueMs: Long, cooldownMs: Long = 4_000): Boolean {
    if (lastIssueMs == 0L) return true
    if (nowMs() - lastIssueMs < cooldownMs) return false
    return me?.isMoving != true && (me?.animation ?: -1) == -1
}

/**
 * Reachable to interact under the LIVE scene collision? If not, take a web-walk step toward a standable
 * interact tile (the walker opens doors en route) and return false so the caller keeps polling. Shared by the
 * poll-driven gatherers ([take]/[loot]) so, like [approach], they never fire an interaction through a closed
 * door (which would strand us on the wrong side, clicking a container/ground item we can't actually reach).
 */
private fun ScriptScope.reachableElseStep(loc: Tile): Boolean {
    if (walking.canReachToInteract(loc)) return true
    webWalking.walkTo(interactStepToward(loc, me?.tile()))
    return false
}

/**
 * The stand tile to web-walk to in order to interact with the object at [loc]. Among the object's
 * interact tiles, prefer one on OUR side of any barrier — reachable under the LIVE scene collision from
 * [from] — over the geometrically-nearest, which for a door sits ACROSS the very crossing we're
 * approaching (the walker could only reach it by first opening the gated door, so its route "has no
 * path" and we'd stall forever web-walking at a tile we can't get to). Falls back to the nearest
 * interact tile when none is locally reachable yet (still far / out of scene) or [from] is unknown.
 */
private fun ScriptScope.interactStepToward(loc: Tile, from: Tile?): Tile {
    val candidates = walking.interactTiles(loc)
    if (candidates.isEmpty()) return loc
    val pool = from?.let { walking.walkReachable(it, candidates, 96) }?.ifEmpty { candidates } ?: candidates
    return pool.minByOrNull { t -> from?.distanceTo(t) ?: Int.MAX_VALUE } ?: loc
}

/** Nearest scene object named [name] (nearest to [at] if given), or null. */
internal fun ScriptScope.findObject(name: String, at: Tile?): SceneObject? =
    if (at != null) objects.all { it.name()?.equals(name, ignoreCase = true) == true }
        .minByOrNull { it.tile()?.distanceTo(at) ?: Int.MAX_VALUE }
    else objects.closest(name)

/**
 * The NPC to talk to for the quest name [name]. With [at], the matching NPC **nearest to `at`** — NOT the one
 * closest to the player, which for a duplicated name ("Mourner") talks to the wrong one across the room after a
 * preceding step moved us. Without [at], nearest to the player: an EXACT match first, else the nearest NPC that
 * carries [name] as **whole word(s)** (so `talkTo("Martha")` finds "Martha Rehnison", `talkTo("Bravek")` a
 * titled NPC). Whole-word (space-bounded) so "Man" never matches "Mangler".
 */
internal fun ScriptScope.findNpc(name: String, at: Tile? = null): io.osrsx.api.Npc? {
    val needle = " ${name.trim().lowercase()} "
    val matches: (io.osrsx.api.Npc) -> Boolean = { npc ->
        npc.name()?.let { it.equals(name, ignoreCase = true) || " ${it.lowercase()} ".contains(needle) } == true
    }
    if (at != null) return npcs.all(matches).minByOrNull { it.tile()?.distanceTo(at) ?: Int.MAX_VALUE }
    npcs.closest(name)?.let { return it }
    return npcs.closest(matches)
}

/** How near [approach] must get to a known target location [at] before it starts matching the target by name —
 *  scene entities aren't loaded until we're roughly this close, so querying earlier finds only the wrong
 *  same-named entities we pass en route. ~10 tiles sits comfortably inside the loaded-scene radius. */
private const val APPROACH_QUERY_RANGE = 10

/**
 * Web-walk to object/NPC [name] until it's reachable to interact, and return it (throws [QuestActionFailed]
 * on timeout — the caller always gets a genuinely-reachable target back).
 * Reachability is decided by the LIVE scene collision ([Walking.canReachToInteract]) — an A* over the loaded
 * scene flags — **never** by geometric distance, which is fooled into "reachable" straight through a shut
 * door (that stranded a bot outside a building: it opened a door then clicked the NPC behind it before the
 * crossing landed). Handles non-unique ids (nearest to [at]) and unstandable tiles (routes to a standable
 * interact tile — the web walker opens doors en route).
 *
 * [requirePath] defaults true (an NPC, an item, any object you walk up to): ONLY a genuine live-collision
 * path counts, so NOTHING is clicked through a closed door — the walker opens the door and arrives first.
 * Pass false ONLY for a barrier we operate directly (a door via [open], a wall via [push]/[interact]
 * `direct`): then standing adjacent also counts, because the barrier's own wall edge makes
 * [Walking.canReachToInteract] reject it.
 */
internal suspend fun ScriptScope.approach(name: String, at: Tile?, requirePath: Boolean = true): Interactable {
    var found: Interactable? = null
    // No wall-clock cap on the WALK itself: a valid web-walk path always completes, so timing out mid-trek just
    // false-fails a legitimate long journey (a curator→examiner run exceeds a minute). The generous bound only
    // backstops the truly-unresolvable case — target never spawns, or no route exists at all — so we can't poll
    // forever; the walker keeps us moving the whole time otherwise.
    val reached = waitUntil(600_000, pollMs = 700) {
        // When we know WHERE the target is, web-walk to within range of [at] BEFORE querying by name. Far out,
        // the target itself often isn't loaded yet, so the only same-named match in scene is the wrong one we're
        // passing (a street "Mourner"), which we'd then chase. Only once near [at] is the real target loaded and
        // nearest-to-[at] correct. (No [at] ⇒ nearest-to-us, as before.)
        val meNow = me?.tile()
        if (at != null && (meNow == null || meNow.distanceTo(at) > APPROACH_QUERY_RANGE)) {
            webWalking.walkTo(at); return@waitUntil false
        }
        val target: Interactable? = findObject(name, at) ?: findNpc(name, at)
        found = target
        if (target == null) {
            if (at != null) webWalking.walkTo(at); return@waitUntil false
        }
        val loc = (target as? SceneEntity)?.tile() ?: return@waitUntil true
        when {
            walking.canReachToInteract(loc) -> true
            !requirePath && meNow != null && meNow.distanceTo(loc) <= 1 -> true // adjacent to a barrier we operate directly
            else -> {
                webWalking.walkTo(interactStepToward(loc, meNow))
                false
            }
        }
    }
    val target = found
    if (!reached || target == null) fail(
        "approach '$name'" + (at?.let { " near $it" } ?: ""),
        if (target == null) "never appeared in the scene" else "no live-collision path to it",
    )
    return target
}
