package io.osrsx.plugin

import io.osrsx.api.Tile
import java.awt.Graphics2D
import java.awt.Point
import java.awt.Polygon

/**
 * A per-frame drawing surface for a [HasSceneOverlay] plugin — world-projected graphics painted OVER the
 * game scene (below the editor UI). Handed to [HasSceneOverlay.onSceneRender] each frame on the render
 * thread; keep the callback quick and read-only.
 *
 * Two coordinate spaces, mirroring the engine's own overlay toolkit:
 *  - **World space** ([drawTile]/[fillTile]/[line]/[dot]/[drawText]) — you give world [Tile]s and the
 *    surface projects them to the canvas for you (no RuneLite perspective math). This is what path/route,
 *    tile-highlight and boss-geometry overlays use.
 *  - **Screen space** ([screenLine]/[rect]/[fillRect]/[screenText], and the raw [graphics]) — canvas
 *    pixels, for HUD-style bits or anything already projected via [toScreen]/[projectLocal].
 *
 * All colours are packed **ARGB** ints (e.g. `0x80FF0000` = half-transparent red).
 */
interface SceneGraphics {

    /** The raw AWT canvas graphics, positioned over the game scene (canvas-pixel screen space). */
    val graphics: Graphics2D

    /** The local player's world tile this frame, or null if unavailable — the usual anchor for path draws. */
    fun playerTile(): Tile?

    // ---- projection ----

    /** The on-screen quad of world [tile], or null when it's off-screen. */
    fun tilePoly(tile: Tile): Polygon?

    /** The on-screen centre point of world [tile], or null when it's off-screen. */
    fun toScreen(tile: Tile): Point?

    /** Project a fine scene-local point (128 units = 1 tile, as returned by [io.osrsx.api.Npc.localPoint])
     *  to canvas pixels, or null when off-screen — for sub-tile viz (e.g. a moving boss's predicted spot). */
    fun projectLocal(localX: Int, localY: Int): Point?

    // ---- world space ----

    /** Outline [tile]'s on-screen polygon in [argb] at [strokeWidth]. */
    fun drawTile(tile: Tile, argb: Int, strokeWidth: Float = 2f)

    /** Fill [tile]'s on-screen polygon with [argb]. */
    fun fillTile(tile: Tile, argb: Int)

    /** A line between the on-screen centres of world tiles [a] and [b]. */
    fun line(a: Tile, b: Tile, argb: Int, strokeWidth: Float = 2f)

    /** A filled dot at world [tile]'s on-screen centre. */
    fun dot(tile: Tile, radius: Float, argb: Int)

    /** Draw [text] centred on [tile] in [argb]. */
    fun drawText(tile: Tile, text: String, argb: Int)

    // ---- screen space ----

    /** A line in canvas pixels. */
    fun screenLine(x1: Int, y1: Int, x2: Int, y2: Int, argb: Int, strokeWidth: Float = 1f)

    /** An outlined rectangle in canvas pixels. */
    fun rect(x: Int, y: Int, w: Int, h: Int, argb: Int, strokeWidth: Float = 1f)

    /** A filled rectangle in canvas pixels. */
    fun fillRect(x: Int, y: Int, w: Int, h: Int, argb: Int)

    /** [text] at canvas pixel (`x`, `y`). */
    fun screenText(text: String, x: Int, y: Int, argb: Int)
}
