package io.osrsx.plugin

/**
 * A plugin capability: draw **world-projected** graphics over the game scene each frame — tile highlights,
 * labels, paths, debug geometry. The engine registers/removes an above-scene overlay for a [Plugin] that
 * implements this on enable/disable (no manual `ctx.overlays()` wiring), and hands [onSceneRender] a
 * [SceneGraphics] that projects world [io.osrsx.api.Tile]s to the canvas for you.
 *
 * This is the in-world counterpart to [HasOverlay]/[HasPaint] (which draw ImGui windows, not world-space
 * graphics). It runs on the render thread — keep it quick and read-only; draw nothing to hide for a frame.
 */
interface HasSceneOverlay {
    /** Paint this plugin's world-space overlay for one frame via [scene]. */
    fun onSceneRender(scene: SceneGraphics)
}
