package io.osrsx.api


/**
 * Observability + configuration types for the [WebWalker]. A walk emits a stream of [WalkEvent]s to
 * registered [WalkListener]s and keeps a pollable [WalkState] snapshot; [WalkConfig] shapes how the
 * route is planned and executed.
 */

/** Coarse phase of an in-progress web walk (pollable via [WebWalker.state]). */
enum class WalkPhase { IDLE, PLANNING, WALKING, TAKING_TRANSPORT, BANKING, STUCK, ARRIVED, FAILED }

/**
 * The family a transport edge belongs to — used for config gating and event reporting. Covers every
 * transport category present in the osrsx dataset (the source TSVs: agility shortcuts, boats/canoes,
 * charter ships, fairy rings, gnome gliders, hot-air balloons, magic carpets, mushtrees, minecarts,
 * quetzals, spirit trees, teleport items/spells, wilderness obelisks, …). [TRAVERSAL] (doors, gates,
 * stairs, ladders, tunnels) and [AGILITY_SHORTCUT] are "on-foot" — they are kept out of [FAST_TRAVEL]
 * so a walk-only configuration still opens doors and uses shortcuts. [OTHER] is any hub-travel edge we
 * couldn't classify yet.
 */
enum class TransportKind {
    TRAVERSAL,
    AGILITY_SHORTCUT,
    BOAT,
    CHARTER_SHIP,
    TELEPORT_ITEM,
    TELEPORT_SPELL,
    FAIRY_RING,
    SPIRIT_TREE,
    GNOME_GLIDER,
    HOT_AIR_BALLOON,
    MAGIC_CARPET,
    MUSHTREE,
    MINECART,
    QUETZAL,
    WILDERNESS_OBELISK,
    MINIGAME_TELEPORT,
    OTHER;

    companion object {
        /** Every non-on-foot family — everything except [TRAVERSAL] and [AGILITY_SHORTCUT]. */
        val FAST_TRAVEL: Set<TransportKind> get() = entries.toSet() - TRAVERSAL - AGILITY_SHORTCUT
        /** Teleport families (item tabs/jewellery + spells + minigame-group teleports). */
        val TELEPORTS: Set<TransportKind> get() = setOf(TELEPORT_ITEM, TELEPORT_SPELL, MINIGAME_TELEPORT)
    }
}

/** A transport/teleport on a planned or taken route, in API-level terms (no engine internals leaked). */
data class WalkTransport(
    val name: String,
    val from: Tile?,
    val to: Tile,
    val kind: TransportKind,
)

/**
 * Something that happened during a walk. Delivered to every registered [WalkListener] and reflected in
 * [WebWalker.state]. All the walker's former diagnostics (selected path, took transport, unreachable,
 * stuck, bank detour, …) surface here.
 */
sealed interface WalkEvent {
    /** The destination this walk is heading to. */
    val dest: Tile

    /** A walk to [dest] began from [from]. */
    data class Started(override val dest: Tile, val from: Tile) : WalkEvent
    /** A route was planned: [walkLegs] walking legs and the ordered [transports] it will take. */
    data class PathPlanned(override val dest: Tile, val walkLegs: Int, val transports: List<WalkTransport>) : WalkEvent
    /** Now heading to the next local waypoint [target]. */
    data class Stepping(override val dest: Tile, val target: Tile) : WalkEvent
    /** A transport/teleport was taken. */
    data class TransportTaken(override val dest: Tile, val transport: WalkTransport) : WalkEvent
    /** Movement stalled at [at] ([reason] describes why — e.g. a blocked path or unreachable waypoint). */
    data class Stuck(override val dest: Tile, val at: Tile, val reason: String) : WalkEvent
    /** No route to [dest] could be found ([diagnosis] from the pathfinder). */
    data class Unreachable(override val dest: Tile, val diagnosis: String) : WalkEvent
    /** Detouring to [bank] to obtain [needs] (items/coins a transport on the route requires). */
    data class BankDetour(override val dest: Tile, val bank: Tile, val needs: List<String>) : WalkEvent
    /** A generic diagnostic message (kept for parity with the debug logging). */
    data class Info(override val dest: Tile, val message: String) : WalkEvent
    /** Arrived at [dest]. */
    data class Arrived(override val dest: Tile) : WalkEvent
    /** The walk gave up ([reason] explains — e.g. a non-bankable requirement, or bank runs disabled). */
    data class Failed(override val dest: Tile, val reason: String) : WalkEvent
}

/** Receives [WalkEvent]s. Functional so callers can pass a lambda. */
fun interface WalkListener {
    fun onEvent(event: WalkEvent)
}

/** An immutable snapshot of the walker's state — safe to read from any thread, any time. */
data class WalkState(
    val phase: WalkPhase,
    val destination: Tile?,
    /** The local waypoint currently being walked to, if any. */
    val target: Tile?,
    /** Transports the active plan will take (in order). */
    val plannedTransports: List<WalkTransport>,
    /** Number of walking legs in the active plan (a route can have legs but no transports). */
    val plannedLegs: Int,
    /** The most recently taken transport, if any. */
    val lastTransport: WalkTransport?,
    /** The most recent event. */
    val lastEvent: WalkEvent?,
    /** A short human-readable status line. */
    val message: String,
) {
    companion object {
        val IDLE = WalkState(WalkPhase.IDLE, null, null, emptyList(), 0, null, null, "idle")
    }
}

/** When the walker should turn run on. */
sealed interface RunPolicy {
    /** The default humanised model: drain to ~0, re-enable at a varied energy, occasional early stop. */
    object Humanized : RunPolicy
    /** Run whenever any energy is available. */
    object Always : RunPolicy
    /** Never run. */
    object Never : RunPolicy
    /** Enable run once energy is at least [percent]. */
    data class AboveEnergy(val percent: Int) : RunPolicy
}

/**
 * Ranking = the routing COST assigned to each transport; the pathfinder measures it against walking at 1
 * per tile, so a lower cost means "more preferred". Everything is rankable, at three precedence levels
 * (first match wins):
 *  1. [transportCost] — an exact per-transport cost by name (case-insensitive substring). Highest control.
 *  2. [kindCost] — a per-family cost override (e.g. make all fairy rings cheap, or all boats expensive).
 *  3. the teleport floors — [teleportMinCost] for normal teleports, [homeTeleportCost] for home teleports
 *     (their long cooldown makes them a last resort). These are FLOORS (`max(baked, floor)`), not overrides.
 * A transport matched by none keeps its data-baked cost. [PREFER]/[AVOID] are handy sentinel costs the DSL's
 * `prefer()`/`avoid()` verbs use.
 */
data class RankingConfig(
    /** Tiles a normal teleport must save to be chosen (a floor). Low → prefer teleporting. */
    val teleportMinCost: Int = 20,
    /** Cost floor for "Home Teleport" transports — high, because of their ~30-min cooldown. */
    val homeTeleportCost: Int = 1000,
    /** Per-family cost override (routing cost for every transport of that [TransportKind]). */
    val kindCost: Map<TransportKind, Int> = emptyMap(),
    /** Per-transport cost override by name (case-insensitive substring) — beats [kindCost]. */
    val transportCost: Map<String, Int> = emptyMap(),
) {
    companion object {
        /** Sentinel cost for `prefer()` — cheaper than almost any walk, so it's taken whenever available. */
        const val PREFER = 2
        /** Sentinel cost for `avoid()` — high, so it's only used when nothing cheaper reaches the goal. */
        const val AVOID = 500
    }
}

/** Bank/GE detour tuning: how the walker reroutes to obtain something a transport needs. */
data class DetourConfig(
    /** Max distinct banks probed for reachability before giving up on a bank detour. */
    val maxBanksProbed: Int = 8,
    /** Per-candidate-bank pathfind budget (ms) when picking a reachable bank. */
    val bankProbeMs: Long = 2000,
    /** Local path longer than the direct line × this (+ [localDetourSlack]) → hand off to the global plan. */
    val localDetourFactor: Int = 2,
    /** Tiles of slack on top of [localDetourFactor], so short obstacle weaves still walk locally. */
    val localDetourSlack: Int = 10,
)

/** Anti-bounce, retry and cooldown tuning: when a transport is vetoed or excluded after trouble. */
data class ExclusionConfig(
    /** After crossing, how long the reverse/same twin transport is vetoed (anti-bounce), in ms. */
    val reverseCooldownMs: Long = 6000,
    /** Consecutive failed takes before a transport is excluded and the route replans. */
    val transportFailLimit: Int = 3,
    /** Consecutive "interacted but never arrived" misses before a transport is excluded. */
    val crossMissLimit: Int = 3,
    /** How long an excluded (broken/blocked) transport stays out of planning, in ms. */
    val transportExcludeMs: Long = 20_000,
    /** Home-teleport family cooldown after use (excluded for this long), in ms. */
    val homeTeleportCooldownMs: Long = 30 * 60_000L,
    /** Minigame-teleport family cooldown after use, in ms. */
    val minigameTeleportCooldownMs: Long = 20 * 60_000L,
)

/** Pathfinding budgets and the radii that decide "close enough" during the on-screen follow. */
data class PathfindingConfig(
    /** Chebyshev distance to a transport origin that counts as "at origin, take it". */
    val nearRadius: Int = 2,
    /** Chebyshev distance to a walk waypoint that counts as reached. */
    val waypointArriveRadius: Int = 3,
    /** How far the safety-net will walk to a blocking gate's origin to cross it. */
    val approachRadius: Int = 16,
    /** Max range to consider taking an off-plan agility/door shortcut (~half a loaded scene). */
    val shortcutReach: Int = 52,
    /** Budget (ms) for tight reachability probes that scan many tiles. */
    val reachProbeMs: Long = 3000,
    /** Fallback A* budget (ms) for secondary searches (bank detour, far-side traces) with no explicit limit. */
    val searchBudgetMs: Long = 6000,
)

/**
 * Interaction timing for taking a transport — how long to wait for gates to open, crossings/teleports to
 * confirm, and the camera to stand down. These shape reliability + humanisation; raise them on a laggy
 * connection, lower them for snappier (but riskier) takes. NOT the local click humaniser (that is separate).
 */
data class TimingConfig(
    /** Extra open/cross wait added per tile of approach when interacting from a distance, in ms. */
    val approachMsPerTile: Long = 350,
    /** Base wait for a gate to open after the action, in ms. */
    val openBaseMs: Long = 2000,
    /** Base wait to confirm arrival on the far side of a crossing, in ms. */
    val crossConfirmMs: Long = 5000,
    /** Wait for a teleport channel to complete before confirming arrival, in ms. */
    val teleportConfirmMs: Long = 9000,
    /** Land within this many tiles of a teleport's destination to count it as taken. */
    val teleportArriveRadius: Int = 12,
)

/**
 * Economy-aware routing: when a transport needs an item the player lacks in inventory AND bank, but which
 * is tradeable and affordable, the walker can detour to the Grand Exchange to buy it — withdrawing the
 * coins from the GE's OWN bank (no separate coin-bank trip; a non-GE bank is only visited when it holds an
 * item that gets us to the GE faster, which the normal bank-detour already handles) — before continuing.
 * Only taken when the whole detour is CLEARLY faster than walking. Gated by [WalkConfig.allowGrandExchange];
 * these tune the money side.
 */
data class EconomyConfig(
    /** A detour to acquire a transport (bank/GE) is chosen over walking only when it beats the direct walk
     *  by at least this many tiles of cost. Higher = more conservative (only detour when clearly faster). */
    val detourMargin: Int = 30,
    /** How far over market price to bid when buying at the GE, so offers fill promptly (percent). */
    val gePriceMarkupPercent: Int = 10,
    /** Absolute cap: max coins to spend buying a SINGLE transport item at the GE (0 = no cap). A safety rail
     *  against a mispriced/expensive item draining the account. */
    val maxGeSpendPerItem: Int = 50_000,
    /** Relative cap: never spend more than this PERCENT of total account coins (bank + inventory) on a
     *  single transport buy. Blocks e.g. a 100k tab when the account only has 200k. (0 = no relative cap.) */
    val maxGeSpendPercentOfCoins: Int = 10,
) {
    /** Whether spending [cost] coins on one transport item is allowed, given [totalCoins] the account holds:
     *  affordable AND within both the absolute ([maxGeSpendPerItem]) and relative ([maxGeSpendPercentOfCoins])
     *  caps. Zero caps disable that check. */
    fun canSpend(cost: Int, totalCoins: Int): Boolean {
        if (cost > totalCoins) return false
        if (maxGeSpendPerItem > 0 && cost > maxGeSpendPerItem) return false
        if (maxGeSpendPercentOfCoins > 0 && cost.toLong() * 100 > totalCoins.toLong() * maxGeSpendPercentOfCoins) return false
        return true
    }
}

/**
 * Highly customizable configuration for a web walk. Defaults reproduce today's behaviour: every transport
 * allowed, humanised run, bank detours on, GE buying off, no stamina potions. Build one directly with
 * `copy(...)`, pick a companion preset ([DEFAULT], [WALK_ONLY], [NO_TELEPORTS], [FASTEST], [FRUGAL]), or use
 * the [walkConfig] builder DSL. Rarely-tuned knobs are grouped into sub-configs ([ranking], [detour],
 * [exclusion], [pathfinding], [timing], [economy]) so the common fields stay at the top level.
 *
 * Transport gating is layered, evaluated per transport in this PRECEDENCE (first match wins). All name
 * matching is case-insensitive substring (so `"Home"` matches `"Lumbridge Home Teleport"`):
 *  1. name matches [blacklistedTransports] → DENY (a force-deny beats everything),
 *  2. name matches [forceAllowTransports] → ALLOW (re-enables a specific transport even if its whole
 *     [TransportKind] is disabled — this is how a family block's `include("Castle Wars")` works),
 *  3. its [TransportKind] is in [disabledKinds] → DENY (TRAVERSAL is never disabled, so basic walking
 *     never breaks),
 *  4. if [allowedTransports] is non-empty and the name matches none → DENY (global whitelist),
 *  5. otherwise → ALLOW.
 *
 * Prefer the [walkConfig] DSL's family blocks (`teleports { none(); include("Varrock") }`,
 * `minigames { include("Castle Wars") }`, …) over setting these sets by hand. Helper sets like
 * [TransportKind.FAST_TRAVEL] and [TransportKind.TELEPORTS] make common cases terse; presets
 * [WalkConfig.WALK_ONLY]/[NO_TELEPORTS]/[FASTEST]/[FRUGAL] cover the usual shapes.
 */
data class WalkConfig(
    /** Whole transport families to exclude (see [TransportKind]). TRAVERSAL is always kept. */
    val disabledKinds: Set<TransportKind> = emptySet(),
    /** Force-deny: transport names (case-insensitive substring) never used, beating every other rule. */
    val blacklistedTransports: Set<String> = emptySet(),
    /** Force-allow: transport names (case-insensitive substring) allowed even if their [TransportKind] is
     *  in [disabledKinds] — the DSL's per-family `include(...)` populates this. */
    val forceAllowTransports: Set<String> = emptySet(),
    /** If non-empty, the ONLY non-traversal transports allowed (by name, case-insensitive substring). */
    val allowedTransports: Set<String> = emptySet(),
    /** May the walker route through farmable/planted spirit-tree patches (off by default — a player's own
     *  planted trees vary; enabling assumes the configured patches are grown). */
    val allowPlantedSpiritTrees: Boolean = false,
    /** Detour to a bank to withdraw items/coins a transport on the route needs. */
    val allowBankRuns: Boolean = true,
    /** Buy missing items at the Grand Exchange (reserved — not yet implemented; emits an info event). */
    val allowGrandExchange: Boolean = false,
    /** Drink stamina/energy potions when run energy is low. */
    val useStaminaPotions: Boolean = false,
    /** Run-energy percent at/below which a stamina/energy potion is drunk (when [useStaminaPotions]). */
    val staminaThreshold: Int = 20,
    /** When to enable run. */
    val runPolicy: RunPolicy = RunPolicy.Humanized,
    /** Per-search pathfinding budget for the MAIN route search (ms). Secondary searches use
     *  [PathfindingConfig.searchBudgetMs] / [PathfindingConfig.reachProbeMs]. */
    val pathfindTimeoutMs: Long = 5000,
    /** If the exact destination tile is unreachable (walled off), accept arriving at the nearest reachable
     *  tile within this many tiles instead of failing. 0 = require the exact tile (today's behaviour). */
    val arriveRadius: Int = 0,
    /** Teleport-vs-walk ranking. */
    val ranking: RankingConfig = RankingConfig(),
    /** Bank/GE detour tuning. */
    val detour: DetourConfig = DetourConfig(),
    /** Anti-bounce / retry / cooldown tuning. */
    val exclusion: ExclusionConfig = ExclusionConfig(),
    /** Pathfinding budgets + follow radii. */
    val pathfinding: PathfindingConfig = PathfindingConfig(),
    /** Transport interaction timing. */
    val timing: TimingConfig = TimingConfig(),
    /** Economy-aware detour tuning (bank/GE buying); only active when [allowGrandExchange] is on. */
    val economy: EconomyConfig = EconomyConfig(),
) {
    /** True when [kind] is permitted (TRAVERSAL is always permitted). Kind-only — prefer [permits] which
     *  also honours the name-level force-deny/force-allow/whitelist rules. */
    fun allows(kind: TransportKind): Boolean = kind == TransportKind.TRAVERSAL || kind !in disabledKinds

    /**
     * Whether a transport named [name] of family [kind] is permitted, applying the full gating precedence
     * documented on this class (force-deny → force-allow → disabled-kind → whitelist → allow). TRAVERSAL is
     * always permitted. Name matching is case-insensitive substring.
     */
    fun permits(name: String, kind: TransportKind): Boolean {
        if (kind == TransportKind.TRAVERSAL) return true
        if (blacklistedTransports.any { name.contains(it, ignoreCase = true) }) return false
        if (forceAllowTransports.any { name.contains(it, ignoreCase = true) }) return true
        if (kind in disabledKinds) return false
        if (allowedTransports.isNotEmpty() && allowedTransports.none { name.contains(it, ignoreCase = true) }) return false
        return true
    }

    companion object {
        /** Balanced defaults — every transport allowed, humanised run, bank detours on, GE off. */
        val DEFAULT = WalkConfig()
        /** Walk on foot only — no fast travel (doors/gates/stairs + agility shortcuts still used). */
        val WALK_ONLY = WalkConfig(disabledKinds = TransportKind.FAST_TRAVEL)
        /** No teleport items or spells (boats, fairy rings, etc. still allowed). */
        val NO_TELEPORTS = WalkConfig(disabledKinds = TransportKind.TELEPORTS)
        /** Get there fastest — aggressively prefer teleports (tiny floor) and allow every fast-travel family. */
        val FASTEST = WalkConfig(ranking = RankingConfig(teleportMinCost = 1, homeTeleportCost = 300))
        /** Conserve consumables — walk unless a teleport saves a lot; still uses free travel (boats, fairy
         *  rings, shortcuts) and only teleports on long hauls. */
        val FRUGAL = WalkConfig(ranking = RankingConfig(teleportMinCost = 150))
    }
}
