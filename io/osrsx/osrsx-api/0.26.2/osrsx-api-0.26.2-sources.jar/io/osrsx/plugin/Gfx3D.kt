package io.osrsx.plugin

import io.osrsx.api.Interactable
import io.osrsx.api.Tile
import io.osrsx.api.packArgb
import java.awt.Color
import java.awt.Graphics2D
import java.awt.Point
import java.awt.Polygon

/**
 * The 3D drawing surface a plugin draws through — world-projected graphics painted OVER the game scene
 * (below the editor UI). Handed to [HasOverlay.onOverlay] each frame on the render thread; keep the callback
 * quick and read-only.
 *
 * Two coordinate spaces, mirroring the engine's own overlay toolkit:
 *  - **World space** ([drawTile]/[fillTile]/[line]/[dot]/[drawText]) — you give world [Tile]s and the
 *    surface projects them to the canvas for you (no RuneLite perspective math). This is what path/route,
 *    tile-highlight and boss-geometry overlays use.
 *  - **Screen space** ([screenLine]/[rect]/[fillRect]/[screenText], and the raw [graphics]) — canvas
 *    pixels, for HUD-style bits or anything already projected via [toScreen]/[projectLocal].
 *
 * Every colour is a packed **`0xAARRGGBB` int** (e.g. `0x80FF0000` = half-transparent red); each
 * colour-taking method also offers float-component and [java.awt.Color] overloads (see [io.osrsx.api.packArgb])
 * that funnel through the single `Int`-ARGB method.
 *
 * The retained, animated [io.osrsx.api.Highlights] service is built on top of these same primitives; use
 * [highlightTile]/[outlineTile] for a one-frame styled marker, or `ctx.highlights()` for a persistent one.
 */
interface Gfx3D {

    /** The raw AWT canvas graphics, positioned over the game scene (canvas-pixel screen space). */
    val graphics: Graphics2D

    /** The local player's world tile this frame, or null if unavailable — the usual anchor for path draws. */
    fun playerTile(): Tile?

    // ---- projection ----

    /** The on-screen quad of world [tile], or null when it's off-screen. */
    fun tilePoly(tile: Tile): Polygon?

    /** The on-screen centre point of world [tile], or null when it's off-screen. */
    fun toScreen(tile: Tile): Point?

    /** Project a fine scene-local point (128 units = 1 tile, as returned by [io.osrsx.api.Npc.localPoint])
     *  to canvas pixels, or null when off-screen — for sub-tile viz (e.g. a moving boss's predicted spot). */
    fun projectLocal(localX: Int, localY: Int): Point?

    // ---- world space ----

    /** Outline [tile]'s on-screen polygon in [argb] at [strokeWidth]. */
    fun drawTile(tile: Tile, argb: Int, strokeWidth: Float = 2f)
    fun drawTile(tile: Tile, r: Float, g: Float, b: Float, a: Float, strokeWidth: Float = 2f): Unit = drawTile(tile, packArgb(r, g, b, a), strokeWidth)
    fun drawTile(tile: Tile, color: Color, strokeWidth: Float = 2f): Unit = drawTile(tile, color.rgb, strokeWidth)

    /** Fill [tile]'s on-screen polygon with [argb]. */
    fun fillTile(tile: Tile, argb: Int)
    fun fillTile(tile: Tile, r: Float, g: Float, b: Float, a: Float): Unit = fillTile(tile, packArgb(r, g, b, a))
    fun fillTile(tile: Tile, color: Color): Unit = fillTile(tile, color.rgb)

    /** A line between the on-screen centres of world tiles [a] and [b]. */
    fun line(a: Tile, b: Tile, argb: Int, strokeWidth: Float = 2f)
    fun line(a: Tile, b: Tile, r: Float, g: Float, bl: Float, al: Float, strokeWidth: Float = 2f): Unit = line(a, b, packArgb(r, g, bl, al), strokeWidth)
    fun line(a: Tile, b: Tile, color: Color, strokeWidth: Float = 2f): Unit = line(a, b, color.rgb, strokeWidth)

    /** A filled dot at world [tile]'s on-screen centre. */
    fun dot(tile: Tile, radius: Float, argb: Int)
    fun dot(tile: Tile, radius: Float, r: Float, g: Float, b: Float, a: Float): Unit = dot(tile, radius, packArgb(r, g, b, a))
    fun dot(tile: Tile, radius: Float, color: Color): Unit = dot(tile, radius, color.rgb)

    /** Draw [text] centred on [tile] in [argb]. */
    fun drawText(tile: Tile, text: String, argb: Int)
    fun drawText(tile: Tile, text: String, color: Color): Unit = drawText(tile, text, color.rgb)

    // ---- retained-highlight helpers (immediate, one-frame; see [io.osrsx.api.Highlights] for persistent) ----

    /** Outline [tile] in [argb] — an alias of [drawTile] for symmetry with the highlight vocabulary. */
    fun outlineTile(tile: Tile, argb: Int, strokeWidth: Float = 2f): Unit = drawTile(tile, argb, strokeWidth)

    /** Outline + translucent fill of [tile] in [argb], the default highlight look, for this frame only. */
    fun highlightTile(tile: Tile, argb: Int, strokeWidth: Float = 2f) {
        fillTile(tile, (argb and 0x00FFFFFF) or 0x33000000)
        drawTile(tile, argb, strokeWidth)
    }

    /**
     * Outline an ENTITY's actual clickable geometry — the NPC/object convex hull or ground-item
     * clickbox ([Interactable.clickbox]) — instead of just its floor tile. Reads the entity's live
     * screen shape on this frame; no-op if it isn't currently projectable (off-screen). Use to mark
     * the exact model a stage is acting on (the mob it's attacking, the loot it's grabbing).
     */
    fun drawEntity(entity: Interactable, argb: Int, strokeWidth: Float = 2f)

    /** Translucent fill of an entity's clickable geometry (see [drawEntity]). */
    fun fillEntity(entity: Interactable, argb: Int)

    /** Outline + translucent fill of an entity's geometry — the entity analogue of [highlightTile]. */
    fun highlightEntity(entity: Interactable, argb: Int, strokeWidth: Float = 2f) {
        fillEntity(entity, (argb and 0x00FFFFFF) or 0x33000000)
        drawEntity(entity, argb, strokeWidth)
    }

    // ---- screen space ----

    /** A line in canvas pixels. */
    fun screenLine(x1: Int, y1: Int, x2: Int, y2: Int, argb: Int, strokeWidth: Float = 1f)
    fun screenLine(x1: Int, y1: Int, x2: Int, y2: Int, color: Color, strokeWidth: Float = 1f): Unit = screenLine(x1, y1, x2, y2, color.rgb, strokeWidth)

    /** An outlined rectangle in canvas pixels. */
    fun rect(x: Int, y: Int, w: Int, h: Int, argb: Int, strokeWidth: Float = 1f)
    fun rect(x: Int, y: Int, w: Int, h: Int, color: Color, strokeWidth: Float = 1f): Unit = rect(x, y, w, h, color.rgb, strokeWidth)

    /** A filled rectangle in canvas pixels. */
    fun fillRect(x: Int, y: Int, w: Int, h: Int, argb: Int)
    fun fillRect(x: Int, y: Int, w: Int, h: Int, color: Color): Unit = fillRect(x, y, w, h, color.rgb)

    /** [text] at canvas pixel (`x`, `y`). */
    fun screenText(text: String, x: Int, y: Int, argb: Int)
    fun screenText(text: String, x: Int, y: Int, color: Color): Unit = screenText(text, x, y, color.rgb)
}
