package io.osrsx.api

/**
 * Immutable snapshot of the live [Sailing] plan, for overlays and debug panels. All tiles are main-world at
 * plane 0 (sea level). Rebuilt each control step; read via [Sailing.view].
 *
 * @property destination where the boat is sailing to (the active target's tile), or null when idle.
 * @property target the destination currently being navigated to (== [destination] while sailing), or null.
 * @property heading boat heading 0..15 (0=S, 4=W, 8=N, 12=E), or -1 when not aboard.
 * @property moving true when the sails are up and the boat is making way.
 * @property path the route the boat is following — the global plan, possibly with a spliced local detour.
 * @property pathIndex progress index into [path] (the boat's nearest reached waypoint).
 * @property hazards every blocked hazard tile the local tier is avoiding this step (real + injected).
 * @property hull the boat's actual multi-tile collision footprint right now.
 * @property detour the stretch of [path] currently being sailed as a LOCAL detour around a live hazard,
 *   empty when following the global plan. Lets an overlay show when the local tier has taken over.
 * @property blocked true when the local tier found a hazard ahead with no safe way around, so the boat is
 *   holding station rather than sailing into it.
 */
data class SailView(
    val destination: Tile?,
    val target: Tile?,
    val heading: Int,
    val moving: Boolean,
    val path: List<Tile>,
    val pathIndex: Int,
    val hazards: List<Tile>,
    val hull: List<Tile>,
    val detour: List<Tile> = emptyList(),
    val blocked: Boolean = false,
)
