package io.osrsx.api

/**
 * Piloted boat travel over water — the automation surface for the OSRS Sailing skill. Distinct from land
 * movement ([Walking] / [WebWalker]): you don't click tiles, you steer a multi-tile boat by HEADING and
 * SAILS, and the pathfinder must respect the hull footprint, turning radius and hazardous water.
 *
 * Event-driven, self-driving model (unlike [WebWalker]'s poll loop): call [sailTo] ONCE and the boat drives
 * itself each control step until it docks — no per-`onLoop` pump. Supply an `onArrival` callback, and/or
 * poll [arrived]; read [target] for the destination in flight. Only ONE target at a time — a new [sailTo]
 * replaces the current one. [stop] cancels navigation and clears the target.
 *
 * A GLOBAL hull-aware route is planned once, and a LOCAL tier reactively routes around dynamic hazards
 * (rocks, whirlpools, sea monsters) each step, rejoining the plan — see [addHazard] and [view].
 *
 * @since 0.x (Sailing is beta content; heading/sail actuation may need per-revision tuning).
 */
interface Sailing {
    /** Is the local player currently aboard a boat (their worldview is a boat sub-view)? */
    fun isOnBoat(): Boolean

    /** Is the player at the helm and actively navigating (self-driving toward a [target])? */
    fun isSailing(): Boolean

    /** Current boat heading, 0..15 (0=S, 4=W, 8=N, 12=E), or -1 when not aboard. */
    fun heading(): Int

    /**
     * Begin sailing to [dest], self-driving each control step until the boat docks (within tolerance).
     * A new call REPLACES the current target (there is only ever one). Planning happens on the first step.
     * Returns true if accepted (the player is aboard a boat), false otherwise.
     *
     * NOTE (behaviour change vs the earlier poll model): this returns immediately and the boat drives
     * itself — do NOT call it every `onLoop`. Use [arrived]/[target] to observe progress, or pass a
     * callback via the [sailTo] overload.
     */
    fun sailTo(dest: Tile): Boolean

    /** As [sailTo], additionally invoking [onArrival] exactly once when the boat docks at [dest]. */
    fun sailTo(dest: Tile, onArrival: () -> Unit): Boolean = sailTo(dest)

    /** The destination currently being sailed to, or null when idle. */
    fun target(): Tile? = null

    /** True when the boat has reached [dest] (within docking tolerance). */
    fun arrived(dest: Tile): Boolean

    /** Stop sailing: cancel navigation, lower sails, and clear the target and cached route. */
    fun stop()

    /** The currently planned route to [dest] as tile waypoints (for overlays), or null if none/unplannable. */
    fun route(dest: Tile): List<Tile>? = null

    /** Live snapshot of the plan for overlays/debug (route, hazards, hull, heading, target), or null when idle. */
    fun view(): SailView? = null

    /** Inject a synthetic circular hazard patch the boat must route around — for testing the local tier. */
    fun addHazard(x: Int, y: Int, radius: Int) {}

    /** Register a real hazard object id (curated identification — the local tier routes around matches). */
    fun addHazardObject(id: Int) {}

    /** Register a real hazard npc id. */
    fun addHazardNpc(id: Int) {}

    /** Register a real hazard by name pattern (matched against object/npc names, case-insensitive). */
    fun addHazardName(pattern: String) {}

    /** Drop the injected synthetic hazards (curated ids/patterns are kept). */
    fun clearHazards() {}
}
