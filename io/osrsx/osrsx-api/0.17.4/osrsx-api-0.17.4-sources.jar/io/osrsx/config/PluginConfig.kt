package io.osrsx.config

import io.osrsx.api.PluginContext
import kotlin.properties.ReadOnlyProperty
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/**
 * Base class a Java/Kotlin plugin extends to declare its settings, RuneLite-style but as Kotlin
 * property delegates. Each `xItem(...)` registers a [ConfigItem] (so the engine can render + persist
 * it) AND returns a delegate that reads/writes the live, persisted value:
 *
 * ```kotlin
 * class WoodcutterConfig : PluginConfig("woodcutter") {
 *     var dropLogs by boolItem("dropLogs", "Drop logs when full", default = true)
 *     var radius   by intItem("radius", "Search radius", default = 10, min = 1, max = 30, step = 5)
 *     var target   by stringItem("target", "Tree name", default = "Tree")
 * }
 * ```
 *
 * Reading `config.dropLogs` returns the stored value (or the default); assigning persists it. The
 * [group] namespaces the keys on disk (`<group>.properties`).
 *
 * **Conditional settings.** Any item may take a [Condition] for [ConfigItem.visibleIf] / [ConfigItem.enabledIf]
 * to show/grey it out based on other settings, with full and / or / not logic:
 *
 * ```kotlin
 * var useSpecial by boolItem("useSpecial", "Use special attack", default = false)
 * var specWeapon by itemItem("specWeapon", "Spec weapon", "Dragon dagger", visibleIf = isTrue("useSpecial"))
 * var minEnergy  by intItem("minEnergy", "Min spec energy %", 50, 0, 100, enabledIf = isTrue("useSpecial"))
 * ```
 *
 * **Auto values.** [autoItem] pairs a picker with a "use best available" toggle that greys the picker and
 * fills it from a live resolver (see [autoItem]).
 */
abstract class PluginConfig(val group: String) {
    private val _items = mutableListOf<ConfigItem>()

    /** Every declared setting, in declaration order (used by the config panel). */
    val items: List<ConfigItem> get() = _items

    private val _sectionHeights = LinkedHashMap<String, Float>()

    /** Per-section fixed pixel height (scrollable); a section absent here renders its full height. */
    val sectionHeights: Map<String, Float> get() = _sectionHeights

    /** Give a sub-[section] a fixed pixel [height] so its box scrolls; omit for a full-height section. */
    protected fun sectionHeight(section: String, height: Float) { _sectionHeights[section] = height }

    /** Bound by the plugin manager once the config group's [ConfigStore] exists. */
    var store: ConfigStore? = null

    /** Bound by the plugin manager at load so auto/dynamic resolvers can read live game state. */
    var context: PluginContext? = null

    /** Resolvers behind auto items ([autoItem] etc.), keyed by item key. Not persisted; evaluated live. */
    private val _resolvers = LinkedHashMap<String, (PluginContext) -> Any?>()

    /** Live option providers behind dynamic [enumItem]s, keyed by item key. Not persisted; evaluated live. */
    private val _optionProviders = LinkedHashMap<String, (PluginContext) -> List<String>>()

    /** Live picker allow-list providers (by **id**) behind dynamic pickers, keyed by item key. */
    private val _choiceIdProviders = LinkedHashMap<String, (PluginContext) -> List<Int>>()

    /** Repeatable-group schemas, keyed by group key, for the panel to expand into add/remove rows. */
    private val _repeatables = LinkedHashMap<String, RepeatableSpec>()

    /**
     * Resolve an auto item's current value (the "best available" pick) as a display string, or `null` if
     * [key] is not an auto item or no [context] is bound yet. Used by the config panel for the greyed value.
     */
    fun resolveAuto(key: String): String? = context?.let { ctx -> _resolvers[key]?.invoke(ctx)?.toString() }

    /**
     * The live choices for a dynamic [enumItem], or `null` if [key] has a fixed option list / no [context]
     * is bound yet. Used by the config panel to fill the dropdown from current game state.
     */
    fun dynamicOptions(key: String): List<String>? = context?.let { ctx -> _optionProviders[key]?.invoke(ctx) }

    /** Static picker allow-list for [key] (the `choices = [...]` param), or `null` if none was set. */
    fun choicesOf(key: String): List<String>? = _items.firstOrNull { it.key == key }?.choices?.takeIf { it.isNotEmpty() }

    /** The live picker allow-list (by id) for a dynamic picker [key], or `null` if none / no [context]. */
    fun dynamicChoiceIds(key: String): List<Int>? = context?.let { ctx -> _choiceIdProviders[key]?.invoke(ctx) }

    // ---- bidirectional field links ------------------------------------------------------------------

    private val _links = mutableListOf<FieldLink>()
    private var applyingLinks = false

    private class FieldLink(val a: String, val b: String, val aToB: (String) -> String?, val bToA: (String) -> String?)

    /**
     * Keep two settings **in sync both ways** via a plugin-supplied mapping: when [a] changes, [b] becomes
     * `aToB(newA)`; when [b] changes, [a] becomes `bToA(newB)` (a `null` result leaves the other untouched).
     * The engine calls [applyLinks] as the user edits, so e.g. a Woodcutter tree (object) and its logs
     * (item) track each other — pick the Willow tree and the log picker follows to Willow logs, and vice
     * versa. Reentrancy is guarded, so a change never ping-pongs.
     */
    protected fun link(a: String, b: String, aToB: (String) -> String?, bToA: (String) -> String?) {
        _links += FieldLink(a, b, aToB, bToA)
    }

    /** [link] via a name→name [map] (applied `a`→`b`; its inverse is derived for `b`→`a`). */
    protected fun link(a: String, b: String, map: Map<String, String>) {
        val inverse = map.entries.associate { (k, v) -> v to k }
        link(a, b, { map[it] }, { inverse[it] })
    }

    /**
     * Called by the engine when the user edits [changedKey]; applies any [link]s that depend on it (a no-op
     * when nothing links to it). Reentrancy-guarded so a linked write does not bounce back.
     */
    fun applyLinks(changedKey: String) {
        if (applyingLinks || store == null) return
        applyingLinks = true
        try {
            for (l in _links) when (changedKey) {
                l.a -> l.aToB(linkValue(l.a))?.let { setLinked(l.b, it) }
                l.b -> l.bToA(linkValue(l.b))?.let { setLinked(l.a, it) }
            }
        } finally { applyingLinks = false }
    }

    private fun linkValue(key: String): String =
        _items.firstOrNull { it.key == key }?.let { store?.get(it)?.toString() } ?: ""

    private fun setLinked(key: String, value: String) {
        val item = _items.firstOrNull { it.key == key } ?: return
        if (store?.get(item)?.toString() != value) store?.set(item, value)
    }

    private inner class Delegate<T>(private val item: ConfigItem) : ReadWriteProperty<Any?, T> {
        @Suppress("UNCHECKED_CAST")
        override fun getValue(thisRef: Any?, property: KProperty<*>): T = (store?.get(item) ?: item.default) as T
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) { store?.set(item, value) }
    }

    private fun <T> register(item: ConfigItem): ReadWriteProperty<Any?, T> {
        _items += item
        return Delegate(item)
    }

    protected fun boolItem(key: String, name: String, default: Boolean, description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, Boolean> =
        register(ConfigItem(key, name, ConfigType.BOOL, default, description, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    /**
     * An integer setting: a [min]/[max] slider (when `max > min`) or a free −/+ stepper otherwise. [step] is
     * the increment the value snaps to on both — drag, the ± buttons and typed entry all land on multiples of
     * it (offset from [min]); e.g. `step = 5` over `min = 0, max = 100` yields 0, 5, 10, … 100.
     */
    protected fun intItem(key: String, name: String, default: Int, min: Int = 0, max: Int = 0, description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null, step: Int = 1): ReadWriteProperty<Any?, Int> =
        register(ConfigItem(key, name, ConfigType.INT, default, description, min, max, step = step, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    /**
     * A decimal setting: a float [min]/[max] slider (or a free stepper when `max <= min`). [step] snaps the
     * slider to multiples of it (offset from [min]); `0.0` (the default) leaves it continuous.
     */
    protected fun floatItem(key: String, name: String, default: Double, min: Double = 0.0, max: Double = 0.0, description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null, step: Double = 0.0): ReadWriteProperty<Any?, Double> =
        register(ConfigItem(key, name, ConfigType.FLOAT, default, description, floatMin = min, floatMax = max, floatStep = step, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    /** A colour setting: an RGBA swatch + picker, persisted (and read) as a `#RRGGBBAA` hex [String]. */
    protected fun colorItem(key: String, name: String, default: String = "#FFFFFFFF", description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.COLOR, default, description, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    protected fun stringItem(key: String, name: String, default: String, description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.STRING, default, description, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    protected fun enumItem(key: String, name: String, default: String, options: List<String>, description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.ENUM, default, description, options = options, section = section, visibleIf = visibleIf, enabledIf = enabledIf))

    /**
     * A **dynamic** enum whose choices are produced live from game state via [options] (given the
     * [PluginContext]) instead of a fixed compile-time list — e.g. the items currently in the bank, or
     * nearby NPC names. The stored value is still the chosen string; the dropdown is refilled each frame.
     *
     * ```kotlin
     * var target by enumItem("target", "Target", "") { ctx -> ctx.npcs.nearby().map { it.name }.distinct() }
     * ```
     */
    protected fun enumItem(key: String, name: String, default: String = "", description: String = "", section: String = "", visibleIf: Condition? = null, enabledIf: Condition? = null, options: (PluginContext) -> List<String>): ReadWriteProperty<Any?, String> {
        _optionProviders[key] = options
        return register(ConfigItem(key, name, ConfigType.ENUM, default, description, section = section, visibleIf = visibleIf, enabledIf = enabledIf))
    }

    /**
     * An item setting: reads/writes an item **name** [String] exactly like [stringItem] (so plugin code is
     * unchanged), but renders as the searchable item picker (sprite + name) instead of a text box. [filter]
     * confines the choices (loose name substrings); [choices] restricts to **exactly** those names (an
     * allow-list — e.g. only real logs); [browse] shows the confined set when the box is empty.
     */
    protected fun itemItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, choices: List<String> = emptyList(), choiceIds: List<Int> = emptyList(), visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.ITEM, default, description, section = section, filter = filter, browse = browse, distinct = distinct, choices = choices, choiceIds = choiceIds, visibleIf = visibleIf, enabledIf = enabledIf))

    /** An item picker whose allow-list is produced **live** from game state as ids (given the [PluginContext]). */
    protected fun itemItem(key: String, name: String, default: String = "", description: String = "", section: String = "", browse: Boolean = true, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null, choiceIds: (PluginContext) -> List<Int>): ReadWriteProperty<Any?, String> =
        registerDynamicPicker(ConfigType.ITEM, key, name, default, description, section, browse, distinct, visibleIf, enabledIf, choiceIds)

    /** An NPC setting: an NPC **name** [String] (like [stringItem]), rendered as the NPC picker. */
    protected fun npcItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, choices: List<String> = emptyList(), choiceIds: List<Int> = emptyList(), visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.NPC, default, description, section = section, filter = filter, browse = browse, distinct = distinct, choices = choices, choiceIds = choiceIds, visibleIf = visibleIf, enabledIf = enabledIf))

    /** An NPC picker whose allow-list is produced **live** from game state as ids (e.g. nearby NPC ids). */
    protected fun npcItem(key: String, name: String, default: String = "", description: String = "", section: String = "", browse: Boolean = true, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null, choiceIds: (PluginContext) -> List<Int>): ReadWriteProperty<Any?, String> =
        registerDynamicPicker(ConfigType.NPC, key, name, default, description, section, browse, distinct, visibleIf, enabledIf, choiceIds)

    /** A scene-object setting: an object **name** [String], rendered as the object picker (model + name). */
    protected fun objectItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, choices: List<String> = emptyList(), choiceIds: List<Int> = emptyList(), visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.OBJECT, default, description, section = section, filter = filter, browse = browse, distinct = distinct, choices = choices, choiceIds = choiceIds, visibleIf = visibleIf, enabledIf = enabledIf))

    /** An object picker whose allow-list is produced **live** from game state as ids. */
    protected fun objectItem(key: String, name: String, default: String = "", description: String = "", section: String = "", browse: Boolean = true, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null, choiceIds: (PluginContext) -> List<Int>): ReadWriteProperty<Any?, String> =
        registerDynamicPicker(ConfigType.OBJECT, key, name, default, description, section, browse, distinct, visibleIf, enabledIf, choiceIds)

    private fun registerDynamicPicker(type: ConfigType, key: String, name: String, default: String, description: String, section: String, browse: Boolean, distinct: Boolean, visibleIf: Condition?, enabledIf: Condition?, choiceIds: (PluginContext) -> List<Int>): ReadWriteProperty<Any?, String> {
        _choiceIdProviders[key] = choiceIds
        return register(ConfigItem(key, name, type, default, description, section = section, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf))
    }

    /**
     * A multi-item setting: a **comma-separated** list of item names as one [String] (so existing
     * comma-separated string configs migrate unchanged), rendered as a multi-select item picker with
     * removable chips. Read/split it the same way as before (`value.split(",")`).
     */
    protected fun itemListItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.ITEM_LIST, default, description, section = section, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf))

    /** A multi-NPC setting: a comma-separated list of NPC names, rendered as a multi-select NPC picker. */
    protected fun npcListItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.NPC_LIST, default, description, section = section, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf))

    /** A multi-object setting: a comma-separated list of object names, rendered as a multi-select object picker. */
    protected fun objectListItem(key: String, name: String, default: String = "", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, visibleIf: Condition? = null, enabledIf: Condition? = null): ReadWriteProperty<Any?, String> =
        register(ConfigItem(key, name, ConfigType.OBJECT_LIST, default, description, section = section, filter = filter, browse = browse, distinct = distinct, visibleIf = visibleIf, enabledIf = enabledIf))

    /**
     * An **item setting with a "use best available" toggle** — the common "let me pick, or let the bot
     * choose" pattern in one line. It registers two things: a hidden companion boolean (`"<key>.auto"`)
     * behind an inline toggle labelled [autoLabel], and the item picker itself. While the toggle is off it
     * is an ordinary [itemItem]; while on, the picker greys out and its value comes from [resolve] (given
     * the live [PluginContext]) instead of user input — and reading the delegate returns that resolved
     * name, so plugin logic is identical either way. The user's manual pick is preserved underneath, so
     * toggling back off restores it.
     *
     * ```kotlin
     * var food by autoItem("food", "Food", default = "Shark", filter = FOODS) { ctx -> bestFood(ctx) }
     * // config.food -> "Shark" (or the manual pick) when off; the resolved best food when on.
     * ```
     */
    protected fun autoItem(key: String, name: String, default: String = "", autoLabel: String = "Use best available", description: String = "", section: String = "", filter: List<String> = emptyList(), browse: Boolean = false, distinct: Boolean = false, resolve: (PluginContext) -> String): ReadWriteProperty<Any?, String> =
        autoValue(ConfigItem(key, name, ConfigType.ITEM, default, description, section = section, filter = filter, browse = browse, distinct = distinct), autoLabel, resolve)

    /** A [stringItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto value. */
    protected fun autoStringItem(key: String, name: String, default: String = "", autoLabel: String = "Use best available", description: String = "", section: String = "", resolve: (PluginContext) -> String): ReadWriteProperty<Any?, String> =
        autoValue(ConfigItem(key, name, ConfigType.STRING, default, description, section = section), autoLabel, resolve)

    /** An [enumItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto choice. */
    protected fun autoEnumItem(key: String, name: String, default: String, options: List<String>, autoLabel: String = "Use best available", description: String = "", section: String = "", resolve: (PluginContext) -> String): ReadWriteProperty<Any?, String> =
        autoValue(ConfigItem(key, name, ConfigType.ENUM, default, description, options = options, section = section), autoLabel, resolve)

    /** An [intItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto number. [step] snaps the slider/stepper. */
    protected fun autoIntItem(key: String, name: String, default: Int, min: Int = 0, max: Int = 0, autoLabel: String = "Use best available", description: String = "", section: String = "", step: Int = 1, resolve: (PluginContext) -> Int): ReadWriteProperty<Any?, Int> =
        autoValue(ConfigItem(key, name, ConfigType.INT, default, description, min, max, step = step, section = section), autoLabel, resolve)

    /** A [floatItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto value. [step] snaps the slider (`0.0` = continuous). */
    protected fun autoFloatItem(key: String, name: String, default: Double, min: Double = 0.0, max: Double = 0.0, autoLabel: String = "Use best available", description: String = "", section: String = "", step: Double = 0.0, resolve: (PluginContext) -> Double): ReadWriteProperty<Any?, Double> =
        autoValue(ConfigItem(key, name, ConfigType.FLOAT, default, description, floatMin = min, floatMax = max, floatStep = step, section = section), autoLabel, resolve)

    /** An [npcItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto NPC name. */
    protected fun autoNpcItem(key: String, name: String, default: String = "", autoLabel: String = "Use best available", description: String = "", section: String = "", filter: List<String> = emptyList(), resolve: (PluginContext) -> String): ReadWriteProperty<Any?, String> =
        autoValue(ConfigItem(key, name, ConfigType.NPC, default, description, section = section, filter = filter), autoLabel, resolve)

    /** An [objectItem] with a "use best available" toggle (see [autoItem]); [resolve] supplies the auto object name. */
    protected fun autoObjectItem(key: String, name: String, default: String = "", autoLabel: String = "Use best available", description: String = "", section: String = "", filter: List<String> = emptyList(), resolve: (PluginContext) -> String): ReadWriteProperty<Any?, String> =
        autoValue(ConfigItem(key, name, ConfigType.OBJECT, default, description, section = section, filter = filter), autoLabel, resolve)

    /**
     * The type-generic core behind the `autoX` factories: given a base [item] schema, register a hidden
     * companion boolean (`"<key>.auto"`) behind the inline [autoLabel] toggle, wire [item.enabledIf] to
     * grey out while on, and store [resolve] so reading returns the resolved value while on (and the panel
     * can show it). While off it behaves exactly like the plain factory of that type.
     */
    private fun <T> autoValue(item: ConfigItem, autoLabel: String, resolve: (PluginContext) -> T): ReadWriteProperty<Any?, T> {
        val autoKey = "${item.key}.auto"
        _items += ConfigItem(autoKey, autoLabel, ConfigType.BOOL, false, hidden = true)
        _resolvers[item.key] = { ctx -> resolve(ctx) }
        val withAuto = item.copy(enabledIf = isFalse(autoKey), auto = AutoSpec(autoKey, autoLabel))
        _items += withAuto
        return AutoDelegate(withAuto, autoKey)
    }

    /** Reading returns the resolved value while the companion toggle is on, else the stored/manual value. */
    private inner class AutoDelegate<T>(private val item: ConfigItem, private val autoKey: String) : ReadWriteProperty<Any?, T> {
        @Suppress("UNCHECKED_CAST")
        override fun getValue(thisRef: Any?, property: KProperty<*>): T {
            if (autoOn(autoKey)) context?.let { ctx -> _resolvers[item.key]?.invoke(ctx)?.let { return it as T } }
            return (store?.get(item) ?: item.default) as T
        }
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) { store?.set(item, value) }
    }

    private fun autoOn(autoKey: String): Boolean {
        val companion = _items.firstOrNull { it.key == autoKey } ?: return false
        return (store?.get(companion) ?: companion.default) as? Boolean ?: false
    }

    /**
     * A **repeatable** group of rows the user can add/remove at runtime — a variable-length list of
     * sub-settings (the "add another rule" pattern). [build] declares one row's [RepeatableTemplate];
     * reading the delegate returns the current rows as [Row] views. The row count and every value persist
     * under indexed keys derived from [key]; [maxRows] `> 0` caps how many rows can be added.
     *
     * ```kotlin
     * val rules by repeatable("rules", "Loot rules", addLabel = "Add rule") {
     *     item("item", "Item"); enumField("action", "Action", "Keep", listOf("Keep","Bank","Drop"))
     * }
     * // rules -> List<Row>; each: r.string("item"), r.string("action")
     * ```
     */
    protected fun repeatable(key: String, name: String, addLabel: String = "Add", section: String = "", maxRows: Int = 0, build: RepeatableTemplate.() -> Unit): ReadOnlyProperty<Any?, List<Row>> {
        val spec = RepeatableSpec(key, addLabel, RepeatableTemplate().apply(build).fields, maxRows)
        _repeatables[key] = spec
        _items += ConfigItem(key, name, ConfigType.GROUP, null, section = section, group = spec)
        _items += ConfigItem(spec.countKey(), "", ConfigType.INT, 0, hidden = true)
        return RepeatableDelegate(spec)
    }

    /** Reads the current row count and materialises each row's values (by their local sub-keys). */
    private inner class RepeatableDelegate(private val spec: RepeatableSpec) : ReadOnlyProperty<Any?, List<Row>> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): List<Row> {
            val s = store ?: return emptyList()
            val count = (s.get(ConfigItem(spec.countKey(), "", ConfigType.INT, 0)) as? Number)?.toInt() ?: 0
            return (0 until count).map { row ->
                Row(spec.template.associate { t ->
                    t.key to (s.get(t.copy(key = spec.rowKey(row, t.key))) ?: t.default)
                })
            }
        }
    }
}
