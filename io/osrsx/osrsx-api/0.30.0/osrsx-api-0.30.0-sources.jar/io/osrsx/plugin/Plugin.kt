package io.osrsx.plugin

import io.osrsx.api.PluginApi
import io.osrsx.api.PluginContext
import io.osrsx.config.PluginConfig

/**
 * The single, first-class automation unit — what used to be split into "scripts" and "plugins". A
 * plugin can do anything from a tiny background utility (auto-loot in a radius) to a full quest/skill
 * bot; many run concurrently. Author in Kotlin/Java by extending this and annotating with
 * [PluginDescriptor].
 *
 * Lifecycle, driven by the [PluginManager]:
 *  - [onStart] when enabled, [onStop] when disabled,
 *  - [onLoop] repeatedly on the plugin's own thread (return ms until the next call; negative = no loop).
 *
 * [ctx] (the game API) and [config] are wired before [onStart].
 *
 * UI is opt-in via capability interfaces, kept off this base so it carries no engine/UI types:
 *  - implement [HasMenu] to contribute a docked, lockable sidebar panel with its own rail icon (ImGui),
 *  - implement [HasPanel] to draw floating, translucent, alt-draggable **interactive** overlay window(s)
 *    over the game (ImGui) — the lightweight replacement for RuneLite overlays,
 *  - implement [HasOverlay] to draw world-projected graphics over the game scene (tiles, paths, geometry).
 */
abstract class Plugin : PluginApi {
    /**
     * The game API surface. Assigned by the host's plugin manager before [onStart] — never read it
     * before then, and plugin code should never assign it (the setter exists only for the host, which
     * lives in a separate module). [PluginApi] surfaces each sub-API as an unprefixed `val`
     * (`skills`, `npcs`, …) that delegates here.
     */
    override lateinit var ctx: PluginContext

    /** This plugin's settings, or null if it has none. Override to declare configuration. */
    open fun config(): PluginConfig? = null

    open fun onStart() {}
    open fun onStop() {}

    /**
     * Called when one of this plugin's settings changes ([key] is the changed [io.osrsx.config.ConfigItem]
     * key). Runs on the thread that made the change (often the UI thread) — keep it quick. Override only
     * for settings that need real setup/teardown; most can just read the live config value when needed.
     */
    open fun onConfigChanged(key: String) {}

    /** Background work; return ms until the next call, or a negative value to not loop at all. */
    open fun onLoop(): Long = NO_LOOP

    /**
     * Called on the **client (game) thread** every client tick — up to ~50×/second (~20ms), the client's
     * render/logic cadence. This is the key difference from [onLoop]: [onLoop] runs on this plugin's own
     * background thread and reads a per-tick *snapshot* of game state, whereas code here runs ON the client
     * thread, so every read (inventory, npc/object queries, varps, skills, …) sees **live, uncached** state
     * with no staleness — no settle loops, no revalidation.
     *
     * In exchange it must be **fast and non-blocking**: never sleep, block, wait, or do heavy work here — you
     * are on the very thread that steps and renders the game, and a slow [onTick] stutters the whole client.
     * For anything that needs to wait or take time, use [onLoop]; for a one-off live read from [onLoop], use
     * [PluginContext.live]. Default is a no-op; override to opt in. Exceptions are caught and logged per tick.
     */
    open fun onTick() {}

    /**
     * Called on the **client (game) thread** every game tick — ~600ms, once per server cycle (the cadence
     * every gameplay action resolves on). Same live-read guarantee and same non-blocking rule as [onTick],
     * just at the slower game-tick rate — the natural place for per-tick decisions that need exact, uncached
     * state (did my inventory change this tick? did that NPC just spawn?). Default is a no-op; override to opt in.
     */
    open fun onGameTick() {}

    companion object {
        const val NO_LOOP = -1L
    }
}
