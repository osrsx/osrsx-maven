package io.osrsx.api


/**
 * The shared contract every navigator implements — one generic shape for local scene movement, whole-map
 * routing, and sailing, so learning one teaches you all four.
 *
 * There are four navigators, on two axes ([Walker] for land, [Sailor] for sea; `.local` for the loaded
 * scene, `.global` for the whole map):
 *
 * |          | global (whole-map plan) | local (scene-reactive) |
 * |----------|-------------------------|------------------------|
 * | **land** | [GlobalWalker]          | [LocalWalker]          |
 * | **sea**  | [GlobalSailor]          | [LocalSailor]          |
 *
 * All four are **self-driving**: call [pathTo] ONCE and an internal driver advances you every control step
 * until you arrive. Do NOT pump it from `onLoop` — that was the old web-walker poll model and it is gone.
 * Observe progress three ways, whichever suits: pass a `listener` for a live [NavEvent] stream, poll [state]
 * from any thread, or (in a script) suspend on `awaitArrival` for a [NavOutcome].
 *
 * Only ONE navigator is active at a time. A [pathTo] on any navigator stops whichever was running and
 * resolves its awaiter with [NavOutcome.Stopped], so two drivers can never fight over the mouse. A global
 * navigator delegating to its local counterpart is exempt from this (that is composition, not contention).
 *
 * @param C the configuration type shaping how this navigator plans and moves.
 * @param E the event type it emits.
 * @since 0.28.0
 */
interface Navigator<C : Any, E : NavEvent> {
    /**
     * The configuration used when [pathTo] is called without one. Declared here rather than as a literal
     * default because Kotlin forbids an override from redeclaring default values, and a base default cannot
     * name a subtype's constant — so `config: C = defaultConfig` is how every implementation gets a sensible
     * default while the signature stays generic.
     */
    val defaultConfig: C

    /**
     * Begin navigating to [dest], driving each control step until arrival. Returns true if the request was
     * ACCEPTED (not that you have arrived) — false when this navigator can't take it (e.g. [LocalSailor] when
     * not aboard a boat, or [dest] out of scene for a local navigator).
     *
     * A new call REPLACES the current target. [listener] receives every [E] for THIS navigation and is
     * dropped when it ends.
     */
    fun pathTo(dest: Tile, config: C = defaultConfig, listener: (E) -> Unit = {}): Boolean

    /** True once [dest] has been reached (within this navigator's arrival tolerance). */
    fun arrived(dest: Tile): Boolean

    /** True while a navigation is in flight (a target is set and the driver is running). */
    fun isNavigating(): Boolean

    /** The destination currently being navigated to, or null when idle. */
    fun target(): Tile?

    /**
     * Stop navigating and reset: cancel the driver, clear the target and any cached plan, return [state] to
     * [NavPhase.IDLE]. Any awaiter resolves with [NavOutcome.Stopped]. Since navigators self-drive, this is
     * the ONLY way to cancel — unlike the old poll model, simply not calling [pathTo] again does nothing.
     */
    fun stop()

    /** An immutable snapshot of the current state — safe to read from any thread, any time. */
    fun state(): NavState<E>
}

/**
 * Something that happened during a navigation. Each navigator has its own event hierarchy
 * ([LocalWalkEvent], [WalkEvent], [SailEvent]) so it can report in its own vocabulary, all sharing this
 * supertype and its [dest].
 */
sealed interface NavEvent {
    /** The destination the navigation is heading to. */
    val dest: Tile
}

/**
 * Coarse phase of a navigation, shared by all four navigators. Deliberately lean — for finer detail read
 * [NavState.lastEvent], which carries the navigator's own vocabulary (which transport, which hazard, …).
 */
enum class NavPhase {
    /** Nothing in flight. */
    IDLE,
    /** Computing a route (no movement yet). */
    PLANNING,
    /** Following the plan. */
    MOVING,
    /** Crossing a transport/transition — a door, boat, teleport, ladder. */
    TRANSPORT,
    /** On a side-trip off the main plan: a bank/GE run for a walker, a hazard detour for a sailor. */
    DETOUR,
    /** Movement has stalled and the navigator is trying to recover. */
    STUCK,
    /** The destination was reached. */
    ARRIVED,
    /** The navigation gave up. */
    FAILED,
}

/**
 * An immutable snapshot of a navigator's state — safe to read from any thread, any time. Poll this from an
 * overlay or a status panel; use a `listener` or `awaitArrival` when you need to react to changes.
 */
data class NavState<E : NavEvent>(
    val phase: NavPhase,
    /** Where we're heading, or null when idle. */
    val destination: Tile?,
    /** The most recent event emitted, or null. */
    val lastEvent: E?,
    /** A short human-readable status line, suitable for a panel. */
    val message: String,
) {
    /** True while a navigation is in flight. */
    val active: Boolean get() = phase != NavPhase.IDLE && phase != NavPhase.ARRIVED && phase != NavPhase.FAILED

    companion object {
        /** The idle snapshot. */
        fun <E : NavEvent> idle(): NavState<E> = NavState(NavPhase.IDLE, null, null, "idle")
    }
}

/**
 * How a navigation ENDED — the result of suspending on `awaitArrival`. Branch on it to handle each failure
 * mode, or call `orFail(action)` (in `io.osrsx.script`) to abort the script unless we arrived.
 */
sealed interface NavOutcome {
    /** The destination the navigation was heading to. */
    val dest: Tile

    /** Reached [dest], standing at [at] (may differ from [dest] within the arrival tolerance). */
    data class Arrived(override val dest: Tile, val at: Tile) : NavOutcome
    /** No route to [dest] could be found ([diagnosis] from the pathfinder). */
    data class Unreachable(override val dest: Tile, val diagnosis: String) : NavOutcome
    /** Still not there when the caller's timeout elapsed; [lastPhase] is where it had got to. */
    data class TimedOut(override val dest: Tile, val lastPhase: NavPhase) : NavOutcome
    /** Cancelled — [Navigator.stop], or displaced by a [Navigator.pathTo] on another navigator. */
    data class Stopped(override val dest: Tile) : NavOutcome
    /** The navigator gave up ([reason] explains — e.g. a required item that can't be obtained). */
    data class Failed(override val dest: Tile, val reason: String) : NavOutcome

    /** True only for [Arrived]. */
    val arrived: Boolean get() = this is Arrived
}

/**
 * Land movement: [local] for the loaded scene, [global] for the whole map. Reached via `walker` on
 * [PluginApi]; the sea counterpart is [Sailor].
 *
 * Pick [local] when the destination is already in the scene and you want a direct, low-latency step (a boss
 * dodge, repositioning in an arena). Pick [global] to get anywhere on the map — it plans across regions and
 * uses transports/teleports, delegating to [local] for each scene leg.
 *
 * @since 0.28.0
 */
interface Walker {
    /** Scene-local walking — direct steps within the loaded scene, no transports. */
    val local: LocalWalker
    /** Whole-map walking — plans across regions using transports and teleports. */
    val global: GlobalWalker
}

/**
 * Sea movement: [local] for the loaded scene, [global] for the whole map — plus the boat state and hazard
 * registry both tiers share. Reached via `sailor` on [PluginApi]; the land counterpart is [Walker].
 *
 * Both navigators require the player to be aboard a boat ([isOnBoat]). Unlike walking you don't click
 * tiles — they steer by HEADING and SAILS, and their pathfinding respects the hull footprint and turning
 * radius, so a route legal for a player on foot may be impossible for a boat.
 *
 * @since 0.28.0
 */
interface Sailor {
    /** Scene-local sailing — hull-aware manoeuvring within the loaded scene, routing around live hazards. */
    val local: LocalSailor
    /** Whole-map sailing — plans a hull-aware route across the sea, delegating to [local] to fly it. */
    val global: GlobalSailor

    // ---- boat state (shared by both tiers) ----

    /** Is the local player currently aboard a boat (their worldview is a boat sub-view)? */
    fun isOnBoat(): Boolean

    /** Current boat heading, 0..15 (0=S, 4=W, 8=N, 12=E), or -1 when not aboard. */
    fun heading(): Int

    /** Live snapshot of the plan for overlays/debug (route, hazards, hull, heading, target), or null when
     *  neither tier is navigating. */
    fun view(): SailView? = null

    // ---- hazard registry (shared: shapes what the local tier routes around) ----

    /** Inject a synthetic circular hazard patch the boat must route around — for testing the local tier. */
    fun addHazard(x: Int, y: Int, radius: Int) {}

    /** Register a real hazard object id (curated identification — the local tier routes around matches). */
    fun addHazardObject(id: Int) {}

    /** Register a real hazard npc id. */
    fun addHazardNpc(id: Int) {}

    /** Register a real hazard by name pattern (matched against object/npc names, case-insensitive). */
    fun addHazardName(pattern: String) {}

    /** Drop the injected synthetic hazards (curated ids/patterns are kept). */
    fun clearHazards() {}
}
