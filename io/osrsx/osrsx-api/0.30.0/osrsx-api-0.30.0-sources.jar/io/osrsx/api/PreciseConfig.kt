package io.osrsx.api

/**
 * Tunables for a **precise** (tracking-triggerbot) interaction — [Interactable.interactPrecise] /
 * [Interactable.hoverPrecise].
 *
 * The ordinary [Interactable.interact] path computes ONE on-screen point and then blindly moves the
 * cursor there. While that humanised move is in flight the point goes stale — the target steps, or the
 * camera drifts (most acutely while the avatar is *walking*) — so the click can land where the
 * tile/NPC/object *used to be*. A precise interaction instead HOMES the humanised cursor onto the target's
 * **live** on-screen clickbox, re-read every client tick (~20ms, far finer than the 600ms game tick), and
 * commits the click only once the cursor has rested inside that fresh clickbox for [dwellMs] — a geometric
 * triggerbot lock. This is the SDK generalisation of the boss-plugin NPC triggerbot, usable for any
 * clickable: NPC, object, ground item, or a walk tile's polygon. See [Mouse.moveTracking].
 *
 * @since 0.11.0
 */
data class PreciseConfig(
    /**
     * The cursor must rest inside the live clickbox continuously for this long before the click commits —
     * long enough that a one-frame graze of the hull edge as the target/camera drifts past never misfires.
     * Zero fires on first contact (snappiest, but riskier on a fast-moving target).
     */
    val dwellMs: Long = 60,
    /** ms of homing per pixel of cursor travel → the tracking window; clamped to [minMoveMs]..[maxMoveMs]. */
    val msPerPx: Double = 0.5,
    /** Lower clamp on the homing window (a nearby target still gets a human-plausible move, not a snap). */
    val minMoveMs: Long = 120,
    /** Upper clamp on the homing window (a far target doesn't crawl forever chasing a lock). */
    val maxMoveMs: Long = 500,
    /**
     * When the wanted action is NOT the game's current left-click default, may we briefly promote it to
     * default and left-click, instead of opening the right-click menu?
     *
     * The promotion is a live PRIORITY REORDER of the menu the client already built (see `Menu.setDefault`)
     * — nothing is injected or fabricated, and the rule is removed as soon as the interaction ends. Three
     * cases follow:
     *  - the action IS already the default → plain left-click; this flag is irrelevant;
     *  - not default and this is `true` → promote, left-click, restore;
     *  - not default and this is `false` → right-click and pick the row.
     *
     * So `true` means "essentially always left-click, promoting only when needed"; `false` means "never
     * touch menu priority, use the right-click menu when the action isn't already default".
     *
     * This matters more than it looks: an action can be present but non-default purely because something
     * else overlaps the target on screen (measured live — a boat's sail drifting over its cargo hold made
     * `Open` available but not default), and without promotion the interaction is at the mercy of camera
     * angle.
     */
    val setDefault: Boolean = true,
)
