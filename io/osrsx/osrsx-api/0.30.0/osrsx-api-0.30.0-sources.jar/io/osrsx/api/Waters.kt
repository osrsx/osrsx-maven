package io.osrsx.api


/**
 * Sea geometry — what the water looks like, asked rather than acted on. The sea counterpart of [Terrain]:
 * every method is a pure READ of the live sailing map (navigability, hull fit, hazards, tile type).
 * Nothing steers the boat; for that use [LocalSailor] or [GlobalSailor].
 *
 * Kept separate from [Terrain] rather than merged because boat navigability is the explicit INVERSE of
 * land walkability — land, docks and rocks BLOCK a hull where they carry a player, and open water passes
 * where it would drown one. One interface answering both would invert its own meaning depending on the
 * caller.
 *
 * The distinguishing question here is [hullFitsAt]: a boat occupies a multi-tile footprint at an
 * orientation, so "is this tile navigable" is necessary but not sufficient — a gap narrower than the beam
 * is open water the boat cannot enter.
 *
 * Sailing is beta content; this surface will grow as the local tier's collision-object routing lands.
 *
 * @since 0.28.0
 */
interface Waters {
    /**
     * Is (x, y, z) open, navigable water for a boat? The sailing analogue of [Terrain.isWalkable], and its
     * inverse in meaning: land, docks and rocks block; open water passes.
     */
    fun isNavigable(x: Int, y: Int, z: Int): Boolean

    /** As [isNavigable], for a [Tile]. */
    fun isNavigable(tile: Tile): Boolean = isNavigable(tile.x, tile.y, tile.plane)

    /**
     * Would the CURRENT boat's hull fit at [tile] on [heading] (0..15)? Unlike [isNavigable] this accounts
     * for the multi-tile footprint at that orientation, so it is the real test of whether the boat can
     * occupy a spot. False when not aboard a boat, or when any tile the hull would cover is un-navigable.
     */
    fun hullFitsAt(tile: Tile, heading: Int): Boolean = false

    /** The tiles the current boat's hull occupies right now, or empty when not aboard. */
    fun hull(): List<Tile> = emptyList()

    /**
     * Known hazard tiles within [radius] of [center] — curated hazard objects/npcs plus any synthetic
     * patches injected via [Sailor.addHazard]. These are what the local tier routes around.
     */
    fun hazardsNear(center: Tile, radius: Int): List<Tile> = emptyList()

    /**
     * The sailing tile classification at [tile] (open water, shallow, dock, land, …) as the sailing map
     * carries it, or null when outside the mapped area.
     */
    fun tileType(tile: Tile): SeaTileType? = null

    // ---- static sea data (baked into osrsx.db from the OSRS Wiki; see :osrsx-data) ----

    /**
     * Sailing docking points, nearest first from the player.
     *
     * [maxLevel] defaults to the player's own Sailing level, so the result is what you can ACTUALLY dock at.
     * [salvagingOnly] narrows to ports that can sort salvage — worth knowing that only about half of them
     * can, so "nearest port" and "nearest port that can sort" are genuinely different questions and picking
     * the wrong one sails you somewhere useless.
     *
     * Empty when the data isn't present (an older `osrsx.db`), never an exception.
     *
     * @since 0.29.0
     */
    fun ports(maxLevel: Int = -1, salvagingOnly: Boolean = false): List<SeaPort> = emptyList()

    /**
     * Shipwreck spawn tiles, nearest first from the player. [tier] filters by display name ("Small",
     * "Fisherman", …); null returns every tier the level allows.
     *
     * These are STATIC spawns — a wreck depletes to a stump and respawns, but the tile set is fixed — so
     * they are a routing hint, not a promise that a wreck is there right now. Confirm with a live scene
     * query before committing to one.
     *
     * @since 0.29.0
     */
    fun wrecks(tier: String? = null, maxLevel: Int = -1): List<SeaWreck> = emptyList()

}

/**
 * How the sailing map classifies a tile. Coarser than the raw collision data and stable across revisions —
 * for finer detail use [Waters.isNavigable] and [Waters.hullFitsAt].
 *
 * @since 0.28.0
 */
enum class SeaTileType {
    /** Open, freely navigable water. */
    OPEN_WATER,
    /** Navigable but shallow/constrained — passable, typically slower or riskier. */
    SHALLOW,
    /** A dock or mooring — where a boat can berth. */
    DOCK,
    /** Land: never navigable. */
    LAND,
    /** A known static obstacle in the water (rocks, wreckage). */
    OBSTACLE,
    /** Mapped, but of a kind we don't classify yet. */
    OTHER,
}

/**
 * A Sailing docking point and the facilities it offers.
 *
 * @property dock where the port is. It is a map position, NOT guaranteed to be water a hull fits in — route
 *   to it with [Sailor], which is hull-aware, rather than steering at it directly.
 * @property requirement a quest or region visit gating the port, empty when there is none. Free text and
 *   NOT machine-checked: a port can be listed and still refuse you.
 *
 * @since 0.29.0
 */
data class SeaPort(
    val name: String,
    val dock: Tile,
    val sailingLevel: Int,
    val requirement: String = "",
    val shipwright: Boolean = false,
    val noticeBoard: Boolean = false,
    val salvagingStation: Boolean = false,
    val ledgerTable: Boolean = false,
    val crewRegistrar: Boolean = false,
    val bankDepositBox: Boolean = false,
)

/**
 * A shipwreck spawn tile.
 *
 * @property tier display name of the wreck tier ("Small", "Fisherman", …).
 * @property sailingLevel level required to salvage that tier.
 *
 * @since 0.29.0
 */
data class SeaWreck(val tier: String, val tile: Tile, val sailingLevel: Int)
