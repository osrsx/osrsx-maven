package io.osrsx.api


/**
 * Scene geometry — what the ground looks like, asked rather than acted on. Every method here is a pure
 * READ of the live collision map: walkability, reachability, distance, line of sight, open space. Nothing
 * moves the player; for that use [LocalWalker] (in the scene) or [GlobalWalker] (anywhere).
 *
 * Split out of the old `Walking` interface, which had accreted these alongside movement and run
 * management. They are used heavily on their own — combat positioning asks "where is it safe to stand"
 * without ever walking — so they now stand on their own. The sea counterpart is [Waters].
 *
 * Unless noted, these read the LOADED SCENE and return an empty/null/false result for anything outside it;
 * [walkReachable] is the exception and works off-scene from the global collision data.
 *
 * @since 0.28.0 (extracted from `Walking`).
 */
interface Terrain {
    // ---- scene framing ----

    /** Is [dest] inside the currently loaded scene? */
    fun isInScene(dest: Tile): Boolean

    /**
     * The SW world tile of the CONTENT of the current dynamic instance — the base of the smallest
     * populated template chunk, in the loaded scene's world frame. `(playerTile − instanceBaseTile) /
     * roomSize` yields the room-grid cell for instances like the Gauntlet, where the content is offset
     * within the scene and the raw scene base includes empty padding. Null when not in an instance.
     */
    fun instanceBaseTile(): Tile? = null

    // ---- walkability & distance ----

    /** Is [tile] standable right now (not a wall/blocked object) per the live collision map? False if it's
     *  outside the loaded scene. A fast, path-free check — e.g. to pick a safe dodge tile that isn't a wall. */
    fun isWalkable(tile: Tile): Boolean

    /** Path distance to [dest] within the scene (not straight-line), or a large value when unreachable. */
    fun localDistance(dest: Tile): Int

    /** The collision-aware tile path to [dest] within the scene, or null when there is none. */
    fun localTilePath(dest: Tile): List<Tile>?

    /** How many steps the local path to [target] takes. */
    fun pathSteps(target: Tile): Int

    /** The nearest tile to [dest] that is actually standable and reachable — use when [dest] itself is
     *  blocked (an object's own tile, a wall). */
    fun reachableNear(dest: Tile): Tile

    // ---- interaction geometry ----

    /** Can the object at [obj] be reached well enough to interact with it? */
    fun canReachToInteract(obj: Tile): Boolean

    /** The tiles you could stand on to INTERACT with the object at [obj] — its walkable neighbours with NO
     *  wall on the edge toward it (so the wrong, walled-off side is excluded). Empty if [obj] isn't in the
     *  loaded scene. Pair with a reachability check to route to the correct usable side (e.g. INTO a building
     *  rather than up against its outer wall). */
    fun interactTiles(obj: Tile): List<Tile>

    // ---- open space & positioning ----

    /** How many of [tile]'s 8 neighbours are walkable (0..8) — a cheap "room to move/dodge from here" measure. */
    fun opennessAt(tile: Tile): Int

    /** The most OPEN standable tile within [radius] of [center] — the one with the most walkable neighbours
     *  (tie-broken toward the centre), i.e. room to dodge in every direction. Collision-only, single scan;
     *  null if none in scene. Use it to reposition off a wall/corner before a boss fight. */
    fun openestTile(center: Tile, radius: Int): Tile?

    /** The openest tile REACHABLE (wall-aware, via the local pathfinder) from [from] within [radius] — the
     *  safest place to stand in a fight: maximum room to dodge AND actually walkable-to (unlike [openestTile],
     *  which is collision-only and can pick a tile across a wall). Tie-broken toward [from]; null if none.
     *  Stand here proactively so a dodge always has somewhere to go. */
    fun safestReachableTile(from: Tile, radius: Int): Tile?

    /** Every tile within [radius] of [center] paired with its step-openness (0..8), or **-1 if blocked** — one
     *  collision scan, for a debug overlay that visualizes exactly what the walker sees (blocked vs open room). */
    fun opennessGrid(center: Tile, radius: Int): List<Pair<Tile, Int>>

    /** Flood-fill the ENCLOSED area reachable from [from] via wall-aware steps (bounded by [maxRadius]) — every
     *  tile inside the same closed-off region, e.g. a boss pen. Scan an arena ONCE with this and confine all
     *  positioning to the returned set, so tiles across a wall (outside the pen) are never considered. */
    fun enclosedArea(from: Tile, maxRadius: Int): List<Tile>

    // ---- threat geometry ----

    /**
     * Is there a clear **line of sight** from [from] to [to] — i.e. no wall/object between them
     * blocks a projectile or a ranged/magic attack? Uses the game's own tile-collision LOS check
     * (RuneLite `WorldArea.hasLineOfSightTo`), the same one the devtools LOS overlay draws, so it
     * respects walls, closed doors and diagonal blockers exactly as the server does. Both tiles must
     * be on the same plane and within the loaded scene; returns false otherwise.
     *
     * Typical use: decide whether an off-screen or adjacent-room NPC can actually hit you (or you it)
     * before you rely on positioning to break the shot — e.g. tucking behind a wall so a second boss
     * in the next room can't attack while you fight the first.
     */
    fun hasLineOfSight(from: Tile, to: Tile): Boolean = true

    /**
     * The nearest tile within [radius] of [from] that a MELEE attacker at [threat] (footprint
     * [threatSize]×[threatSize]) **cannot reach melee range of** — the live scene collision
     * (walls/closed doors/diagonal blockers) separates the two so the attacker can never step
     * adjacent. It is computed dynamically: a wall-aware flood-fill of where WE can stand, and one of
     * where the THREAT can walk, and the returned tile is the closest standable one none of whose
     * melee-adjacent squares the threat can occupy. Prefers the tile nearest [from] (least movement).
     *
     * Returns null in the OPEN — with no barrier a melee NPC can always path adjacent, so there is no
     * safespot. Use it to duck a melee add behind cover while you keep attacking something else;
     * pair with [hasLineOfSight] for ranged threats. Off-scene / different plane ⇒ null.
     *
     * [blockers] are tiles that OTHER actors (NPCs) currently occupy — NPCs can't overlap, so a mob
     * standing in a chokepoint blocks the threat's path through it. Passing the other mobs' footprint
     * tiles here makes a tile safe when a body (a boss you're behind, another add) walls the threat off,
     * even where the static collision alone wouldn't. They constrain only the THREAT's pathing, not ours.
     */
    fun safeTileFromMelee(from: Tile, threat: Tile, threatSize: Int = 1, radius: Int = 8, blockers: List<Tile> = emptyList()): Tile? = null

    // ---- off-scene reachability ----

    /**
     * Of [tiles], those within [maxSteps] ON-FOOT steps of [from] over the WHOLE-MAP collision map (no
     * transports) — so a water/wall barrier excludes a tile that is near in a straight line but a long walk
     * away (a tree across a river). Unlike the scene helpers this works OFF-SCENE (it reads the global
     * collision data), so a plugin can judge whether catalogued resource tiles it has never had in view form
     * a real, walkable cluster. An object/blocked tile counts as reached once a tile adjacent to it is reached
     * (you stand beside it to interact). Empty when [from]'s region has no collision data.
     */
    fun walkReachable(from: Tile, tiles: Collection<Tile>, maxSteps: Int): List<Tile>
}
