package io.osrsx.api

/**
 * A lightweight, always-available code profiler for plugin authors — time named sections of your plugin
 * and see, per section, both wall-clock cost **and how many client-thread marshalls it incurred**.
 *
 * The marshall count is the point. Almost every game read/write a plugin makes (an inventory lookup, a
 * varbit read, a widget bounds check) hops onto the RuneLite client thread. Off the client thread each hop
 * blocks until the next game tick, so a logical operation that fires ten independent hops is ~ten times
 * slower than the same reads wrapped in one on-thread scope. That "death by a thousand marshalls" pattern
 * is invisible in a normal profiler — it just looks like the operation is slow. Here it shows up directly:
 * a [TimerStat] with a high `marshalls` relative to `count` is the smell.
 *
 * ```
 * // wrap the hot section; the engine attributes every marshall inside it to this label
 * val fish = profiler.time("fishing-tick") {
 *     onLoop()          // whatever your loop does
 * }
 * // later, in the profiler window / debug server / report file:
 * //   fishing-tick   runs=1204  avg=3.1ms  marshalls=18/run   <-- 18 hops per tick is a lot; batch them
 * ```
 *
 * **Zero-overhead when off.** Profiling is globally toggleable (off by default in release builds; on for
 * local dev / when the profiler window or debug server asks for it). When [enabled] is `false` every method
 * here is a cheap no-op — [time]/[span] just run your block with no timestamps, allocation or bookkeeping —
 * so you can leave `profiler.time(...)` calls in shipping code with no measurable cost. Guard genuinely
 * expensive instrumentation (building a label string, say) behind an [enabled] check yourself.
 *
 * Labels are per-plugin scoped by the engine, so two plugins using the label `"tick"` never collide.
 *
 * Obtain it via [PluginContext.profiler] or, inside a plugin body, the `profiler` sugar on [PluginApi].
 */
interface Profiler {
    /**
     * Whether profiling is currently recording. When `false`, all recording methods are no-ops and reads
     * ([report]) return empty/zero. Cheap to read; use it to skip building expensive labels.
     */
    val enabled: Boolean

    /**
     * Run [block] under [label], recording its wall-clock duration and the client-thread marshalls it
     * incurred — even if it throws. Returns [block]'s result. When [enabled] is `false` this just calls
     * [block] with no bookkeeping. Nesting is supported: an inner section's time and marshalls are also
     * counted toward every enclosing section.
     */
    fun <T> time(label: String, block: () -> T): T

    /**
     * Open a timing [ProfileSpan] under [label] for cases where the timed region can't be a single lambda
     * (spans a suspend point, crosses methods, etc.). Close it with [ProfileSpan.close] — it is
     * [AutoCloseable], so `profiler.span("x").use { … }` works. Prefer [time] when a lambda fits.
     */
    fun span(label: String): ProfileSpan

    /** Increment a named counter by [amount] (default 1). Use for event tallies — items banked, ticks
     *  skipped, retries. Cheap no-op when disabled. */
    fun count(label: String, amount: Long = 1)

    /** Record a point-in-time numeric sample under [label] (queue depth, gp/hr, distance-to-target). The
     *  [report] keeps last/min/max/mean per gauge. Cheap no-op when disabled. */
    fun gauge(label: String, value: Double)

    /**
     * The number of client-thread marshalls the engine has attributed to the currently-open [span]/[time]
     * scope on this thread (0 if none is open or profiling is off). Lets a plugin assert or log the
     * marshall cost of a specific operation inline, without a full [report].
     */
    fun currentMarshalls(): Long

    /** An immutable snapshot of everything recorded since the last [reset]. Empty when disabled. */
    fun report(): ProfileReport

    /** Clear all accumulated timers, counters and gauges for this plugin. */
    fun reset()
}

/**
 * An open timing region from [Profiler.span]. Closing it records the elapsed time and marshall count under
 * the span's label. [AutoCloseable] for use with Kotlin `use` / Java try-with-resources. Closing twice is a
 * no-op. A no-op instance is returned when profiling is disabled.
 */
interface ProfileSpan : AutoCloseable {
    /** The label this span records under. */
    val label: String

    /** Marshalls attributed to this span so far (0 when profiling is disabled). */
    fun marshalls(): Long

    /** Record the span's elapsed time and marshalls. Idempotent. */
    override fun close()
}

/**
 * An immutable snapshot of a [Profiler]'s state — safe to render, serialize to a report file, or ship over
 * the debug socket. All lists are sorted by the engine most-expensive-first.
 */
data class ProfileReport(
    /** Wall-clock ms since the epoch when this snapshot was taken (engine-stamped). */
    val capturedAtMillis: Long,
    /** How long profiling has been recording since the last reset, in ms. */
    val windowMillis: Long,
    val timers: List<TimerStat>,
    val counters: List<CounterStat>,
    val gauges: List<GaugeStat>,
) {
    /** The single most marshall-heavy timer (by marshalls-per-run), or null if there are no timers. */
    fun worstMarshaller(): TimerStat? = timers.maxByOrNull { it.marshallsPerRun }

    companion object {
        /** The empty report returned when profiling is disabled. */
        val EMPTY = ProfileReport(0L, 0L, emptyList(), emptyList(), emptyList())
    }
}

/** Aggregated stats for one named timed section since the last reset. */
data class TimerStat(
    val label: String,
    /** How many times this section was entered. */
    val count: Long,
    val totalNanos: Long,
    val minNanos: Long,
    val maxNanos: Long,
    /** Total client-thread marshalls attributed to this section across all runs — the key inefficiency
     *  signal. High relative to [count] means the section is hopping the client thread too often. */
    val marshalls: Long,
    /** Wall-clock ns of synthetic-INPUT dispatch (the deliberately random, sleepy humanised mouse move/click/
     *  scroll + keyboard) attributed to this section — subtract from [totalNanos] to see its actual, non-random
     *  logic cost. @since 0.26.5 */
    val inputNanos: Long = 0L,
    /** Straight-line px the cursor travelled in the mouse-move dispatches, across all runs. @since 0.26.5 */
    val mousePx: Double = 0.0,
) {
    val avgNanos: Double get() = if (count == 0L) 0.0 else totalNanos.toDouble() / count
    val totalMs: Double get() = totalNanos / 1_000_000.0
    val avgMs: Double get() = avgNanos / 1_000_000.0
    val minMs: Double get() = minNanos / 1_000_000.0
    val maxMs: Double get() = maxNanos / 1_000_000.0

    /** Average client-thread marshalls per run — the number to watch. */
    val marshallsPerRun: Double get() = if (count == 0L) 0.0 else marshalls.toDouble() / count

    /** Synthetic-input dispatch time for this section (mouse + keyboard). */
    val inputMs: Double get() = inputNanos / 1_000_000.0
    /** [totalMs] minus the input dispatch time — the section's actual (non-random) cost. */
    val nonInputMs: Double get() = (totalNanos - inputNanos).coerceAtLeast(0L) / 1_000_000.0
    /** Average px travelled per run. */
    val mousePxPerRun: Double get() = if (count == 0L) 0.0 else mousePx / count
}

/** A named event tally. */
data class CounterStat(val label: String, val value: Long)

/** A sampled numeric series (last/min/max/mean over [count] samples). */
data class GaugeStat(
    val label: String,
    val last: Double,
    val min: Double,
    val max: Double,
    val sum: Double,
    val count: Long,
) {
    val mean: Double get() = if (count == 0L) 0.0 else sum / count
}
