package io.osrsx.api

import java.awt.Shape

/**
 * Anything a plugin can click in the world or on the screen. The SDK-facing surface of the engine's
 * interaction wrappers (the concrete impls live in `io.osrsx.wrappers` inside the client and drive the
 * virtual mouse / camera / menu selection). No `net.runelite.*` on this boundary — positions are exposed
 * as [Tile] via [SceneEntity.tile]; on-screen geometry uses the JDK's [java.awt.Shape].
 */
interface Interactable {
    /** Display name (e.g. the NPC/object/item name), or null when unknown / off-scene. */
    fun name(): String?

    /** The on-screen clickable region (convex hull / clickbox), or null if off-screen. */
    fun clickbox(): Shape?

    /**
     * Move the cursor onto this entity and settle there without clicking — e.g. to pre-position before a
     * follow-up [interact]. Homes onto the entity's LIVE clickbox, tracking it as it (or the camera) moves.
     */
    fun hover(config: PreciseConfig = PreciseConfig()): Boolean

    /**
     * Interact with this entity. With [action] null, performs the default left-click; a non-null [action]
     * (e.g. "Attack", "Bank") performs that menu option.
     *
     * Homes the humanised cursor onto the entity's LIVE clickbox — re-read every render frame, so the
     * cursor follows the target as it steps or as the camera drifts while you walk — and commits only once
     * the game itself agrees the cursor is on the target. That is the fix for the "clicked where it *used
     * to be*" miss; there is no separate imprecise path.
     *
     * How a non-default [action] is reached depends on [PreciseConfig.setDefault]: by default it is briefly
     * promoted to the left-click default and left-clicked, otherwise the right-click menu is used. Returns
     * true if it locked on and clicked; false if the target never settled (a loop can retry next tick).
     */
    /**
     * Perform [action] on this entity, or — when [more] is given — whichever of the listed actions the game
     * actually offers, in preference order.
     *
     * The multi-action form exists because some entities' advertised actions are empty or misleading while
     * their live menu carries the real options (scripted ferry operators are the standard case: the menu has
     * "Travel" though the composition lists nothing). Listing alternatives lets ONE menu satisfy any of
     * them, rather than paying a separate hover-and-click attempt per candidate.
     *
     * A first action is required explicitly so this never collides with the no-action overload above.
     */
    fun interact(vararg actions: String, config: PreciseConfig = PreciseConfig()): Boolean

    /**
     * Single-action [interact], as a plain overload.
     *
     * Exists for callers that are NOT Kotlin. A vararg-plus-default method compiles to one JVM signature
     * (`interact(String[], PreciseConfig)`) with the default hidden behind a synthetic, so Java — and the
     * Lua debug console, which binds real JVM signatures — cannot express `interact("Open")` at all. This
     * keeps the common call scriptable. Kotlin resolves to this overload for a lone action anyway, so
     * behaviour is identical from either side.
     */
    fun interact(action: String): Boolean = interact(action, config = PreciseConfig())

    /** No-arg [hover], as a plain overload — same non-Kotlin-caller reason as the [interact] overload above. */
    fun hover(): Boolean = hover(PreciseConfig())

    /**
     * Is [action] actually available on this entity RIGHT NOW — would the game offer it?
     *
     * Distinct from the entity's advertised action list, which comes from its COMPOSITION and says what it
     * can *ever* offer, not what it offers at this moment. Where an action is conditional the two diverge
     * sharply, and matching on the list alone silently reads as "always available" — a boat's sails
     * advertise `Trim` permanently, so a loop gated on the list fires forever whether or not a trim is
     * really on offer.
     *
     * **Accuracy differs by entity type**, and the difference is worth knowing rather than assuming:
     *  - **Scene objects** expose a live per-option flag, so this is exact for anything on screen, with no
     *    need to hover first. Conditional facilities (a salvaging hook's `Deploy`, a cargo hold's `Open`)
     *    are answered truthfully.
     *  - **NPCs** expose no per-instance shown/hidden flag (`isOpShown` is `TileObject`-only, verified
     *    across the whole engine API), but their composition is the TRANSFORMED one — it follows varbit
     *    state — so this does track a live variant change, just not per-instance visibility. Treat a true
     *    as "offered by this NPC in its current form".
     *  - **Players and ground items** report what is advertised.
     *
     * In every non-object case the interaction itself still verifies against the live menu before it
     * commits, so a false positive here costs a failed attempt, never a wrong click.
     *
     * Returns false when the action isn't on this entity at all, and when the entity is off-screen.
     */
    fun canInteract(action: String): Boolean = false
}

/**
 * A world entity (NPC, object, player, ground item) — an [Interactable] with a world position and
 * distance, plus verified/multi-option interaction helpers. Concrete impls are the engine's
 * `io.osrsx.wrappers.Entity` subclasses.
 */
interface SceneEntity : Interactable {
    /** World tile of this entity, or null if not in the scene. */
    fun tile(): Tile?

    /**
     * INTERPOLATED sub-tile scene position in local units (128 = 1 tile), or null when off-scene. Finer
     * than [tile] (whole-tile) and — unlike world [tile] — expressed in the loaded scene's own frame, so
     * `x / 128` / `y / 128` are the scene-tile coords (0..103). Available on every scene entity including
     * the LOCAL PLAYER (via `me`), e.g. for instance room-grid math where world coords are templated.
     *
     * @since 0.25.1
     */
    fun localPoint(): java.awt.Point? = null

    /** Chebyshev distance (tiles) from the local player; [Int.MAX_VALUE] if either is off-scene. */
    fun distance(): Int

    /**
     * The rendered TILE HEIGHT of this entity's position (engine units; more negative = higher up), or 0 when
     * off-scene. This is the only way to tell apart stacked areas the game overlays at the SAME world tile and
     * plane — most notably the Motherlode Mine's two floors (the upper floor is well below the lower's height,
     * ~< -490). Compare an object's [tileHeight] to the local player's to know they're on the same floor.
     *
     * @since 0.11.2
     */
    fun tileHeight(): Int = 0

    /**
     * A fast, VERIFIED default left-click: hover, confirm the live top menu entry really is [action] on
     * [target] (defaults to this entity's name), then left-click. No right-click fallback — returns false
     * if it can't confirm, so a tight loop can just retry next tick.
     */
    fun leftClickIfDefault(action: String, target: String? = null): Boolean
}
