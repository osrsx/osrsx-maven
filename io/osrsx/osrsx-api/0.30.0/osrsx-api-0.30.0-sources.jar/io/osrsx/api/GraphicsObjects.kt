package io.osrsx.api

/**
 * Read the scene graphics objects (spot-anims rendered into the world) currently active — the poll-style
 * companion to the [io.osrsx.api.events] graphics feed. These are the on-the-ground telegraphs bosses drop:
 * an AoE splat tile, a falling-rock marker, a poison pool. Answer "is graphics object id X on tile T right
 * now?" to step off a marked tile before it resolves.
 *
 * Served from the per-cycle client-thread snapshot, so an off-thread `active()` is a plain read with no
 * marshalling (the underlying client deque can't be iterated off-thread safely).
 *
 * @since 0.26.4
 */
interface GraphicsObjects {
    /** A snapshot of every graphics object active in the loaded scene this cycle. */
    fun active(): List<GraphicObjectInfo>
}

/**
 * One active scene graphics object (spot-anim).
 *
 * @since 0.26.4
 */
data class GraphicObjectInfo(
    val id: Int,
    /** The tile it is rendered on, or null when unresolved. */
    val tile: Tile?,
    /** The client cycle the object was spawned on — subtract from the current cycle for its age. */
    val startCycle: Int,
)
