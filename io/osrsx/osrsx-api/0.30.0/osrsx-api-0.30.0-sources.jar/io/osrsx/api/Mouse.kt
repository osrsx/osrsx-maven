package io.osrsx.api

import java.awt.Dimension
import java.awt.Point

/**
 * Low-level control of the humanised virtual cursor — the escape hatch for plugins that need precise,
 * reaction-time mouse control the ordinary [SceneEntity.interact] path can't express: homing a moving
 * target's on-screen hull, dwell-gating a click, aborting a move mid-flight when a telegraph fires, or
 * parking the cursor on a specific tile to dodge. Obtained from [PluginContext.mouse].
 *
 * Most plugins should NOT use this — prefer [SceneEntity.interact] / [LocalWalker] / [Combat], which pick and
 * click menu options for you. This surface exists for reaction-fight automation (boss triggerbots) that
 * genuinely needs pixel-level cursor control. All coordinates are game-canvas pixels; moves are generated
 * by the client's humanised mouse-path engine (never a teleport).
 */
interface Mouse {

    /** The cursor's current position on the game canvas. */
    val position: Point

    /** The game canvas size in pixels (for choosing on-screen points, e.g. a camera-recenter drag). */
    fun canvasSize(): Dimension

    /** Humanised move to (`x`, `y`) on the canvas. */
    fun moveTo(x: Int, y: Int)

    /** Humanised move to [p]. */
    fun moveTo(p: Point) = moveTo(p.x, p.y)

    /** Click at the current cursor position ([LEFT] by default). */
    fun click(button: Int = LEFT)

    /** Move to (`x`, `y`) and click ([LEFT] by default). */
    fun click(x: Int, y: Int, button: Int = LEFT)

    /**
     * Estimated duration (ms) of a humanised glide from the CURRENT cursor position to (`x`, `y`) —
     * the scheduling primitive for deadline-critical clicks: a fight loop asks this to compute the
     * latest safe start of a move that must arrive by a given tick (see
     * `io.osrsx.combat.CursorScheduler`). Estimates should be conservative (a high quantile, not the
     * mean): arriving early is free, arriving late loses the tick.
     *
     * The default is a distance-based heuristic for headless use; the engine overrides it with its
     * real mouse-path model.
     *
     * @since 0.25.0
     */
    fun travelTime(x: Int, y: Int): Long {
        val p = position
        val dx = (x - p.x).toDouble()
        val dy = (y - p.y).toDouble()
        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
        return (90 + dist * 0.65).toLong() // conservative: ~90ms reaction/settle + ~0.65ms per pixel
    }

    /** [travelTime] to [p]. @since 0.25.0 */
    fun travelTime(p: Point): Long = travelTime(p.x, p.y)

    /**
     * Pre-generate a complete humanised glide from the CURRENT cursor position to (`x`, `y`) — every
     * step's delay, INCLUDING the randomised jitter and overshoot+correction segments — so
     * [MousePlan.durationMs] is **exact by construction** before anything moves. This is the primitive
     * for deadline-critical clicks: plan the move, schedule its start so `start + durationMs` lands
     * exactly when the click must happen (see `io.osrsx.combat.CursorScheduler`), then [MousePlan.run]
     * replays THAT pre-rolled path faithfully — the path whose duration was computed is the path that
     * executes, never a re-roll.
     *
     * **Uniqueness contract**: every plan rolls fresh randomness — two plans between the same pixels
     * must never produce the same path/timing. Engines must not cache or replay paths.
     *
     * **Duration budget**: [withinMs] constrains the total duration — the engine paces the humanised
     * path (step density, dwell, overshoot depth) so [MousePlan.durationMs] falls inside the range,
     * rather than the caller hoping the roll comes out fast enough. Null = the engine's natural pace.
     *
     * **Humanizer interplay**: a plan is a single-use, execute-soon artifact anchored to the cursor
     * position at plan time — the background camera/idle-mouse humanizers WILL invalidate plans by
     * stealing the cursor. Deadline-critical sequences hold them off first
     * ([CameraControl.hold] + [Humanizers.setIdleMouse]=false) and check [MousePlan.valid] before [MousePlan.run].
     *
     * The default composes the [travelTime] heuristic with a plain [moveTo] (headless/testkit); the
     * engine overrides it with true path pre-generation.
     *
     * @since 0.25.0
     */
    fun planMove(x: Int, y: Int, withinMs: LongRange? = null): MousePlan {
        val origin = position
        val natural = travelTime(x, y)
        val duration = withinMs?.let { natural.coerceIn(it.first, it.last) } ?: natural
        return object : MousePlan {
            override val durationMs: Long = duration
            override val valid: Boolean get() = position == origin
            override fun run() = moveTo(x, y)
        }
    }

    /** [planMove] to [p]. @since 0.25.0 */
    fun planMove(p: Point, withinMs: LongRange? = null): MousePlan = planMove(p.x, p.y, withinMs)

    /** Raise the abort flag so an in-flight [moveTo]/[moveTracking] bails at its next step. */
    /**
     * Press-drag-release from [from] to [to] (humanised path, LEFT button) — the raw drag primitive
     * for drag UIs whose TARGET has no live widget, e.g. an EMPTY inventory slot (its widget is
     * hidden, so [Widgets.drag] rightly refuses it; pair this with [Inventory.slotBounds]). Prefer
     * [Widgets.drag] whenever both ends are real widgets.
     * @since 0.25.7 — transitional default; the engine overrides it in osrsx-core.
     */
    fun drag(from: Point, to: Point): Boolean = false

    fun abortMove()

    /** Clear the abort flag before a move that must complete (e.g. the dodge step itself). */
    fun clearAbort()

    /** Run [block] as one atomic cursor gesture (serialised against other cursor operations). */
    fun <T> gesture(block: () -> T): T

    /** Run [block] at a hurried, reaction-time pace (skips the leisurely inter-move dwell). */
    fun <T> withHurry(block: () -> T): T

    /**
     * Track a moving target for [durationMs], continuously aiming the humanised cursor at the freshest
     * point [target] returns (it's re-queried with the remaining ms as the boss keeps moving). [hitTest]
     * can early-exit the moment the cursor is over the target; [dwellMs] holds on-target before returning.
     * Returns true if it locked onto (a non-null [target]) within the window.
     */
    fun moveTracking(
        durationMs: Long,
        minStepMs: Long = 5L,
        dwellMs: Long = 0L,
        hitTest: (Point) -> Boolean = { false },
        target: (remMs: Double) -> Point?,
    ): Boolean

    companion object {
        /** Left mouse button. */
        const val LEFT = 1
        /** Right mouse button. */
        const val RIGHT = 3
    }
}

/**
 * A pre-generated humanised mouse glide with an exact, known-in-advance duration — see
 * [Mouse.planMove]. Single-use.
 *
 * @since 0.25.0
 */
interface MousePlan {
    /** Exact total duration of the pre-rolled path (every step delay, jitter and overshoot included). */
    val durationMs: Long

    /** True while the cursor is still at the plan's origin (plans go stale if something else moves it). */
    val valid: Boolean

    /** Execute the pre-rolled path (blocks for ~[durationMs]). Behaviour on a stale plan is engine-defined:
     *  prefer checking [valid] and re-planning. */
    fun run()
}
