package io.osrsx.api


/**
 * Scene-local walking — movement WITHIN the loaded scene, plus run-energy management. For anywhere else on
 * the map use [GlobalWalker], which plans across regions and delegates each scene leg back to this. Scene
 * geometry questions ("is this walkable", "can I see that", "how far is it") live on [Terrain].
 *
 * Two ways to move, for two different needs:
 *  - [pathTo] — self-driving. Give it a destination in the scene and it walks the collision-aware path,
 *    step by step, until it arrives. This is the [Navigator] contract; observe it with a listener,
 *    [state], or `awaitArrival`.
 *  - [walkStep] and friends — a single raw click, right now, returning immediately. The primitive for
 *    tight reactive control (a boss dodge on a specific tick) where you want to own the timing yourself
 *    rather than hand it to a driver.
 *
 * @since 0.28.0 (was `Walking`, whose geometry queries moved to [Terrain]).
 */
interface LocalWalker : Navigator<LocalWalkConfig, LocalWalkEvent> {
    override val defaultConfig: LocalWalkConfig get() = LocalWalkConfig.DEFAULT

    // ---- run management ----

    /** Current run energy, 0..100. */
    fun runEnergy(): Int
    /** Is run currently toggled on? */
    fun isRunEnabled(): Boolean
    /** Toggle run; returns the new state. */
    fun toggleRun(): Boolean
    /** Enable run if it's off and energy is at least [threshold]; returns true if run is on afterwards. */
    fun enableRunIf(threshold: Int = 30): Boolean
    /** Apply the humanised run policy for this tick — call it as periodic upkeep. */
    fun manageRun()

    // ---- raw stepping primitives ----

    /**
     * Click once toward [dest], returning immediately — no driver, no arrival guarantee. Honours the normal
     * click cadence, so a call while already walking is usually swallowed.
     */
    fun walkStep(dest: Tile): Boolean

    /**
     * Like [walkStep] but [force] bypasses the cadence and clicks even while already walking — for a
     * redirect that must override an in-progress walk NOW (a boss dodge interrupting a reposition), which
     * normal cadence would swallow.
     */
    fun walkStep(dest: Tile, force: Boolean): Boolean

    /**
     * Like [walkStep] but, when [leftClickOnly] is true, NEVER falls back to a right-click → "Walk here"
     * menu: if the viewport tile under the cursor isn't a left-click "Walk here" (an entity/object is on
     * top), it goes STRAIGHT to a minimap left-click instead. The right-click menu costs ~700ms to open —
     * fatal mid boss-dodge — so a dodge wants a guaranteed instant left-click (viewport if clean, else
     * minimap).
     */
    fun walkStep(dest: Tile, force: Boolean, leftClickOnly: Boolean): Boolean

    /** Step one hop toward [target] without committing to reach it — useful for closing distance gradually. */
    fun walkTowards(target: Tile): Boolean

    /**
     * RuneLite's authoritative walk TARGET — the tile the client is currently moving toward (the yellow
     * destination tile), or null when standing still. This is the real in-game destination regardless of who
     * issued the move (this navigator, another plugin, or the user), so it's the reliable "are we moving, and
     * where to" for dodge logic. Distinct from [target], which is only what THIS navigator was asked for.
     */
    fun destination(): Tile?
}

/**
 * How [LocalWalker.pathTo] walks. Defaults reproduce ordinary walking: exact arrival, normal click cadence,
 * humanised run.
 */
data class LocalWalkConfig(
    /** Accept arriving within this many tiles of the destination. 0 = require the exact tile. */
    val arriveRadius: Int = 0,
    /** Never open a right-click "Walk here" menu — go straight to the minimap when the viewport tile is
     *  obstructed. Costs some precision, saves the ~700ms menu open. See [LocalWalker.walkStep]. */
    val leftClickOnly: Boolean = false,
    /** Bypass the normal click cadence on every step — each step re-clicks even while already walking.
     *  For reactive repositioning that must not be swallowed. */
    val force: Boolean = false,
    /** When to enable run during the walk. */
    val runPolicy: RunPolicy = RunPolicy.Humanized,
    /** No progress for this long ⇒ [NavPhase.STUCK], then a re-path attempt. */
    val stuckMs: Long = 3_000,
    /** Give up (emit [LocalWalkEvent.Failed]) after this long without arriving. 0 = never time out. */
    val timeoutMs: Long = 30_000,
) {
    companion object {
        /** Ordinary walking — exact arrival, normal cadence, humanised run. */
        val DEFAULT = LocalWalkConfig()

        /**
         * For reactive combat movement: forced clicks that are never swallowed, never a right-click menu,
         * always running, and a loose arrival radius so a near-enough tile counts.
         */
        val DODGE = LocalWalkConfig(
            arriveRadius = 1,
            leftClickOnly = true,
            force = true,
            runPolicy = RunPolicy.Always,
            stuckMs = 1_200,
            timeoutMs = 5_000,
        )
    }
}

/** What a [LocalWalker.pathTo] reports as it walks. */
sealed interface LocalWalkEvent : NavEvent {
    /** A local walk to [dest] began from [from]. */
    data class Started(override val dest: Tile, val from: Tile) : LocalWalkEvent
    /** Now stepping to [target], with [remaining] tiles of path left. */
    data class Stepping(override val dest: Tile, val target: Tile, val remaining: Int) : LocalWalkEvent
    /** No progress from [at] ([reason] describes why); the walker will try to re-path. */
    data class Blocked(override val dest: Tile, val at: Tile, val reason: String) : LocalWalkEvent
    /** Arrived at [dest], standing on [at]. */
    data class Arrived(override val dest: Tile, val at: Tile) : LocalWalkEvent
    /** Gave up ([reason] explains — unreachable within the scene, or timed out). */
    data class Failed(override val dest: Tile, val reason: String) : LocalWalkEvent
}

/** When a walker should turn run on. */
sealed interface RunPolicy {
    /** The default humanised model: drain to ~0, re-enable at a varied energy, occasional early stop. */
    object Humanized : RunPolicy
    /** Run whenever any energy is available. */
    object Always : RunPolicy
    /** Never run. */
    object Never : RunPolicy
    /** Enable run once energy is at least [percent]. */
    data class AboveEnergy(val percent: Int) : RunPolicy
}
