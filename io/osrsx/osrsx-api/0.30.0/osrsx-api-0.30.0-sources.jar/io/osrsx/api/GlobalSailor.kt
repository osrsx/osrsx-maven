package io.osrsx.api


/**
 * Whole-map sailing — plan and follow a hull-aware route across the sea to anywhere reachable by water.
 * The sea counterpart of [GlobalWalker]; for manoeuvring inside the loaded scene use [LocalSailor], which
 * this delegates each leg to.
 *
 * Self-driving per the [Navigator] contract: call [pathTo] ONCE and the boat sails itself — planning a
 * global hull-legal route, then flying it leg by leg while the local tier reactively routes around live
 * hazards and rejoins the plan. Observe with a listener, [state], or `awaitArrival`.
 *
 * Requires being aboard a boat ([Sailor.isOnBoat]); [pathTo] returns false otherwise. Sailing is beta
 * content — heading/sail actuation may need per-revision tuning.
 *
 * @since 0.28.0 (was `Sailing`, which mixed the two tiers and had no config or event stream).
 */
interface GlobalSailor : Navigator<GlobalSailConfig, SailEvent> {
    override val defaultConfig: GlobalSailConfig get() = GlobalSailConfig.DEFAULT

    /**
     * The currently planned route to [dest] as tile waypoints (for overlays and previewing), or null when
     * none exists or it can't be planned. Does not begin sailing.
     */
    fun route(dest: Tile): List<Tile>? = null

    /**
     * The route currently being followed as tile waypoints — the global plan including any local detour
     * spliced into it — or null when idle.
     */
    fun route(): List<Tile>? = null
}

/**
 * How [GlobalSailor.pathTo] plans and flies a whole-map route. The reactive, per-step behaviour is
 * configured by the local tier it delegates to — see [local].
 */
data class GlobalSailConfig(
    /** Dock/arrive when within this many tiles of the destination. */
    val arriveRadius: Int = 2,
    /** Per-search budget for the global hull-aware route search, in ms. */
    val pathfindTimeoutMs: Long = 8_000,
    /** Re-plan the global route from scratch when the local tier can't rejoin it within this many tiles. */
    val replanAfterDriftTiles: Int = 24,
    /** Give up (emit [SailEvent.Failed]) after this long without arriving. 0 = never time out. */
    val timeoutMs: Long = 600_000,
    /** The local-tier configuration used for each leg — hazard clearance, control cadence, un-wedging. */
    val local: LocalSailConfig = LocalSailConfig.DEFAULT,
) {
    companion object {
        /** Balanced defaults. */
        val DEFAULT = GlobalSailConfig()

        /** Cluttered/hazardous water — wider clearance and a longer planning budget. */
        val CAUTIOUS = GlobalSailConfig(pathfindTimeoutMs = 15_000, local = LocalSailConfig.CAUTIOUS)
    }
}
