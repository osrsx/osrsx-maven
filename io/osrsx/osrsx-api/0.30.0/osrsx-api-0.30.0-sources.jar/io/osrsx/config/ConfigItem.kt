package io.osrsx.config

/**
 * The value type of a [ConfigItem] — drives both persistence parsing and the auto-generated UI widget.
 *
 * The picker types all persist as a plain [String] (so a plugin reads them exactly like [STRING]) but
 * render as searchable, sprite/model-backed pickers instead of a raw text box:
 *  - [ITEM] / [NPC] / [OBJECT]              — a single item / NPC / scene-object **name**.
 *  - [ITEM_LIST] / [NPC_LIST] / [OBJECT_LIST] — a **comma-separated** name list (multi-select).
 *
 * [INT_RANGE] / [FLOAT_RANGE] persist as a `"lo,hi"` string (like the list types) but render as a
 * **dual-knob** slider that picks a low/high pair within the item's bounds — [ConfigItem.min]/[ConfigItem.max]
 * for [INT_RANGE], [ConfigItem.floatMin]/[ConfigItem.floatMax] for [FLOAT_RANGE].
 */
enum class ConfigType { BOOL, INT, FLOAT, STRING, ENUM, COLOR, ITEM, NPC, OBJECT, ITEM_LIST, NPC_LIST, OBJECT_LIST, GROUP, INT_RANGE, FLOAT_RANGE }

/**
 * One per-plugin setting: its storage [key], display [name]/[description], [type], [default], and
 * (for INT) a slider [min]/[max], or (for ENUM) the allowed [options]. A plugin declares its settings as
 * the list of these it registers (via [PluginConfig] delegates) — the analogue of a RuneLite
 * `@ConfigItem`, but as data so the same schema drives the config panel and persistence.
 */
data class ConfigItem(
    val key: String,
    val name: String,
    val type: ConfigType,
    val default: Any?,
    val description: String = "",
    val min: Int = 0,
    val max: Int = 0,
    /** For an [ConfigType.INT] slider/stepper: the increment the value snaps to (drag, −/+ buttons and typed
     *  entry are all quantised to it, offset from [min]). Clamped to at least 1; the default is a step of 1. */
    val step: Int = 1,
    val options: List<String> = emptyList(),
    /** For a [ConfigType.FLOAT] slider: the inclusive value bounds (a [floatMax] > [floatMin] gives a slider,
     *  otherwise a free stepper). */
    val floatMin: Double = 0.0,
    val floatMax: Double = 0.0,
    /** For a [ConfigType.FLOAT] slider: the increment the value snaps to (offset from [floatMin]).
     *  `0.0` (the default) means continuous — no snapping. */
    val floatStep: Double = 0.0,
    /** Optional sub-section this item is grouped under in the config UI ("" = top level). */
    val section: String = "",
    /**
     * For a picker type ([ITEM]/[NPC]/[OBJECT] and their lists): restrict the choices to entries whose name
     * contains any of these terms (case-insensitive). Empty = the whole catalog. E.g. a Woodcutter tree
     * setting can be confined to `["tree","oak","willow","yew",…]`.
     */
    val filter: List<String> = emptyList(),
    /** For a picker type: show the (filtered) list when the search box is empty, instead of recents — so a
     *  small filtered set (e.g. the handful of tree objects) can be browsed without typing. */
    val browse: Boolean = false,
    /** For a picker type: collapse entries that share a name to a single result. Useful for objects, where
     *  many ids share one name (all the "Rocks"/"Basalt") and the value is stored by name anyway. */
    val distinct: Boolean = false,
    /**
     * For a LIST picker type ([ITEM_LIST]/[NPC_LIST]/[OBJECT_LIST]): give every chosen entry an editable
     * quantity. The value is stored as a comma-separated `name:qty` list (e.g. `"Repair kit:3,Cannonball:0"`)
     * instead of a bare name list; parse it with [io.osrsx.config.Quantified.parse]. Ignored for the
     * single-value picker types. Registered through `itemQtyListItem`/`npcQtyListItem`/`objectQtyListItem`.
     */
    val quantified: Boolean = false,
    /**
     * For a picker type ([ITEM]/[NPC]/[OBJECT]): restrict the picker to **exactly** these names (an
     * allow-list), instead of the loose substring [filter] over the whole catalogue. Empty = unrestricted.
     * For a *dynamic* (game-state-derived) list, register a provider via the `choices { ctx -> … }` factory
     * overload instead — the panel reads it through [PluginConfig.dynamicOptions]. E.g. a Woodcutter tree
     * picker confined to real tree objects, and its log picker to real logs.
     */
    val choices: List<String> = emptyList(),
    /**
     * For a picker type: restrict to **exactly** these numeric ids — the precise complement to [choices]
     * when a name is ambiguous (e.g. the many object ids all named "Tree"). Unioned with [choices] when
     * both are given. For a dynamic id list, use the `choiceIds { ctx -> … }` factory overload.
     */
    val choiceIds: List<Int> = emptyList(),
    /**
     * Show this item only while this [Condition] holds against the *other* settings' current values
     * (`null` = always shown). UI-only — the stored value is left untouched while hidden. Supports full
     * and / or / not logic, e.g. `visibleIf = isTrue("useSpecial") and oneOf("mode","Custom","Advanced")`.
     */
    val visibleIf: Condition? = null,
    /**
     * Allow *editing* this item only while this [Condition] holds (`null` = always editable). When it is
     * false the control is drawn read-only and greyed but still shows its value. UI-only — the stored
     * value is kept, so re-enabling restores the user's last edit.
     */
    val enabledIf: Condition? = null,
    /**
     * An internal/companion item: it is persisted and usable in [Condition]s (via its [key]), but never
     * drawn as a standalone field — its owner renders it. Used by [PluginConfig.autoItem] for the boolean
     * behind its "use best available" toggle.
     */
    val hidden: Boolean = false,
    /**
     * When set, this item renders with an inline toggle that flips it into **auto** mode: the paired
     * boolean ([AutoSpec.key], a [hidden] companion) drives [enabledIf] (so the control greys out while
     * on) and the displayed/effective value comes from the plugin's resolver instead of user input. See
     * [PluginConfig.autoItem].
     */
    val auto: AutoSpec? = null,
    /**
     * Present on a [ConfigType.GROUP] marker item: describes a **repeatable** group of rows the user can
     * add/remove at runtime (a variable-length list of sub-settings). The panel expands it into a section
     * with one row per entry plus an add button; the count and per-row values persist under indexed keys.
     * See [PluginConfig.repeatable].
     */
    val group: RepeatableSpec? = null,
)

/**
 * The inline "auto" toggle attached to an item by [PluginConfig.autoItem]. [key] is the [ConfigItem.hidden]
 * companion boolean it reads/writes; [label] is the toggle caption (e.g. `"Use best available"`).
 */
data class AutoSpec(val key: String, val label: String)
