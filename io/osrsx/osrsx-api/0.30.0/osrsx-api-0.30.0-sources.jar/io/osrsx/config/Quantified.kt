package io.osrsx.config

/**
 * Encode/decode the `name:qty` string that backs a quantified list config
 * (`itemQtyListItem`/`npcQtyListItem`/`objectQtyListItem`).
 *
 * The format is a comma-separated list of `name:qty` entries — `"Repair kit:3,Cannonball:0"`. It is a
 * deliberate superset of the plain name-list format the ordinary list pickers use, so a value hand-written
 * without quantities (`"Repair kit,Cannonball"`) still parses, each entry taking [DEFAULT_QTY]. That keeps a
 * setting migratable in either direction and forgiving of a hand-edited config file.
 *
 * Names can legitimately contain characters, but not a bare `:` followed by digits at the end — the split
 * is on the LAST colon, so `"Rune:5"` is `Rune`×5 while a name that itself ends in `:something` is
 * preserved as long as the trailing token isn't a number. Order is preserved (it is the display order).
 */
object Quantified {

    /** Quantity assumed for an entry written without one — see the migration note above. */
    const val DEFAULT_QTY = 1

    /**
     * Parse `"name:qty,name:qty"` into ordered `name -> qty` pairs.
     *
     * Tolerant by design: blank entries are dropped, a missing or unparseable quantity falls back to
     * [DEFAULT_QTY], and a negative quantity is clamped to 0. Never throws — a malformed config degrades to
     * a best-effort reading rather than failing the plugin.
     */
    fun parse(raw: String?): List<Pair<String, Int>> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(',').mapNotNull { token ->
            val entry = token.trim()
            if (entry.isEmpty()) return@mapNotNull null
            val cut = entry.lastIndexOf(':')
            if (cut <= 0 || cut == entry.length - 1) {
                entry to DEFAULT_QTY
            } else {
                val name = entry.substring(0, cut).trim()
                val qty = entry.substring(cut + 1).trim().toIntOrNull()
                if (name.isEmpty()) null
                else name to (qty ?: DEFAULT_QTY).coerceAtLeast(0)
            }
        }
    }

    /** Parse into a `name -> qty` map, keeping the first entry when a name repeats. */
    fun parseMap(raw: String?): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        for ((name, qty) in parse(raw)) out.putIfAbsent(name, qty)
        return out
    }

    /** Encode ordered `name -> qty` pairs back to the stored `"name:qty,name:qty"` form. */
    fun encode(entries: List<Pair<String, Int>>): String =
        entries.filter { it.first.isNotBlank() }
            .joinToString(",") { (name, qty) -> "$name:${qty.coerceAtLeast(0)}" }
}
