package io.osrsx.script

import io.osrsx.api.NavOutcome
import io.osrsx.api.NavPhase
import io.osrsx.api.Navigator
import io.osrsx.api.Tile

/**
 * Suspend until [nav] finishes whatever it is navigating to, and report how it ended.
 *
 * Navigators self-drive, so this does NOT pump them — it parks the script and checks back every [pollMs]
 * until the navigation resolves. That means the script reads linearly:
 *
 * ```
 * walker.global.pathTo(dest)
 * awaitArrival(walker.global).orFail("travel to $dest")
 * ```
 *
 * **Why polling and not a callback bridge.** [ScriptRunner] is a single-threaded cooperative step machine
 * — `tick` and the resumed body run on the same loop thread, with no locking — while every navigator drives
 * from its own scheduler thread. Resuming the script's continuation from that thread would violate the
 * runner's invariant, so arrival is observed by parking rather than by being signalled. The practical
 * consequence is that arrival is noticed within [pollMs], not instantly; pass a `listener` to `pathTo`
 * instead when you need to react on the exact control step.
 *
 * Returns [NavOutcome.TimedOut] if [timeoutMs] elapses first — the navigator is left RUNNING in that case,
 * so call [Navigator.stop] yourself if you want it cancelled.
 *
 * @since 0.28.0
 */
suspend fun ScriptScope.awaitArrival(
    nav: Navigator<*, *>,
    timeoutMs: Long = 120_000,
    pollMs: Long = 250,
): NavOutcome {
    val dest = nav.target() ?: return NavOutcome.Stopped(Tile(0, 0, 0))
    val settled = waitUntil(timeoutMs, pollMs) { !nav.isNavigating() }
    if (!settled) return NavOutcome.TimedOut(dest, nav.state().phase)
    return nav.outcome(dest)
}

/**
 * As [awaitArrival], but starts the navigation for you: begins [nav] toward [dest] and suspends until it
 * resolves. Returns [NavOutcome.Failed] immediately if the navigator refuses the request (e.g. not aboard a
 * boat, or the destination is out of scene for a local navigator).
 *
 * @since 0.28.0
 */
suspend fun <C : Any> ScriptScope.navigateTo(
    nav: Navigator<C, *>,
    dest: Tile,
    config: C = nav.defaultConfig,
    timeoutMs: Long = 120_000,
    pollMs: Long = 250,
): NavOutcome {
    if (!nav.pathTo(dest, config)) return NavOutcome.Failed(dest, "navigator refused the request")
    val settled = waitUntil(timeoutMs, pollMs) { !nav.isNavigating() }
    if (!settled) return NavOutcome.TimedOut(dest, nav.state().phase)
    return nav.outcome(dest)
}

/** Translate a settled navigator's terminal phase into a [NavOutcome]. */
private fun Navigator<*, *>.outcome(dest: Tile): NavOutcome {
    val state = state()
    return when {
        arrived(dest) -> NavOutcome.Arrived(dest, target() ?: dest)
        state.phase == NavPhase.FAILED -> NavOutcome.Failed(dest, state.message)
        else -> NavOutcome.Stopped(dest)
    }
}

/**
 * The tile we arrived at, or abort the script — throws [ScriptActionFailed] naming [action] and why it
 * ended. The terse way to say "this must have worked" in a linear script, matching how the quest actions
 * fail. Use `when (outcome) { … }` instead when you want to handle a failure rather than propagate it.
 *
 * @since 0.28.0
 */
fun NavOutcome.orFail(action: String): Tile = when (this) {
    is NavOutcome.Arrived -> at
    is NavOutcome.Unreachable -> throw ScriptActionFailed("$action — unreachable: $diagnosis")
    is NavOutcome.TimedOut -> throw ScriptActionFailed("$action — timed out in $lastPhase")
    is NavOutcome.Stopped -> throw ScriptActionFailed("$action — navigation was stopped")
    is NavOutcome.Failed -> throw ScriptActionFailed("$action — $reason")
}
