package io.osrsx.combat

import io.osrsx.api.Tile
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Pure dodge-tile selection over a pre-scanned arena — the geometry half of AoE-dodging, adapted from
 * the extracted boss-lib's planner (proven by Brutus/Demonic Gorilla). The fight controller owns the
 * POLICY (when to dodge, what counts as a threat — see [ThreatMap]); this ranks WHERE to step.
 *
 * [arena] is the reachable fight area (e.g. `terrain.enclosedArea(startTile, 16)` computed once at
 * fight start), so candidate tiles are walkable by construction — no per-tile pathfinding. Scoring:
 * openness (8-neighbour arena membership — corners and walls rank low), an optional keep-range band
 * around a focus tile (stay in bow range without hugging the boss), and slight randomness among the
 * top picks so repeated dodges don't machine-repeat. Unit-testable: everything in-memory, seedable RNG.
 *
 * @since 0.25.0
 */
class DodgePlanner(
    /** Farthest a dodge may travel (Chebyshev). Run covers 2 tiles/tick, so far picks clear fast. */
    private val rangeMax: Int = 5,
    /** A pick chooses uniformly among the top-N ranked safe tiles (human variety). */
    private val choices: Int = 3,
    /** Per-open-neighbour bonus (max 8×this): prefers open ground, punishes corners. */
    private val opennessWeight: Int = 8,
    /** Penalty per tile of keep-range-band violation (outside [DodgePrefs.keepRange] of the focus). */
    private val rangeBandWeight: Int = 15,
    /** Seedable for tests; the fight uses the default. */
    private val rng: Random = Random(),
) {

    /**
     * The best safe tile to step to from [from], or null when nothing qualifies (then flee: the caller
     * takes [leastBad]). [threatened] is the hard veto — typically
     * `{ threats.isThreatened(it, now, lookahead) || it in bossFootprint }`.
     */
    fun pick(from: Tile, arena: Set<Tile>, threatened: (Tile) -> Boolean, prefs: DodgePrefs = DodgePrefs()): Tile? {
        val scored = ArrayList<Pair<Tile, Int>>(24)
        for (dx in -rangeMax..rangeMax) for (dy in -rangeMax..rangeMax) {
            if (dx == 0 && dy == 0) continue
            val dist = max(abs(dx), abs(dy))
            if (dist < prefs.minDist) continue
            val t = Tile(from.x + dx, from.y + dy, from.plane)
            if (t !in arena || threatened(t)) continue
            var score = openness(t, arena) * opennessWeight
            prefs.keepRange?.let { (focus, band) ->
                val d = max(abs(t.x - focus.x), abs(t.y - focus.y))
                val violation = when {
                    d < band.first -> band.first - d
                    d > band.last -> d - band.last
                    else -> 0
                }
                score -= violation * rangeBandWeight
            }
            scored.add(t to score)
        }
        if (scored.isEmpty()) return null
        scored.sortByDescending { it.second }
        return scored[rng.nextInt(min(choices, scored.size))].first
    }

    /**
     * Last resort when no strictly-safe tile exists: the openest in-arena tile that maximises distance
     * from [fleeFrom] — better than eating the hit standing still. Null only when boxed in completely.
     */
    fun leastBad(from: Tile, arena: Set<Tile>, fleeFrom: Tile): Tile? {
        var best: Tile? = null
        var bestScore = Int.MIN_VALUE
        for (dx in -2..2) for (dy in -2..2) {
            if (dx == 0 && dy == 0) continue
            val t = Tile(from.x + dx, from.y + dy, from.plane)
            if (t !in arena) continue
            val score = openness(t, arena) * opennessWeight +
                max(abs(t.x - fleeFrom.x), abs(t.y - fleeFrom.y)) * FLEE_WEIGHT
            if (score > bestScore) { bestScore = score; best = t }
        }
        return best
    }

    /** 8-neighbour arena membership (0–8): the openness of a tile. */
    private fun openness(t: Tile, arena: Set<Tile>): Int {
        var n = 0
        for (dx in -1..1) for (dy in -1..1) {
            if (dx == 0 && dy == 0) continue
            if (Tile(t.x + dx, t.y + dy, t.plane) in arena) n++
        }
        return n
    }

    private companion object {
        const val FLEE_WEIGHT = 20
    }
}

/**
 * Per-pick preferences. [minDist] is a hard floor on how far the dodge travels; [keepRange] keeps the
 * pick inside a Chebyshev distance band of a focus tile (the boss — stay in weapon range, out of stomp
 * range).
 *
 * @since 0.25.0
 */
data class DodgePrefs(
    val minDist: Int = 1,
    val keepRange: Pair<Tile, IntRange>? = null,
)
