package io.osrsx.plugin

import io.osrsx.api.packArgb
import java.awt.Color

/**
 * The 2D immediate-mode drawing surface a plugin draws through — a thin, engine-agnostic facade over the
 * current UI frame so panels/overlays are authored in osrsx terms (`gfx.text(...)`, `gfx.button(...)`)
 * rather than against a concrete UI toolkit. The engine supplies the backing implementation.
 *
 * Handed to two capabilities:
 *  - [HasPanel.onPanel] — floating in-game overlays. Root-scope draw calls go into an implicit window
 *    titled the plugin name, shown only on frames it actually drew; [overlay] opens extra named windows.
 *  - [HasMenu.onMenu] — the plugin's docked sidebar panel body (a single engine-managed window).
 *
 * Stateful widgets take the current value and return the new one (immediate-mode style): read the
 * returned value and store it back yourself.
 *
 * Every colour is a packed **`0xAARRGGBB` int**; each colour-taking method also offers float-component and
 * [java.awt.Color] overloads (see [io.osrsx.api.packArgb]) that funnel through the single `Int`-ARGB method.
 */
interface Gfx2D {
    fun text(s: String)

    /** Coloured text; [argb] is a packed `0xAARRGGBB` int — the one real implementation path. */
    fun textColored(argb: Int, s: String)

    /** Coloured text from float components (each `0f..1f`). Converts to ARGB and delegates. */
    fun textColored(r: Float, g: Float, b: Float, a: Float, s: String): Unit = textColored(packArgb(r, g, b, a), s)

    /** Coloured text from a [java.awt.Color] (alpha honoured). Converts to ARGB and delegates. */
    fun textColored(color: Color, s: String): Unit = textColored(color.rgb, s)

    fun separator()
    fun sameLine()
    fun spacing()

    /** @return true on the frame the button is clicked. */
    fun button(label: String): Boolean

    /** @return the new checkbox state (pass the current value in). */
    fun checkbox(label: String, value: Boolean): Boolean

    /** @return the new slider value (pass the current value in). */
    fun sliderInt(label: String, value: Int, min: Int, max: Int): Int

    /** @return the new integer (pass the current value in). */
    fun inputInt(label: String, value: Int): Int

    /**
     * Three integers on a **single row** — a game-engine style vector field (X / Y / Z), ideal for a
     * tile/coordinate entry. [label] is shown once after the trio (pass `""` for none). Pass the current
     * components in; @return the new `[x, y, z]`. The default composes three [inputInt]s (functional but not
     * inline) so headless/older engines still work; the real engine renders them compactly on one line.
     */
    fun inputInt3(label: String, x: Int, y: Int, z: Int): IntArray =
        intArrayOf(inputInt("$label X", x), inputInt("$label Y", y), inputInt("$label Z", z))

    /** @return the new text (pass the current value in). */
    fun inputText(label: String, value: String, maxLen: Int = 256): String

    /**
     * A searchable item picker (GE-search-style fuzzy match, item sprite + name + category rows). [id] is a
     * stable widget key. @return the selected item id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]) for engine impls without a graphical surface.
     */
    fun itemPicker(id: String, selected: Int): Int = selected

    /**
     * A searchable NPC picker (fuzzy match, NPC model thumbnail + name + combat/actions rows). [id] is a
     * stable widget key. @return the selected NPC id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]).
     */
    fun npcPicker(id: String, selected: Int): Int = selected

    /**
     * A searchable object picker (fuzzy match, object model thumbnail + name + coordinates rows). [id] is a
     * stable widget key. @return the selected object id (`< 0` = none); pass the current selection in. The
     * default is a no-op (returns [selected]).
     */
    fun objectPicker(id: String, selected: Int): Int = selected

    /**
     * Open an **additional** overlay window titled [title] and draw its body via [block]. Meant for
     * [HasPanel.onPanel]: each call is its own engine-managed, alt-draggable floating window, independent of
     * the implicit plugin-named window that the root scope's draw calls fill. Draw only [overlay] windows
     * (and nothing at the root) to suppress that default window entirely.
     *
     * In a docked [HasMenu.onMenu] body there is no separate overlay chrome, so this simply renders [block]
     * inline in the panel.
     */
    fun overlay(title: String, block: (Gfx2D) -> Unit)

    /** Initial-only window position for the current window (the user can move it after). */
    fun setNextWindowPos(x: Float, y: Float)

    /** Initial-only window size for the current window (the user can resize after). */
    fun setNextWindowSize(w: Float, h: Float)
}
